<?php
/**
 * Template Name: Contact
 * 
 * Contact page template
 *
 * @package GAS_Developer
 */

get_header();
?>

<div class="developer-page-content" style="padding-top: 120px;">
    <div class="developer-container">
        <h1 style="color: #1e293b; margin: 0 0 8px; font-size: 2rem;"><?php the_title(); ?></h1>
        <p style="color: #64748b; margin: 0 0 30px;">Have questions? We'd love to hear from you.</p>
        
        <div class="developer-contact-grid">
            <div class="developer-contact-info">
                <h3>Get In Touch</h3>
                <p style="color: var(--developer-text-light); margin-bottom: 32px;">Whether you have questions about our properties, need help with a booking, or just want to say hello, we're here to help.</p>
                
                <?php if (get_theme_mod('developer_phone')) : ?>
                <div class="developer-contact-item">
                    <div class="developer-contact-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                    </div>
                    <div>
                        <strong>Phone</strong><br>
                        <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', get_theme_mod('developer_phone'))); ?>"><?php echo esc_html(get_theme_mod('developer_phone')); ?></a>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (get_theme_mod('developer_email')) : ?>
                <div class="developer-contact-item">
                    <div class="developer-contact-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    </div>
                    <div>
                        <strong>Email</strong><br>
                        <a href="mailto:<?php echo esc_attr(get_theme_mod('developer_email')); ?>"><?php echo esc_html(get_theme_mod('developer_email')); ?></a>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (get_theme_mod('developer_address')) : ?>
                <div class="developer-contact-item">
                    <div class="developer-contact-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    </div>
                    <div>
                        <strong>Address</strong><br>
                        <?php echo nl2br(esc_html(get_theme_mod('developer_address'))); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="developer-contact-form">
                <form action="#" method="post">
                    <input type="text" name="name" placeholder="Your Name" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                    <input type="text" name="subject" placeholder="Subject">
                    <textarea name="message" placeholder="Your Message" required></textarea>
                    <button type="submit">Send Message</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
