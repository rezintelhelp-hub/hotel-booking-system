<?php
/**
 * Homepage Template
 *
 * @package GAS_Developer
 */

get_header();

// Hero settings
$hero_bg = get_theme_mod('developer_hero_bg', '');
$hero_video_url = get_theme_mod('developer_hero_video_url', '');
$hero_badge = get_theme_mod('developer_hero_badge', 'Welcome to Paradise');
$hero_badge_link = get_theme_mod('developer_hero_badge_link', '');
$hero_badge_bg = get_theme_mod('developer_hero_badge_bg', 'rgba(255,255,255,0.15)');
$hero_badge_text = get_theme_mod('developer_hero_badge_text', '#ffffff');
$hero_badge_border = get_theme_mod('developer_hero_badge_border', 'rgba(255,255,255,0.3)');
$hero_title = get_theme_mod('developer_hero_title', 'Find Your Perfect Vacation Rental');
$hero_subtitle = get_theme_mod('developer_hero_subtitle', 'Discover stunning vacation rentals with luxury amenities, prime locations, and unforgettable experiences.');
$hero_opacity = get_theme_mod('developer_hero_opacity', 30);
$hero_overlay_color = get_theme_mod('developer_hero_overlay_color', '#0f172a');

// Search widget settings
$search_bg = get_theme_mod('developer_search_bg', '#ffffff');
$search_opacity = get_theme_mod('developer_search_opacity', 100);
$search_radius = get_theme_mod('developer_search_radius', '16');
$search_btn_bg = get_theme_mod('developer_hero_search_btn_bg', '#2563eb');
$search_btn_text = get_theme_mod('developer_hero_search_btn_text', '#ffffff');
$search_below_text = get_theme_mod('developer_search_below_text', '');
$search_max_width = get_theme_mod('developer_search_max_width', '900');
$search_scale = get_theme_mod('developer_search_scale', '100');

// Hero trust badges
$hero_badge_1 = get_theme_mod('developer_hero_trust_1', 'Instant Booking');
$hero_badge_2 = get_theme_mod('developer_hero_trust_2', 'Best Price Guarantee');
$hero_badge_3 = get_theme_mod('developer_hero_trust_3', '24/7 Support');

// Intro section settings
$intro_enabled = get_theme_mod('developer_intro_enabled', true);
$intro_bg = get_theme_mod('developer_intro_bg', '#ffffff');
$intro_text_color = get_theme_mod('developer_intro_text_color', '#1e293b');
$intro_title = get_theme_mod('developer_intro_title', 'Welcome to Our Property');
$intro_title_size = get_theme_mod('developer_intro_title_size', '36');
$intro_text = get_theme_mod('developer_intro_text', 'We are delighted to have you here. Explore our beautiful accommodations and find your perfect stay.');
$intro_text_size = get_theme_mod('developer_intro_text_size', '18');
$intro_max_width = get_theme_mod('developer_intro_max_width', '800');
$intro_btn_text = get_theme_mod('developer_intro_btn_text', '');
$intro_btn_url = get_theme_mod('developer_intro_btn_url', '');
$intro_btn_bg = get_theme_mod('developer_intro_btn_bg', '#2563eb');
$intro_btn_text_color = get_theme_mod('developer_intro_btn_text_color', '#ffffff');

// Featured properties settings
$featured_mode = get_theme_mod('developer_featured_mode', 'all');
$featured_enabled = get_theme_mod('developer_featured_enabled', true);
$featured_count = get_theme_mod('developer_featured_count', 3);
$featured_ids = get_theme_mod('developer_featured_ids', '');
$featured_title = get_theme_mod('developer_featured_title', 'Featured Properties');
$featured_subtitle = get_theme_mod('developer_featured_subtitle', 'Discover our handpicked selection of stunning vacation rentals, each offering unique experiences and exceptional comfort.');
$featured_btn_text = get_theme_mod('developer_featured_btn_text', 'View All Properties');
$featured_btn_url = get_theme_mod('developer_featured_btn_url', '/book-now/');
$featured_btn_bg = get_theme_mod('developer_featured_btn_bg', '#2563eb');
$featured_btn_text_color = get_theme_mod('developer_featured_btn_text_color', '#ffffff');
$featured_btn_enabled = get_theme_mod('developer_featured_btn_enabled', true);
$featured_bg = get_theme_mod('developer_featured_bg', '#ffffff');
$featured_title_color = get_theme_mod('developer_featured_title_color', '#1e293b');
$featured_subtitle_color = get_theme_mod('developer_featured_subtitle_color', '#64748b');

// About settings
$about_enabled = get_theme_mod('developer_about_enabled', true);
$about_image = get_theme_mod('developer_about_image', '');
$about_title = get_theme_mod('developer_about_title', 'Experience Luxury & Comfort');
$about_title_size = get_theme_mod('developer_about_title_size', '36');
$about_text = get_theme_mod('developer_about_text', 'Our carefully curated collection of vacation rentals offers the perfect blend of luxury, comfort, and convenience. Whether you\'re planning a family reunion, a getaway with friends, or a romantic escape, we have the ideal property for you.');
$about_text_size = get_theme_mod('developer_about_text_size', '16');
$about_layout = get_theme_mod('developer_about_layout', 'image-left');
$about_btn_text = get_theme_mod('developer_about_btn_text', 'Learn More');
$about_btn_url = get_theme_mod('developer_about_btn_url', '/about/');
$about_btn_bg = get_theme_mod('developer_about_btn_bg', '#2563eb');
$about_btn_text_color = get_theme_mod('developer_about_btn_text_color', '#ffffff');
$about_bg = get_theme_mod('developer_about_bg', '#f8fafc');
$about_title_color = get_theme_mod('developer_about_title_color', '#1e293b');
$about_text_color = get_theme_mod('developer_about_text_color', '#475569');

// About features (editable)
$about_feature_1 = get_theme_mod('developer_about_feature_1', 'Spacious Bedrooms');
$about_feature_2 = get_theme_mod('developer_about_feature_2', 'Luxury Bathrooms');
$about_feature_3 = get_theme_mod('developer_about_feature_3', 'Prime Locations');
$about_feature_4 = get_theme_mod('developer_about_feature_4', 'Full Amenities');
$about_feature_5 = get_theme_mod('developer_about_feature_5', 'Entertainment Areas');
$about_feature_6 = get_theme_mod('developer_about_feature_6', 'Private Parking');

// Calculate overlay opacity (convert percentage to decimal)
$overlay_opacity = $hero_opacity / 100;

// Convert hex to RGB for rgba
$hex = ltrim($hero_overlay_color, '#');
$r = hexdec(substr($hex, 0, 2));
$g = hexdec(substr($hex, 2, 2));
$b = hexdec(substr($hex, 4, 2));

// Convert search bg hex to RGB for opacity
$search_hex = ltrim($search_bg, '#');
$sr = hexdec(substr($search_hex, 0, 2));
$sg = hexdec(substr($search_hex, 2, 2));
$sb = hexdec(substr($search_hex, 4, 2));
$search_bg_rgba = "rgba($sr, $sg, $sb, " . ($search_opacity / 100) . ")";
?>

<!-- Hero Section -->
<section class="developer-hero">
    <?php if ($hero_video_url) : ?>
        <!-- Video Background -->
        <video class="developer-hero-video" autoplay muted loop playsinline>
            <source src="<?php echo esc_url($hero_video_url); ?>" type="video/mp4">
        </video>
        <?php if ($hero_bg) : ?>
            <!-- Fallback image for mobile/slow connections -->
            <div class="developer-hero-bg developer-hero-bg-fallback" style="background-image: url('<?php echo esc_url($hero_bg); ?>');"></div>
        <?php endif; ?>
    <?php elseif ($hero_bg) : ?>
        <div class="developer-hero-bg" style="background-image: url('<?php echo esc_url($hero_bg); ?>');"></div>
    <?php endif; ?>
    <div class="developer-hero-overlay" style="background: rgba(<?php echo "$r, $g, $b"; ?>, <?php echo esc_attr($overlay_opacity); ?>);"></div>
    
    <div class="developer-hero-content">
        <?php if ($hero_badge) : ?>
            <?php if ($hero_badge_link) : ?>
                <a href="<?php echo esc_url($hero_badge_link); ?>" class="developer-hero-badge" style="background: <?php echo esc_attr($hero_badge_bg); ?>; color: <?php echo esc_attr($hero_badge_text); ?>; border-color: <?php echo esc_attr($hero_badge_border); ?>; text-decoration: none;"><?php echo esc_html($hero_badge); ?></a>
            <?php else : ?>
                <span class="developer-hero-badge" style="background: <?php echo esc_attr($hero_badge_bg); ?>; color: <?php echo esc_attr($hero_badge_text); ?>; border-color: <?php echo esc_attr($hero_badge_border); ?>;"><?php echo esc_html($hero_badge); ?></span>
            <?php endif; ?>
        <?php endif; ?>
        
        <h1><?php echo esc_html($hero_title); ?></h1>
        <p class="developer-hero-subtitle"><?php echo esc_html($hero_subtitle); ?></p>
        
        <!-- GAS Search Widget with custom styling -->
        <div class="developer-search-wrapper" style="background: <?php echo esc_attr($search_bg_rgba); ?>; border-radius: <?php echo esc_attr($search_radius); ?>px; max-width: <?php echo esc_attr($search_max_width); ?>px; transform: scale(<?php echo esc_attr($search_scale / 100); ?>); transform-origin: center top;">
            <?php if (shortcode_exists('gas_search')) : ?>
                <?php echo do_shortcode('[gas_search layout="horizontal" max_width="100%" primary_color="' . esc_attr($search_btn_bg) . '" text_color="' . esc_attr($search_btn_text) . '" background_color="transparent"]'); ?>
            <?php else : ?>
                <div style="padding: 24px 32px; text-align: center;">
                    <p style="margin: 0; color: #64748b;">Search widget will appear here when GAS Booking plugin is activated.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if ($search_below_text) : ?>
            <p class="developer-search-below-text"><?php echo esc_html($search_below_text); ?></p>
        <?php endif; ?>
        
        <?php if ($hero_badge_1 || $hero_badge_2 || $hero_badge_3) : ?>
        <div class="developer-hero-features">
            <?php if ($hero_badge_1) : ?>
            <div class="developer-hero-feature">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                <span><?php echo esc_html($hero_badge_1); ?></span>
            </div>
            <?php endif; ?>
            <?php if ($hero_badge_2) : ?>
            <div class="developer-hero-feature">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                <span><?php echo esc_html($hero_badge_2); ?></span>
            </div>
            <?php endif; ?>
            <?php if ($hero_badge_3) : ?>
            <div class="developer-hero-feature">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                <span><?php echo esc_html($hero_badge_3); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php if ($intro_enabled && ($intro_title || $intro_text)) : ?>
<!-- Intro Section -->
<section class="developer-section developer-intro" style="background: <?php echo esc_attr($intro_bg); ?>; color: <?php echo esc_attr($intro_text_color); ?>;">
    <div class="developer-container">
        <div class="developer-intro-content" style="max-width: <?php echo esc_attr($intro_max_width); ?>px;">
            <?php if ($intro_title) : ?>
                <h2 style="color: <?php echo esc_attr($intro_text_color); ?>; font-size: <?php echo esc_attr($intro_title_size); ?>px;"><?php echo esc_html($intro_title); ?></h2>
            <?php endif; ?>
            <?php if ($intro_text) : ?>
                <p style="font-size: <?php echo esc_attr($intro_text_size); ?>px;"><?php echo esc_html($intro_text); ?></p>
            <?php endif; ?>
            <?php if ($intro_btn_text && $intro_btn_url) : ?>
                <a href="<?php echo esc_url($intro_btn_url); ?>" class="developer-btn" style="background: <?php echo esc_attr($intro_btn_bg); ?>; color: <?php echo esc_attr($intro_btn_text_color); ?>;"><?php echo esc_html($intro_btn_text); ?></a>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($featured_enabled) : ?>
<!-- Featured Properties -->
<section class="developer-section developer-featured" style="background-color: <?php echo esc_attr($featured_bg); ?>;">
    <div class="developer-container">
        <div class="developer-section-header">
            <h2 style="color: <?php echo esc_attr($featured_title_color); ?>;"><?php echo esc_html($featured_title); ?></h2>
            <p style="color: <?php echo esc_attr($featured_subtitle_color); ?>;"><?php echo esc_html($featured_subtitle); ?></p>
        </div>
        
        <?php 
        // Build shortcode based on display mode
        if (shortcode_exists('gas_rooms')) :
            $shortcode = '[gas_rooms columns="3" show_map="false"';
            
            if ($featured_mode === 'specific' && !empty($featured_ids)) {
                $shortcode .= ' room_ids="' . esc_attr($featured_ids) . '"';
            } elseif ($featured_mode === 'random') {
                $shortcode .= ' limit="' . esc_attr($featured_count) . '" random="true"';
            } else {
                $shortcode .= ' limit="' . esc_attr($featured_count) . '"';
            }
            
            $shortcode .= ']';
            echo do_shortcode($shortcode);
        else : ?>
            <div style="text-align: center; padding: 60px; background: #f8fafc; border-radius: 12px;">
                <p style="color: #64748b; margin: 0;">Property listings will appear here when GAS Booking plugin is activated.</p>
            </div>
        <?php endif; ?>
        
        <?php if ($featured_btn_enabled && $featured_btn_text) : ?>
        <div class="text-center mt-5">
            <a href="<?php echo esc_url(home_url($featured_btn_url)); ?>" class="developer-btn" style="background: <?php echo esc_attr($featured_btn_bg); ?>; color: <?php echo esc_attr($featured_btn_text_color); ?>;"><?php echo esc_html($featured_btn_text); ?></a>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<?php if ($about_enabled) : ?>
<!-- About Section -->
<section class="developer-section developer-section-alt" style="background-color: <?php echo esc_attr($about_bg); ?>;">
    <div class="developer-container">
        <div class="developer-about <?php echo esc_attr('developer-about-' . $about_layout); ?>">
            <div class="developer-about-image">
                <?php if ($about_image) : ?>
                    <img src="<?php echo esc_url($about_image); ?>" alt="<?php echo esc_attr($about_title); ?>">
                <?php else : ?>
                    <div style="width: 100%; height: 500px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 48px; border-radius: 16px;">🏠</div>
                <?php endif; ?>
            </div>
            
            <div class="developer-about-content">
                <h2 style="font-size: <?php echo esc_attr($about_title_size); ?>px; color: <?php echo esc_attr($about_title_color); ?>;"><?php echo esc_html($about_title); ?></h2>
                <p style="font-size: <?php echo esc_attr($about_text_size); ?>px; color: <?php echo esc_attr($about_text_color); ?>;"><?php echo esc_html($about_text); ?></p>
                
                <div class="developer-features-list">
                    <?php 
                    $features = array($about_feature_1, $about_feature_2, $about_feature_3, $about_feature_4, $about_feature_5, $about_feature_6);
                    foreach ($features as $feature) :
                        if (!empty($feature)) :
                    ?>
                    <div class="developer-feature-item">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                        <span><?php echo esc_html($feature); ?></span>
                    </div>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </div>
                
                <?php if ($about_btn_text) : ?>
                <div class="mt-4">
                    <a href="<?php echo esc_url(home_url($about_btn_url)); ?>" class="developer-btn" style="background: <?php echo esc_attr($about_btn_bg); ?>; color: <?php echo esc_attr($about_btn_text_color); ?>;"><?php echo esc_html($about_btn_text); ?></a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php 
// Reviews Section
$reviews_enabled = get_theme_mod('developer_reviews_enabled', false);
$reviews_title = get_theme_mod('developer_reviews_title', 'What Our Guests Say');
$reviews_subtitle = get_theme_mod('developer_reviews_subtitle', 'Real reviews from real guests across all platforms');
$reviews_bg = get_theme_mod('developer_reviews_bg', '#0f172a');
$reviews_text_color = get_theme_mod('developer_reviews_text_color', '#ffffff');
$reviews_style = get_theme_mod('developer_reviews_style', 'slider');
$reviews_limit = get_theme_mod('developer_reviews_limit', '6');
$reviews_use_app = get_theme_mod('developer_reviews_use_app', false);

// Get manual reviews
$review1_name = get_theme_mod('developer_reviews_review1_name', '');
$review1_source = get_theme_mod('developer_reviews_review1_source', '');
$review1_text = get_theme_mod('developer_reviews_review1_text', '');
$review2_name = get_theme_mod('developer_reviews_review2_name', '');
$review2_source = get_theme_mod('developer_reviews_review2_source', '');
$review2_text = get_theme_mod('developer_reviews_review2_text', '');
$review3_name = get_theme_mod('developer_reviews_review3_name', '');
$review3_source = get_theme_mod('developer_reviews_review3_source', '');
$review3_text = get_theme_mod('developer_reviews_review3_text', '');
$has_manual_reviews = $review1_text || $review2_text || $review3_text;

if ($reviews_enabled && $reviews_use_app && shortcode_exists('gas_reviews')) : 
?>
<!-- Reviews Section (GAS Reviews App) -->
<section class="developer-section developer-reviews" style="background: <?php echo esc_attr($reviews_bg); ?>; color: <?php echo esc_attr($reviews_text_color); ?>;">
    <div class="developer-container">
        <div class="developer-section-header">
            <h2 style="color: <?php echo esc_attr($reviews_text_color); ?>;"><?php echo esc_html($reviews_title); ?></h2>
            <p style="color: <?php echo esc_attr($reviews_text_color); ?>; opacity: 0.8;"><?php echo esc_html($reviews_subtitle); ?></p>
        </div>
        
        <div class="developer-reviews-widget">
            <?php 
            // Output the appropriate shortcode based on style
            switch ($reviews_style) {
                case 'slider':
                    echo do_shortcode('[gas_reviews_slider]');
                    break;
                case 'grid':
                    echo do_shortcode('[gas_reviews limit="' . esc_attr($reviews_limit) . '" layout="grid"]');
                    break;
                case 'badges':
                    echo do_shortcode('[gas_reviews_badge]');
                    break;
                case 'summary':
                    echo do_shortcode('[gas_reviews_summary]');
                    break;
                default:
                    echo do_shortcode('[gas_reviews_slider]');
            }
            ?>
        </div>
    </div>
</section>
<?php elseif ($reviews_enabled && $has_manual_reviews) : ?>
<!-- Manual Reviews Section -->
<section class="developer-section developer-testimonials" style="background: <?php echo esc_attr($reviews_bg); ?>;">
    <div class="developer-container">
        <div class="developer-section-header">
            <h2 style="color: <?php echo esc_attr($reviews_text_color); ?>;"><?php echo esc_html($reviews_title); ?></h2>
            <p style="color: <?php echo esc_attr($reviews_text_color); ?>; opacity: 0.8;"><?php echo esc_html($reviews_subtitle); ?></p>
        </div>
        <div class="developer-testimonials-grid">
            <?php if ($review1_text) : ?>
            <div class="developer-testimonial-card">
                <div class="developer-testimonial-stars">★★★★★</div>
                <p>"<?php echo esc_html($review1_text); ?>"</p>
                <div class="developer-testimonial-author">
                    <strong><?php echo esc_html($review1_name ?: 'Guest'); ?></strong>
                    <span><?php echo esc_html($review1_source); ?></span>
                </div>
            </div>
            <?php endif; ?>
            <?php if ($review2_text) : ?>
            <div class="developer-testimonial-card">
                <div class="developer-testimonial-stars">★★★★★</div>
                <p>"<?php echo esc_html($review2_text); ?>"</p>
                <div class="developer-testimonial-author">
                    <strong><?php echo esc_html($review2_name ?: 'Guest'); ?></strong>
                    <span><?php echo esc_html($review2_source); ?></span>
                </div>
            </div>
            <?php endif; ?>
            <?php if ($review3_text) : ?>
            <div class="developer-testimonial-card">
                <div class="developer-testimonial-stars">★★★★★</div>
                <p>"<?php echo esc_html($review3_text); ?>"</p>
                <div class="developer-testimonial-author">
                    <strong><?php echo esc_html($review3_name ?: 'Guest'); ?></strong>
                    <span><?php echo esc_html($review3_source); ?></span>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php 
// CTA Section settings
$cta_enabled = get_theme_mod('developer_cta_enabled', true);
$cta_title = get_theme_mod('developer_cta_title', 'Ready to Book Your Stay?');
$cta_title_size = get_theme_mod('developer_cta_title_size', '36');
$cta_text = get_theme_mod('developer_cta_text', 'Find your perfect vacation rental today and create memories that last a lifetime.');
$cta_text_size = get_theme_mod('developer_cta_text_size', '18');
$cta_background = get_theme_mod('developer_cta_background', '#2563eb');
$cta_text_color = get_theme_mod('developer_cta_text_color', '#ffffff');
$cta_btn_text = get_theme_mod('developer_cta_btn_text', 'Browse Properties');
$cta_btn_url = get_theme_mod('developer_cta_btn_url', '/book-now/');
$cta_btn_bg = get_theme_mod('developer_cta_btn_bg', '#ffffff');
$cta_btn_text_color = get_theme_mod('developer_cta_btn_text_color', '#2563eb');

if ($cta_enabled) : 
?>
<!-- CTA Section -->
<section class="developer-section developer-cta" style="background: <?php echo esc_attr($cta_background); ?>;">
    <div class="developer-container">
        <div class="developer-cta-content">
            <h2 style="color: <?php echo esc_attr($cta_text_color); ?>; font-size: <?php echo esc_attr($cta_title_size); ?>px;"><?php echo esc_html($cta_title); ?></h2>
            <p style="color: <?php echo esc_attr($cta_text_color); ?>; opacity: 0.9; font-size: <?php echo esc_attr($cta_text_size); ?>px;"><?php echo esc_html($cta_text); ?></p>
            <?php if ($cta_btn_text) : ?>
                <a href="<?php echo esc_url(home_url($cta_btn_url)); ?>" class="developer-btn" style="background: <?php echo esc_attr($cta_btn_bg); ?>; color: <?php echo esc_attr($cta_btn_text_color); ?>;"><?php echo esc_html($cta_btn_text); ?></a>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php get_footer(); ?>
