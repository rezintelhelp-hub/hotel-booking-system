<?php
/**
 * Single Post Template
 *
 * @package GAS_Developer
 */

get_header();

$post_type = get_post_type();
$is_gas_blog = ($post_type === 'gas_blog');
$is_gas_attraction = ($post_type === 'gas_attraction');

// Get accent color
$accent_color = '#667eea';
if ($is_gas_blog) {
    $accent_color = get_option('gas_blog_accent_color', '#667eea');
} elseif ($is_gas_attraction) {
    $accent_color = get_option('gas_attractions_accent_color', '#667eea');
}
?>

<article class="developer-single-post">
    <div class="developer-page-content" style="padding-top: 120px;">
        <div class="developer-container">
            <div style="max-width: 800px; margin: 0 auto;">
                <?php if ($is_gas_blog) : 
                    $categories = get_the_terms(get_the_ID(), 'gas_blog_category');
                    $read_time = get_post_meta(get_the_ID(), '_gas_blog_read_time', true) ?: '5';
                ?>
                    <div style="color: #64748b; margin-bottom: 12px; font-size: 0.9rem;">
                        <?php echo get_the_date(); ?> 
                        · <?php echo esc_html($read_time); ?> min read
                        <?php if ($categories && !is_wp_error($categories)) : ?>
                            · <?php echo esc_html($categories[0]->name); ?>
                        <?php endif; ?>
                    </div>
                <?php elseif ($is_gas_attraction) :
                    $categories = get_the_terms(get_the_ID(), 'gas_attraction_cat');
                    $rating = get_post_meta(get_the_ID(), '_gas_attraction_rating', true);
                ?>
                    <div style="color: #64748b; margin-bottom: 12px; font-size: 0.9rem;">
                        <?php if ($categories && !is_wp_error($categories)) : ?>
                            <?php echo esc_html($categories[0]->name); ?>
                        <?php endif; ?>
                        <?php if ($rating) : ?>
                            · ⭐ <?php echo esc_html($rating); ?>/5
                        <?php endif; ?>
                    </div>
                <?php else : ?>
                    <div style="color: #64748b; margin-bottom: 12px; font-size: 0.9rem;">
                        <?php echo get_the_date(); ?> · <?php echo get_the_category_list(', '); ?>
                    </div>
                <?php endif; ?>
                
                <h1 style="color: #1e293b; margin: 0 0 24px; font-size: 2rem;"><?php the_title(); ?></h1>
                
                <?php if (has_post_thumbnail()) : ?>
                    <div style="margin-bottom: 30px; border-radius: 12px; overflow: hidden; box-shadow: var(--developer-shadow-lg);">
                        <?php the_post_thumbnail('large', array('style' => 'width: 100%; height: auto;')); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($is_gas_attraction) : 
                    $address = get_post_meta(get_the_ID(), '_gas_attraction_address', true);
                    $distance = get_post_meta(get_the_ID(), '_gas_attraction_distance', true);
                    $phone = get_post_meta(get_the_ID(), '_gas_attraction_phone', true);
                    $website = get_post_meta(get_the_ID(), '_gas_attraction_website', true);
                    $hours = get_post_meta(get_the_ID(), '_gas_attraction_hours', true);
                    $price = get_post_meta(get_the_ID(), '_gas_attraction_price', true);
                    $map_url = get_post_meta(get_the_ID(), '_gas_attraction_map_url', true);
                ?>
                    <div style="background: #f8fafc; border-radius: 12px; padding: 24px; margin-bottom: 30px; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                        <?php if ($address) : ?>
                            <div><strong>📍 Address</strong><br><?php echo esc_html($address); ?></div>
                        <?php endif; ?>
                        <?php if ($distance) : ?>
                            <div><strong>🚗 Distance</strong><br><?php echo esc_html($distance); ?></div>
                        <?php endif; ?>
                        <?php if ($phone) : ?>
                            <div><strong>📞 Phone</strong><br><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $phone)); ?>"><?php echo esc_html($phone); ?></a></div>
                        <?php endif; ?>
                        <?php if ($hours) : ?>
                            <div><strong>🕐 Hours</strong><br><?php echo esc_html($hours); ?></div>
                        <?php endif; ?>
                        <?php if ($price) : ?>
                            <div><strong>💰 Price</strong><br><?php echo esc_html($price === 'free' ? 'Free' : $price); ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($website || $map_url) : ?>
                        <div style="display: flex; gap: 12px; margin-bottom: 30px;">
                            <?php if ($website) : ?>
                                <a href="<?php echo esc_url($website); ?>" target="_blank" rel="noopener" style="background: <?php echo esc_attr($accent_color); ?>; color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600;">Visit Website</a>
                            <?php endif; ?>
                            <?php if ($map_url) : ?>
                                <a href="<?php echo esc_url($map_url); ?>" target="_blank" rel="noopener" style="background: #f1f5f9; color: #475569; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600;">Get Directions</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                
                <div class="developer-post-content" style="font-size: 18px; line-height: 1.8;">
                    <?php the_content(); ?>
                </div>
                
                <div style="margin-top: 60px; padding-top: 40px; border-top: 1px solid var(--developer-border);">
                    <h3>Share This</h3>
                    <div style="display: flex; gap: 12px; margin-top: 16px;">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" class="developer-btn" style="background: #1877f2; color: white; padding: 10px 20px;">Facebook</a>
                        <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>" target="_blank" class="developer-btn" style="background: #1da1f2; color: white; padding: 10px 20px;">Twitter</a>
                    </div>
                </div>
                
                <div style="margin-top: 60px;">
                    <?php if ($is_gas_blog) : ?>
                        <a href="<?php echo esc_url(home_url('/blog/')); ?>" style="display: inline-flex; align-items: center; gap: 8px; color: <?php echo esc_attr($accent_color); ?>;">
                            ← Back to Blog
                        </a>
                    <?php elseif ($is_gas_attraction) : ?>
                        <a href="<?php echo esc_url(home_url('/attractions/')); ?>" style="display: inline-flex; align-items: center; gap: 8px; color: <?php echo esc_attr($accent_color); ?>;">
                            ← Back to Attractions
                        </a>
                    <?php else : ?>
                        <a href="<?php echo esc_url(home_url('/blog/')); ?>" style="display: inline-flex; align-items: center; gap: 8px; color: var(--developer-primary);">
                            ← Back to Blog
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</article>

<?php get_footer(); ?>
