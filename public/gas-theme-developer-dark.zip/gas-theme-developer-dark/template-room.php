<?php
/**
 * Template Name: Room Detail
 * 
 * Single room/property detail page
 *
 * @package GAS_Developer
 */

get_header();
?>

<div class="developer-page-content">
    <div class="developer-container">
        <?php if (shortcode_exists('gas_room')) : ?>
            <?php echo do_shortcode('[gas_room]'); ?>
        <?php else : ?>
            <div style="text-align: center; padding: 80px 24px; background: #f8fafc; border-radius: 12px;">
                <h3>Room Details</h3>
                <p style="color: #64748b;">Please install and activate the GAS Booking plugin to display room details.</p>
                <a href="<?php echo esc_url(home_url('/book-now/')); ?>" class="developer-btn developer-btn-primary" style="background: var(--developer-primary); color: white; margin-top: 16px;">View All Properties</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
