Theme Screenshot Instructions
============================

To complete the theme, add a screenshot.png file (1200x900 pixels recommended) 
showing a preview of the theme design.

This file should be placed in the root of the theme folder:
/gas-theme-developer/screenshot.png

For now, the theme will work without it, but WordPress will show a blank 
preview in the Themes screen.
