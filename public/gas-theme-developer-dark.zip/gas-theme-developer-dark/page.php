<?php
/**
 * Default Page Template
 *
 * @package GAS_Developer
 */

get_header();

// Auto-detect page type by slug
$page_slug = get_post_field('post_name', get_post());
$content = get_the_content();

// Check if this is the Book Now / Properties page - redirect to that template's behavior
if (in_array($page_slug, array('book-now', 'properties', 'rooms', 'listings', 'accommodations'))) {
    // Use Book Now template layout
    ?>
    <div class="developer-book-now-page" style="padding-top: 100px;">
        <?php if (shortcode_exists('gas_rooms')) : ?>
            <?php echo do_shortcode('[gas_rooms]'); ?>
        <?php else : ?>
            <div style="text-align: center; padding: 80px 24px; background: #f8fafc; border-radius: 12px; margin: 20px 24px;">
                <h3>Properties Coming Soon</h3>
                <p style="color: #64748b;">Please install and activate the GAS Booking plugin to display properties.</p>
            </div>
        <?php endif; ?>
    </div>
    <?php
    get_footer();
    return; // Stop processing rest of page.php
}

// Check which special page this is
$special_page = '';
if (in_array($page_slug, array('about', 'about-us', 'our-story'))) {
    $special_page = 'about';
} elseif (in_array($page_slug, array('contact', 'contact-us', 'get-in-touch'))) {
    $special_page = 'contact';
} elseif (in_array($page_slug, array('terms', 'terms-and-conditions', 'terms-of-service'))) {
    $special_page = 'terms';
} elseif (in_array($page_slug, array('privacy', 'privacy-policy'))) {
    $special_page = 'privacy';
} elseif (in_array($page_slug, array('blog', 'news', 'journal', 'posts')) && shortcode_exists('gas_blog')) {
    $special_page = 'blog';
} elseif (in_array($page_slug, array('attractions', 'things-to-do', 'explore', 'local-area', 'area-guide')) && shortcode_exists('gas_attractions')) {
    $special_page = 'attractions';
}

// Wide layout for special pages
$wide_layout = in_array($special_page, array('about', 'contact', 'blog', 'attractions'));
$max_width = $wide_layout ? '1100px' : '800px';

// Get primary color
$primary_color = get_theme_mod('developer_primary_color', '#2563eb');
?>

<div class="developer-page-content" style="padding-top: 120px;">
    <div class="developer-container">
        <?php while (have_posts()) : the_post(); ?>
            <div class="developer-page-body" style="max-width: <?php echo esc_attr($max_width); ?>; margin: 0 auto;">
                
                <?php if ($special_page === 'about') : 
                    // Get About Page settings from Customizer
                    $story = get_theme_mod('developer_about_page_story', '');
                    $history = get_theme_mod('developer_about_page_history', '');
                    $host_name = get_theme_mod('developer_about_page_host_name', '');
                    $host_title = get_theme_mod('developer_about_page_host_title', 'Owner & Host');
                    $host_bio = get_theme_mod('developer_about_page_host_bio', '');
                    $host_image = get_theme_mod('developer_about_page_host_image', '');
                    $values_raw = get_theme_mod('developer_about_page_values', '');
                    $amenities_raw = get_theme_mod('developer_about_page_amenities', '');
                    
                    // Also use homepage about section as fallback
                    $about_image = get_theme_mod('developer_about_image', '');
                    $about_title = get_theme_mod('developer_about_title', '');
                    $about_text = get_theme_mod('developer_about_text', '');
                ?>
                    <div class="gas-about-page">
                        <?php if ($about_image) : ?>
                            <img src="<?php echo esc_url($about_image); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" style="width: 100%; max-height: 400px; object-fit: cover; border-radius: 16px; margin-bottom: 40px;">
                        <?php endif; ?>
                        
                        <?php if ($story || $about_text) : ?>
                        <div style="margin-bottom: 50px;">
                            <h2 style="font-size: 1.75rem; font-weight: 700; color: #1e293b; margin: 0 0 20px; padding-bottom: 10px; border-bottom: 3px solid <?php echo esc_attr($primary_color); ?>; display: inline-block;">Our Story</h2>
                            <div style="font-size: 1.1rem; line-height: 1.8; color: #475569;">
                                <?php echo wpautop(esc_html($story ?: $about_text)); ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($values_raw) : 
                            $values = array_filter(array_map('trim', explode("\n", $values_raw)));
                        ?>
                        <div style="margin-bottom: 50px;">
                            <h2 style="font-size: 1.75rem; font-weight: 700; color: #1e293b; margin: 0 0 30px; padding-bottom: 10px; border-bottom: 3px solid <?php echo esc_attr($primary_color); ?>; display: inline-block;">What We Offer</h2>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 24px;">
                                <?php foreach ($values as $value) :
                                    $parts = array_map('trim', explode('|', $value));
                                    if (count($parts) >= 3) :
                                ?>
                                <div style="background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 4px 15px rgba(0,0,0,0.08); text-align: center;">
                                    <div style="font-size: 40px; margin-bottom: 12px;"><?php echo esc_html($parts[0]); ?></div>
                                    <h3 style="font-size: 1.1rem; font-weight: 700; color: #1e293b; margin: 0 0 8px;"><?php echo esc_html($parts[1]); ?></h3>
                                    <p style="color: #64748b; font-size: 0.95rem; line-height: 1.5; margin: 0;"><?php echo esc_html($parts[2]); ?></p>
                                </div>
                                <?php endif; endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($host_name || $host_bio) : 
                            $host_initial = $host_name ? strtoupper(substr($host_name, 0, 1)) : 'H';
                        ?>
                        <div style="margin-bottom: 50px;">
                            <h2 style="font-size: 1.75rem; font-weight: 700; color: #1e293b; margin: 0 0 30px; padding-bottom: 10px; border-bottom: 3px solid <?php echo esc_attr($primary_color); ?>; display: inline-block;">Meet Your Host</h2>
                            <div style="display: flex; gap: 30px; align-items: flex-start; flex-wrap: wrap;">
                                <?php if ($host_image) : ?>
                                    <img src="<?php echo esc_url($host_image); ?>" alt="<?php echo esc_attr($host_name); ?>" style="width: 180px; height: 180px; border-radius: 50%; object-fit: cover; box-shadow: 0 10px 30px rgba(0,0,0,0.15);">
                                <?php else : ?>
                                    <div style="width: 180px; height: 180px; border-radius: 50%; background: linear-gradient(135deg, <?php echo esc_attr($primary_color); ?>, #a855f7); display: flex; align-items: center; justify-content: center; color: white; font-size: 64px; font-weight: 700; box-shadow: 0 10px 30px rgba(0,0,0,0.15);">
                                        <?php echo esc_html($host_initial); ?>
                                    </div>
                                <?php endif; ?>
                                <div style="flex: 1; min-width: 280px;">
                                    <h3 style="font-size: 1.5rem; font-weight: 700; color: #1e293b; margin: 0 0 4px;"><?php echo esc_html($host_name); ?></h3>
                                    <p style="color: <?php echo esc_attr($primary_color); ?>; font-weight: 500; margin: 0 0 16px;"><?php echo esc_html($host_title); ?></p>
                                    <p style="font-size: 1.05rem; line-height: 1.7; color: #475569; margin: 0;"><?php echo esc_html($host_bio); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($history) : ?>
                        <div style="margin-bottom: 50px;">
                            <h2 style="font-size: 1.75rem; font-weight: 700; color: #1e293b; margin: 0 0 20px; padding-bottom: 10px; border-bottom: 3px solid <?php echo esc_attr($primary_color); ?>; display: inline-block;">Our History</h2>
                            <div style="font-size: 1.1rem; line-height: 1.8; color: #475569;">
                                <?php echo wpautop(esc_html($history)); ?>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($amenities_raw) : 
                            $amenities = array_filter(array_map('trim', explode("\n", $amenities_raw)));
                        ?>
                        <div style="margin-bottom: 50px;">
                            <h2 style="font-size: 1.75rem; font-weight: 700; color: #1e293b; margin: 0 0 30px; padding-bottom: 10px; border-bottom: 3px solid <?php echo esc_attr($primary_color); ?>; display: inline-block;">Amenities</h2>
                            <div style="display: flex; flex-wrap: wrap; gap: 12px;">
                                <?php foreach ($amenities as $amenity) : ?>
                                <span style="background: <?php echo esc_attr($primary_color); ?>15; color: <?php echo esc_attr($primary_color); ?>; padding: 10px 20px; border-radius: 25px; font-weight: 500;">
                                    ✓ <?php echo esc_html($amenity); ?>
                                </span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                
                <?php elseif ($special_page === 'contact') : 
                    // Get Contact settings
                    $email = get_theme_mod('developer_email', 'hello@example.com');
                    $phone = get_theme_mod('developer_phone', '+1 (555) 123-4567');
                    $address = get_theme_mod('developer_address', '');
                    $map_embed = get_theme_mod('developer_contact_page_map', '');
                    $map_link = get_theme_mod('developer_contact_page_map_link', '');
                    $hours = get_theme_mod('developer_contact_page_hours', '');
                    $form_intro = get_theme_mod('developer_contact_page_form_intro', "Have a question? We'd love to hear from you!");
                    
                    // Social links
                    $facebook = get_theme_mod('developer_social_facebook', '');
                    $instagram = get_theme_mod('developer_social_instagram', '');
                    $twitter = get_theme_mod('developer_social_twitter', '');
                ?>
                    <div class="gas-contact-page">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 50px; margin-bottom: 50px;">
                            <div>
                                <h2 style="font-size: 1.5rem; font-weight: 700; color: #1e293b; margin: 0 0 24px;">Send Us a Message</h2>
                                <?php if ($form_intro) : ?>
                                    <p style="color: #64748b; margin: 0 0 24px;"><?php echo esc_html($form_intro); ?></p>
                                <?php endif; ?>
                                
                                <form id="gas-contact-form" style="display: flex; flex-direction: column; gap: 20px;">
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                        <div>
                                            <label style="display: block; font-weight: 600; color: #374151; margin-bottom: 6px;">Name *</label>
                                            <input type="text" name="name" required style="width: 100%; padding: 14px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 1rem;">
                                        </div>
                                        <div>
                                            <label style="display: block; font-weight: 600; color: #374151; margin-bottom: 6px;">Email *</label>
                                            <input type="email" name="email" required style="width: 100%; padding: 14px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 1rem;">
                                        </div>
                                    </div>
                                    <div>
                                        <label style="display: block; font-weight: 600; color: #374151; margin-bottom: 6px;">Subject</label>
                                        <select name="subject" style="width: 100%; padding: 14px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 1rem;">
                                            <option>General Inquiry</option>
                                            <option>Reservation</option>
                                            <option>Special Request</option>
                                            <option>Feedback</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label style="display: block; font-weight: 600; color: #374151; margin-bottom: 6px;">Message *</label>
                                        <textarea name="message" rows="5" required style="width: 100%; padding: 14px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 1rem; resize: vertical;"></textarea>
                                    </div>
                                    <button type="submit" style="background: <?php echo esc_attr($primary_color); ?>; color: white; border: none; padding: 16px 32px; border-radius: 10px; font-size: 1rem; font-weight: 600; cursor: pointer;">Send Message</button>
                                </form>
                            </div>
                            
                            <div>
                                <h2 style="font-size: 1.5rem; font-weight: 700; color: #1e293b; margin: 0 0 24px;">Get in Touch</h2>
                                
                                <?php if ($address) : ?>
                                <div style="display: flex; gap: 16px; margin-bottom: 24px;">
                                    <div style="width: 50px; height: 50px; background: <?php echo esc_attr($primary_color); ?>15; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; flex-shrink: 0;">📍</div>
                                    <div>
                                        <h3 style="font-size: 1rem; font-weight: 700; color: #1e293b; margin: 0 0 4px;">Address</h3>
                                        <p style="color: #64748b; margin: 0; line-height: 1.5;">
                                            <?php if ($map_link) : ?><a href="<?php echo esc_url($map_link); ?>" target="_blank" style="color: <?php echo esc_attr($primary_color); ?>; text-decoration: none;"><?php endif; ?>
                                            <?php echo nl2br(esc_html($address)); ?>
                                            <?php if ($map_link) : ?></a><?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($phone) : ?>
                                <div style="display: flex; gap: 16px; margin-bottom: 24px;">
                                    <div style="width: 50px; height: 50px; background: <?php echo esc_attr($primary_color); ?>15; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; flex-shrink: 0;">📞</div>
                                    <div>
                                        <h3 style="font-size: 1rem; font-weight: 700; color: #1e293b; margin: 0 0 4px;">Phone</h3>
                                        <p style="margin: 0;"><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $phone)); ?>" style="color: <?php echo esc_attr($primary_color); ?>; text-decoration: none;"><?php echo esc_html($phone); ?></a></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($email) : ?>
                                <div style="display: flex; gap: 16px; margin-bottom: 24px;">
                                    <div style="width: 50px; height: 50px; background: <?php echo esc_attr($primary_color); ?>15; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; flex-shrink: 0;">✉️</div>
                                    <div>
                                        <h3 style="font-size: 1rem; font-weight: 700; color: #1e293b; margin: 0 0 4px;">Email</h3>
                                        <p style="margin: 0;"><a href="mailto:<?php echo esc_attr($email); ?>" style="color: <?php echo esc_attr($primary_color); ?>; text-decoration: none;"><?php echo esc_html($email); ?></a></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($hours) : ?>
                                <div style="display: flex; gap: 16px; margin-bottom: 24px;">
                                    <div style="width: 50px; height: 50px; background: <?php echo esc_attr($primary_color); ?>15; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; flex-shrink: 0;">🕐</div>
                                    <div>
                                        <h3 style="font-size: 1rem; font-weight: 700; color: #1e293b; margin: 0 0 4px;">Hours</h3>
                                        <p style="color: #64748b; margin: 0; line-height: 1.6;"><?php echo nl2br(esc_html($hours)); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($facebook || $instagram || $twitter) : ?>
                                <div style="display: flex; gap: 12px; margin-top: 30px;">
                                    <?php if ($facebook) : ?>
                                        <a href="<?php echo esc_url($facebook); ?>" target="_blank" style="width: 44px; height: 44px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; text-decoration: none;">📘</a>
                                    <?php endif; ?>
                                    <?php if ($instagram) : ?>
                                        <a href="<?php echo esc_url($instagram); ?>" target="_blank" style="width: 44px; height: 44px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; text-decoration: none;">📷</a>
                                    <?php endif; ?>
                                    <?php if ($twitter) : ?>
                                        <a href="<?php echo esc_url($twitter); ?>" target="_blank" style="width: 44px; height: 44px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 20px; text-decoration: none;">🐦</a>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <?php if ($map_embed) : ?>
                        <div style="margin-top: 40px;">
                            <h2 style="font-size: 1.5rem; font-weight: 700; color: #1e293b; margin: 0 0 24px;">Find Us</h2>
                            <div style="border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
                                <?php echo $map_embed; ?>
                            </div>
                        </div>
                        <style>.gas-contact-page iframe { width: 100%; height: 400px; border: none; }</style>
                        <?php endif; ?>
                    </div>
                    
                    <style>
                        @media (max-width: 768px) {
                            .gas-contact-page > div:first-child { grid-template-columns: 1fr !important; }
                        }
                    </style>
                
                <?php elseif ($special_page === 'terms') : 
                    $terms_content = get_theme_mod('developer_terms_content', '');
                ?>
                    <div class="gas-terms-page" style="font-size: 1.05rem; line-height: 1.8; color: #475569;">
                        <?php if ($terms_content) : ?>
                            <?php echo wpautop(wp_kses_post($terms_content)); ?>
                        <?php else : ?>
                            <p style="text-align: center; color: #94a3b8; padding: 40px;">Terms & Conditions content has not been set. Go to Customizer → Terms & Conditions to add content.</p>
                        <?php endif; ?>
                    </div>
                
                <?php elseif ($special_page === 'privacy') : 
                    $privacy_content = get_theme_mod('developer_privacy_content', '');
                ?>
                    <div class="gas-privacy-page" style="font-size: 1.05rem; line-height: 1.8; color: #475569;">
                        <?php if ($privacy_content) : ?>
                            <?php echo wpautop(wp_kses_post($privacy_content)); ?>
                        <?php else : ?>
                            <p style="text-align: center; color: #94a3b8; padding: 40px;">Privacy Policy content has not been set. Go to Customizer → Privacy Policy to add content.</p>
                        <?php endif; ?>
                    </div>
                
                <?php elseif ($special_page === 'blog') : ?>
                    <?php 
                    echo do_shortcode('[gas_blog_categories]');
                    echo do_shortcode('[gas_blog limit="12"]');
                    ?>
                
                <?php elseif ($special_page === 'attractions') : ?>
                    <?php 
                    echo do_shortcode('[gas_attractions_categories]');
                    echo do_shortcode('[gas_attractions]');
                    ?>
                
                <?php else : ?>
                    <?php the_content(); ?>
                <?php endif; ?>
                
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php get_footer(); ?>
