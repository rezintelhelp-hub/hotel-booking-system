<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<?php
$menu_layout = get_theme_mod('developer_menu_layout', 'logo-left');
$header_sticky = get_theme_mod('developer_header_sticky', true);
$nav_blog = get_theme_mod('developer_header_nav_blog', false);
$nav_contact = get_theme_mod('developer_header_nav_contact', true);
$nav_about = get_theme_mod('developer_header_nav_about', false);
$cta_text = get_theme_mod('developer_header_cta_text', 'Book Now');

$header_classes = 'developer-header';
$header_classes .= ' developer-menu-' . $menu_layout;
if (!$header_sticky) {
    $header_classes .= ' developer-header-static';
}
?>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="<?php echo esc_attr($header_classes); ?>">
    <div class="developer-container">
        <?php if ($menu_layout === 'logo-center') : ?>
            <!-- Logo Center Layout -->
            <div class="developer-header-inner developer-header-center">
                <nav class="developer-nav developer-nav-left">
                    <?php
                    if (has_nav_menu('primary')) {
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'container'      => false,
                            'items_wrap'     => '%3$s',
                            'walker'         => new Developer_Nav_Walker(),
                            'depth'          => 1,
                        ));
                    } else {
                        ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                        <a href="<?php echo esc_url(home_url('/book-now/')); ?>">Properties</a>
                        <a href="<?php echo esc_url(home_url('/about/')); ?>">About</a>
                        <?php
                    }
                    ?>
                </nav>
                
                <a href="<?php echo esc_url(home_url('/')); ?>" class="developer-logo">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <?php bloginfo('name'); ?>
                    <?php endif; ?>
                </a>
                
                <nav class="developer-nav developer-nav-right">
                    <?php if ($nav_blog) : ?><a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a><?php endif; ?>
                    <?php if ($nav_about) : ?><a href="<?php echo esc_url(home_url('/about/')); ?>">About</a><?php endif; ?>
                    <?php if ($nav_contact) : ?><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a><?php endif; ?>
                    <a href="<?php echo esc_url(home_url('/book-now/')); ?>" class="developer-nav-cta"><?php echo esc_html($cta_text); ?></a>
               </nav>
                
                <button class="developer-menu-toggle" aria-label="Toggle menu">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
            
        <?php elseif ($menu_layout === 'stacked') : ?>
            <!-- Stacked Layout -->
            <div class="developer-header-inner developer-header-stacked">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="developer-logo">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <?php bloginfo('name'); ?>
                    <?php endif; ?>
                </a>
                
                <button class="developer-menu-toggle" aria-label="Toggle menu">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <nav class="developer-nav developer-nav-stacked">
                    <?php
                    if (has_nav_menu('primary')) {
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'container'      => false,
                            'items_wrap'     => '%3$s',
                            'walker'         => new Developer_Nav_Walker(),
                        ));
                    } else {
                        ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                        <a href="<?php echo esc_url(home_url('/book-now/')); ?>">Properties</a>
                        <a href="<?php echo esc_url(home_url('/about/')); ?>">About</a>
                        <a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a>
                        <a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a>
                        <a href="<?php echo esc_url(home_url('/book-now/')); ?>" class="developer-nav-cta"><?php echo esc_html($cta_text); ?></a>
                        <?php
                    }
                    ?>
                </nav>
            </div>
            
        <?php else : ?>
            <!-- Default: Logo Left or Logo Right -->
            <div class="developer-header-inner <?php echo $menu_layout === 'logo-right' ? 'developer-header-reversed' : ''; ?>">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="developer-logo">
                    <?php if (has_custom_logo()) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <?php bloginfo('name'); ?>
                    <?php endif; ?>
                </a>
                
                <button class="developer-menu-toggle" aria-label="Toggle menu">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                
                <nav class="developer-nav">
                    <?php
                    if (has_nav_menu('primary')) {
                        wp_nav_menu(array(
                            'theme_location' => 'primary',
                            'container'      => false,
                            'items_wrap'     => '%3$s',
                            'walker'         => new Developer_Nav_Walker(),
                        ));
                    } else {
                        ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo is_front_page() ? 'active' : ''; ?>">Home</a>
                        <a href="<?php echo esc_url(home_url('/book-now/')); ?>">Properties</a>
                        <a href="<?php echo esc_url(home_url('/about/')); ?>">About</a>
                        <a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a>
                        <a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a>
                        <a href="<?php echo esc_url(home_url('/book-now/')); ?>" class="developer-nav-cta"><?php echo esc_html($cta_text); ?></a>
                        <?php
                    }
                    ?>
                </nav>
            </div>
        <?php endif; ?>
    </div>
</header>

<main id="main-content">
