<?php
/**
 * GAS Developer Theme Functions
 *
 * @package GAS_Developer
 */

if (!defined('ABSPATH')) exit;

define('GAS_DEVELOPER_VERSION', '1.0.0');

/**
 * Theme Activation - Auto Setup Pages & Menu
 */
function developer_theme_activation() {
    // Only run once
    if (get_option('developer_theme_setup_complete')) {
        return;
    }
    
    // Pages to create
    $pages = array(
        'home' => array(
            'title'    => 'Home',
            'content'  => '',
            'template' => '',
        ),
        'book-now' => array(
            'title'    => 'Book Now',
            'content'  => '',
            'template' => 'template-book-now.php',
        ),
        'room' => array(
            'title'    => 'Room',
            'content'  => '',
            'template' => 'template-room.php',
        ),
        'checkout' => array(
            'title'    => 'Checkout',
            'content'  => '[gas_checkout]',
            'template' => '',
        ),
        'offers' => array(
            'title'    => 'Special Offers',
            'content'  => '[gas_offers]',
            'template' => '',
        ),
        'properties' => array(
            'title'    => 'Properties',
            'content'  => '',
            'template' => 'template-book-now.php',
        ),
        'about' => array(
            'title'    => 'About',
            'content'  => '',
            'template' => '',
        ),
        'contact' => array(
            'title'    => 'Contact',
            'content'  => '',
            'template' => '',
        ),
        'terms' => array(
            'title'    => 'Terms & Conditions',
            'content'  => '',
            'template' => '',
        ),
        'privacy' => array(
            'title'    => 'Privacy Policy',
            'content'  => '',
            'template' => '',
        ),
        'blog' => array(
            'title'    => 'Blog',
            'content'  => '',
            'template' => '',
        ),
    );
    
    $created_pages = array();
    
    foreach ($pages as $slug => $page_data) {
        // Check if page already exists
        $existing = get_page_by_path($slug);
        
        if (!$existing) {
            $page_id = wp_insert_post(array(
                'post_title'     => $page_data['title'],
                'post_content'   => $page_data['content'],
                'post_status'    => 'publish',
                'post_type'      => 'page',
                'post_name'      => $slug,
                'comment_status' => 'closed',
            ));
            
            if ($page_id && !is_wp_error($page_id)) {
                // Set template if specified
                if (!empty($page_data['template'])) {
                    update_post_meta($page_id, '_wp_page_template', $page_data['template']);
                }
                $created_pages[$slug] = $page_id;
            }
        } else {
            $created_pages[$slug] = $existing->ID;
        }
    }
    
    // Set Homepage and Blog page
    if (isset($created_pages['home'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $created_pages['home']);
    }
    if (isset($created_pages['blog'])) {
        update_option('page_for_posts', $created_pages['blog']);
    }
    
    // Create Primary Menu
    $menu_name = 'Primary Menu';
    $menu_exists = wp_get_nav_menu_object($menu_name);
    
    if (!$menu_exists) {
        $menu_id = wp_create_nav_menu($menu_name);
        
        if (!is_wp_error($menu_id)) {
            // Add menu items - Rooms links to book-now page
            $menu_items = array(
                'home'       => array('title' => 'Home', 'order' => 1, 'page' => 'home'),
                'rooms'      => array('title' => 'Rooms', 'order' => 2, 'page' => 'book-now'),
                'about'      => array('title' => 'About', 'order' => 3, 'page' => 'about'),
                'blog'       => array('title' => 'Blog', 'order' => 4, 'page' => 'blog'),
                'contact'    => array('title' => 'Contact', 'order' => 5, 'page' => 'contact'),
                'book-now'   => array('title' => 'Book Now', 'order' => 6, 'page' => 'book-now'),
            );
            
            foreach ($menu_items as $slug => $item_data) {
                $page_slug = $item_data['page'];
                if (isset($created_pages[$page_slug])) {
                    wp_update_nav_menu_item($menu_id, 0, array(
                        'menu-item-title'     => $item_data['title'],
                        'menu-item-object'    => 'page',
                        'menu-item-object-id' => $created_pages[$page_slug],
                        'menu-item-type'      => 'post_type',
                        'menu-item-status'    => 'publish',
                        'menu-item-position'  => $item_data['order'],
                    ));
                }
            }
            
            // Assign menu to primary location
            $locations = get_theme_mod('nav_menu_locations');
            $locations['primary'] = $menu_id;
            set_theme_mod('nav_menu_locations', $locations);
        }
    }
    
    // Auto-configure GAS Booking plugin settings if active
    if (function_exists('is_plugin_active') || defined('GAS_BOOKING_VERSION')) {
        update_option('gas_checkout_url', '/checkout/');
        update_option('gas_offers_url', '/offers/');
        update_option('gas_room_url_base', '/room/');
        update_option('gas_search_results_url', '/book-now/');
    }
    
    // Mark setup as complete
    update_option('developer_theme_setup_complete', true);
    
    // Store created pages for reference
    update_option('developer_created_pages', $created_pages);
}
add_action('after_switch_theme', 'developer_theme_activation');

/**
 * Admin Notice after theme activation
 */
function developer_activation_notice() {
    if (get_transient('developer_activation_notice')) {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><strong>🎉 GAS Developer Theme Activated!</strong></p>
            <p>The following pages have been created automatically:</p>
            <ul style="list-style: disc; margin-left: 20px;">
                <li><strong>Home</strong> - Set as your homepage</li>
                <li><strong>Book Now</strong> - Property listings with search</li>
                <li><strong>Room</strong> - Individual room/property details</li>
                <li><strong>Checkout</strong> - Booking checkout page</li>
                <li><strong>Special Offers</strong> - Offers & promo codes showcase</li>
                <li><strong>Properties</strong> - Alternative listings page</li>
                <li><strong>About</strong> - About your property</li>
                <li><strong>Contact</strong> - Contact form page</li>
                <li><strong>Blog</strong> - Your blog posts</li>
            </ul>
            <p>A <strong>Primary Menu</strong> has also been created and assigned.</p>
            <p><a href="<?php echo admin_url('customize.php'); ?>" class="button button-primary">Customize Your Site</a> <a href="<?php echo admin_url('edit.php?post_type=page'); ?>" class="button">View Pages</a></p>
        </div>
        <?php
        delete_transient('developer_activation_notice');
    }
}
add_action('admin_notices', 'developer_activation_notice');

/**
 * Set transient on theme switch
 */
function developer_set_activation_notice() {
    set_transient('developer_activation_notice', true, 60);
}
add_action('after_switch_theme', 'developer_set_activation_notice');

/**
 * Add "Re-run Setup" option in Customizer
 */
function developer_add_setup_reset_option($wp_customize) {
    $wp_customize->add_section('developer_theme_setup', array(
        'title'    => __('🔧 Theme Setup', 'developer-developer'),
        'priority' => 1,
    ));
    
    $wp_customize->add_setting('developer_rerun_setup', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_rerun_setup', array(
        'label'       => __('Theme Auto-Setup', 'developer-developer'),
        'description' => __('Pages and menu were created automatically when the theme was activated. To re-run setup (create missing pages), switch to another theme and back to this one.', 'developer-developer'),
        'section'     => 'developer_theme_setup',
        'type'        => 'hidden',
    ));
}
add_action('customize_register', 'developer_add_setup_reset_option', 5);

/**
 * Theme Setup
 */
function developer_developer_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('customize-selective-refresh-widgets');
    
    // Register menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'developer-developer'),
        'footer'  => __('Footer Menu', 'developer-developer'),
    ));
    
    // Set thumbnail sizes
    set_post_thumbnail_size(800, 600, true);
    add_image_size('developer-hero', 1920, 1080, true);
    add_image_size('developer-card', 600, 400, true);
    add_image_size('developer-attraction', 400, 400, true);
}
add_action('after_setup_theme', 'developer_developer_setup');

/**
 * Enqueue Scripts & Styles
 */
function developer_developer_scripts() {
    // Get selected fonts
    $heading_font = get_theme_mod('developer_heading_font', 'playfair');
    $body_font = get_theme_mod('developer_body_font', 'inter');
    
    // Font name mappings for Google Fonts
    $font_names = array(
        'playfair'    => 'Playfair+Display:wght@600;700',
        'montserrat'  => 'Montserrat:wght@400;500;600;700',
        'lora'        => 'Lora:wght@400;500;600;700',
        'poppins'     => 'Poppins:wght@400;500;600;700',
        'merriweather'=> 'Merriweather:wght@400;700',
        'raleway'     => 'Raleway:wght@400;500;600;700',
        'oswald'      => 'Oswald:wght@400;500;600;700',
        'inter'       => 'Inter:wght@400;500;600;700',
        'roboto'      => 'Roboto:wght@400;500;700',
        'opensans'    => 'Open+Sans:wght@400;500;600;700',
        'lato'        => 'Lato:wght@400;700',
        'sourcesans'  => 'Source+Sans+Pro:wght@400;600;700',
        'nunito'      => 'Nunito:wght@400;500;600;700',
    );
    
    // Build Google Fonts URL
    $fonts = array();
    if (isset($font_names[$heading_font])) {
        $fonts[] = $font_names[$heading_font];
    }
    if (isset($font_names[$body_font]) && $body_font !== $heading_font) {
        $fonts[] = $font_names[$body_font];
    }
    
    if (!empty($fonts)) {
        wp_enqueue_style(
            'developer-fonts',
            'https://fonts.googleapis.com/css2?family=' . implode('&family=', $fonts) . '&display=swap',
            array(),
            null
        );
    }
    
    // Theme styles
    wp_enqueue_style(
        'developer-style',
        get_stylesheet_uri(),
        array(),
        GAS_DEVELOPER_VERSION
    );
    
    // Theme scripts
    wp_enqueue_script(
        'developer-script',
        get_template_directory_uri() . '/assets/js/main.js',
        array('jquery'),
        GAS_DEVELOPER_VERSION,
        true
    );
    
    // Pass settings to JS
    wp_localize_script('developer-script', 'developerSettings', array(
        'headerSticky' => get_theme_mod('developer_header_sticky', true),
        'menuLayout'   => get_theme_mod('developer_menu_layout', 'logo-left'),
    ));
}
add_action('wp_enqueue_scripts', 'developer_developer_scripts');

/**
 * Custom Room Selector Control for Customizer
 */
if (class_exists('WP_Customize_Control')) {
    class Developer_Room_Selector_Control extends WP_Customize_Control {
        public $type = 'room_selector';
        
        public function render_content() {
            // Get rooms from API
            $rooms = $this->get_rooms();
            $selected = explode(',', $this->value());
            ?>
            <label>
                <span class="customize-control-title"><?php echo esc_html($this->label); ?></span>
                <?php if ($this->description) : ?>
                    <span class="description customize-control-description"><?php echo esc_html($this->description); ?></span>
                <?php endif; ?>
            </label>
            
            <?php if (empty($rooms)) : ?>
                <p style="color: #666; font-style: italic; padding: 10px; background: #f5f5f5; border-radius: 4px;">
                    No rooms found. Make sure GAS Booking plugin is configured with your Client ID.
                </p>
            <?php else : ?>
                <div class="developer-room-selector" style="max-height: 250px; overflow-y: auto; border: 1px solid #ddd; border-radius: 4px; background: #fff; margin-top: 8px;">
                    <?php foreach ($rooms as $room) : 
                        $checked = in_array($room['id'], $selected) ? 'checked' : '';
                    ?>
                        <label style="display: flex; align-items: center; padding: 10px 12px; border-bottom: 1px solid #eee; cursor: pointer; transition: background 0.2s;" 
                               onmouseover="this.style.background='#f8fafc'" 
                               onmouseout="this.style.background='transparent'">
                            <input type="checkbox" 
                                   value="<?php echo esc_attr($room['id']); ?>" 
                                   <?php echo $checked; ?>
                                   style="margin-right: 10px;">
                            <span style="flex: 1;">
                                <strong style="display: block; color: #1e293b;"><?php echo esc_html($room['name']); ?></strong>
                                <small style="color: #64748b;"><?php echo esc_html($room['property_name'] ?? 'Property'); ?> • $<?php echo esc_html(number_format($room['base_price'] ?? 0)); ?>/night</small>
                            </span>
                            <span style="background: #2563eb; color: white; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 600;">ID: <?php echo esc_html($room['id']); ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" <?php $this->link(); ?> value="<?php echo esc_attr($this->value()); ?>" class="developer-room-ids-value">
                <script>
                    (function() {
                        var container = document.querySelector('.developer-room-selector');
                        var hiddenInput = container.parentElement.querySelector('.developer-room-ids-value');
                        
                        container.addEventListener('change', function(e) {
                            if (e.target.type === 'checkbox') {
                                var checked = container.querySelectorAll('input[type="checkbox"]:checked');
                                var ids = Array.from(checked).map(function(cb) { return cb.value; });
                                hiddenInput.value = ids.join(',');
                                hiddenInput.dispatchEvent(new Event('change'));
                            }
                        });
                    })();
                </script>
            <?php endif; ?>
            <?php
        }
        
        private function get_rooms() {
            $client_id = get_option('gas_client_id', '');
            if (empty($client_id)) {
                return array();
            }
            
            // Try to get cached rooms first
            $cache_key = 'developer_rooms_cache_' . $client_id;
            $rooms = get_transient($cache_key);
            
            if ($rooms === false) {
                $api_url = get_option('gas_api_url', 'https://gas-booking-production.up.railway.app');
                $response = wp_remote_get("{$api_url}/api/public/client/{$client_id}/rooms", array(
                    'timeout' => 15,
                    'sslverify' => false
                ));
                
                if (!is_wp_error($response)) {
                    $body = json_decode(wp_remote_retrieve_body($response), true);
                    $rooms = $body['rooms'] ?? array();
                    // Cache for 5 minutes
                    set_transient($cache_key, $rooms, 5 * MINUTE_IN_SECONDS);
                } else {
                    $rooms = array();
                }
            }
            
            return $rooms;
        }
    }
}

/**
 * Customizer Settings
 */
function developer_developer_customizer($wp_customize) {
    
    // ===========================================
    // GLOBAL STYLES SECTION
    // ===========================================
    $wp_customize->add_section('developer_global_styles', array(
        'title'       => __('🎨 Global Styles', 'developer-developer'),
        'description' => __('These styles apply across all pages. Use CSS for page-specific overrides.', 'developer-developer'),
        'priority'    => 24,
    ));
    
    // Primary Button Background
    $wp_customize->add_setting('developer_btn_primary_bg', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_btn_primary_bg', array(
        'label'   => __('Primary Button Background', 'developer-developer'),
        'section' => 'developer_global_styles',
    )));
    
    // Primary Button Text
    $wp_customize->add_setting('developer_btn_primary_text', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_btn_primary_text', array(
        'label'   => __('Primary Button Text', 'developer-developer'),
        'section' => 'developer_global_styles',
    )));
    
    // Secondary Button Background
    $wp_customize->add_setting('developer_btn_secondary_bg', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_btn_secondary_bg', array(
        'label'   => __('Secondary Button Background', 'developer-developer'),
        'section' => 'developer_global_styles',
    )));
    
    // Secondary Button Text
    $wp_customize->add_setting('developer_btn_secondary_text', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_btn_secondary_text', array(
        'label'   => __('Secondary Button Text', 'developer-developer'),
        'section' => 'developer_global_styles',
    )));
    
    // Page Title Size
    $wp_customize->add_setting('developer_page_title_size', array(
        'default'           => '42',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_page_title_size', array(
        'label'       => __('Page Title Size (px)', 'developer-developer'),
        'section'     => 'developer_global_styles',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 28,
            'max'  => 72,
            'step' => 2,
        ),
    ));
    
    // Body Text Size
    $wp_customize->add_setting('developer_body_text_size', array(
        'default'           => '16',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_body_text_size', array(
        'label'       => __('Body Text Size (px)', 'developer-developer'),
        'section'     => 'developer_global_styles',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 14,
            'max'  => 20,
            'step' => 1,
        ),
    ));
    
    // Button Border Radius
    $wp_customize->add_setting('developer_btn_radius', array(
        'default'           => '8',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_btn_radius', array(
        'label'       => __('Button Border Radius (px)', 'developer-developer'),
        'description' => __('0 = square, 50 = very rounded', 'developer-developer'),
        'section'     => 'developer_global_styles',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 0,
            'max'  => 50,
            'step' => 2,
        ),
    ));
    
    // Link Color
    $wp_customize->add_setting('developer_link_color', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_link_color', array(
        'label'   => __('Link Color', 'developer-developer'),
        'section' => 'developer_global_styles',
    )));
    
    // Custom CSS
    $wp_customize->add_setting('developer_custom_css', array(
        'default'           => '',
        'sanitize_callback' => 'wp_strip_all_tags',
    ));
    $wp_customize->add_control('developer_custom_css', array(
        'label'       => __('Custom CSS', 'developer-developer'),
        'description' => __('Add custom CSS for specific overrides', 'developer-developer'),
        'section'     => 'developer_global_styles',
        'type'        => 'textarea',
    ));
    
    // ===========================================
    // GLOBAL COLORS SECTION
    // ===========================================
    $wp_customize->add_section('developer_colors', array(
        'title'    => __('🎨 Colors & Branding', 'developer-developer'),
        'priority' => 25,
    ));
    
    // Primary Color
    $wp_customize->add_setting('developer_primary_color', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_primary_color', array(
        'label'   => __('Primary Color (Buttons, Links)', 'developer-developer'),
        'section' => 'developer_colors',
    )));
    
    // Secondary Color
    $wp_customize->add_setting('developer_secondary_color', array(
        'default'           => '#0f172a',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_secondary_color', array(
        'label'   => __('Secondary Color (Headers, Footer)', 'developer-developer'),
        'section' => 'developer_colors',
    )));
    
    // Accent Color
    $wp_customize->add_setting('developer_accent_color', array(
        'default'           => '#f59e0b',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_accent_color', array(
        'label'   => __('Accent Color (Stars, Highlights)', 'developer-developer'),
        'section' => 'developer_colors',
    )));
    
    // ===========================================
    // TYPOGRAPHY SECTION
    // ===========================================
    $wp_customize->add_section('developer_typography', array(
        'title'    => __('✏️ Typography', 'developer-developer'),
        'priority' => 26,
    ));
    
    // Heading Font
    $wp_customize->add_setting('developer_heading_font', array(
        'default'           => 'playfair',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_heading_font', array(
        'label'   => __('Heading Font', 'developer-developer'),
        'section' => 'developer_typography',
        'type'    => 'select',
        'choices' => array(
            'playfair'   => 'Playfair Display (Elegant)',
            'montserrat' => 'Montserrat (Modern)',
            'lora'       => 'Lora (Classic)',
            'poppins'    => 'Poppins (Clean)',
            'merriweather' => 'Merriweather (Traditional)',
            'raleway'    => 'Raleway (Light)',
            'oswald'     => 'Oswald (Bold)',
        ),
    ));
    
    // Body Font
    $wp_customize->add_setting('developer_body_font', array(
        'default'           => 'inter',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_body_font', array(
        'label'   => __('Body Font', 'developer-developer'),
        'section' => 'developer_typography',
        'type'    => 'select',
        'choices' => array(
            'inter'      => 'Inter (Modern)',
            'roboto'     => 'Roboto (Clean)',
            'opensans'   => 'Open Sans (Friendly)',
            'lato'       => 'Lato (Professional)',
            'sourcesans' => 'Source Sans Pro (Readable)',
            'nunito'     => 'Nunito (Rounded)',
        ),
    ));
    
    // ===========================================
    // HEADER & MENU SECTION
    // ===========================================
    $wp_customize->add_section('developer_header', array(
        'title'    => __('📌 Header & Menu', 'developer-developer'),
        'priority' => 27,
    ));
    
    // Menu Layout
    $wp_customize->add_setting('developer_menu_layout', array(
        'default'           => 'logo-left',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_menu_layout', array(
        'label'   => __('Menu Layout', 'developer-developer'),
        'section' => 'developer_header',
        'type'    => 'select',
        'choices' => array(
            'logo-left'   => 'Logo Left, Menu Right',
            'logo-center' => 'Logo Center, Menu Split',
            'logo-right'  => 'Logo Right, Menu Left',
            'stacked'     => 'Logo Top, Menu Below (Centered)',
        ),
    ));
    
    // Header Background Color
    $wp_customize->add_setting('developer_header_bg_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_header_bg_color', array(
        'label'   => __('Header Background Color', 'developer-developer'),
        'section' => 'developer_header',
    )));
    
    // Header Text/Link Color
    $wp_customize->add_setting('developer_header_text_color', array(
        'default'           => '#1e293b',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_header_text_color', array(
        'label'   => __('Menu Link Color', 'developer-developer'),
        'section' => 'developer_header',
    )));
    
    // Header Logo/Site Title Color
    $wp_customize->add_setting('developer_header_logo_color', array(
        'default'           => '#0f172a',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_header_logo_color', array(
        'label'   => __('Logo/Site Title Color', 'developer-developer'),
        'section' => 'developer_header',
    )));
    
    // Header CTA Button Color
    $wp_customize->add_setting('developer_header_cta_bg', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_header_cta_bg', array(
        'label'   => __('CTA Button Background', 'developer-developer'),
        'section' => 'developer_header',
    )));
    
    // Header CTA Button Text Color
    $wp_customize->add_setting('developer_header_cta_text', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_header_cta_text', array(
        'label'   => __('CTA Button Text Color', 'developer-developer'),
        'section' => 'developer_header',
    )));
    
    // Header Font
    $wp_customize->add_setting('developer_header_font', array(
        'default'           => 'inter',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_header_font', array(
        'label'   => __('Menu Font', 'developer-developer'),
        'section' => 'developer_header',
        'type'    => 'select',
        'choices' => array(
            'inter'       => 'Inter (Modern)',
            'roboto'      => 'Roboto (Clean)',
            'opensans'    => 'Open Sans (Friendly)',
            'lato'        => 'Lato (Professional)',
            'montserrat'  => 'Montserrat (Bold)',
            'poppins'     => 'Poppins (Rounded)',
            'raleway'     => 'Raleway (Elegant)',
        ),
    ));
    
    // Menu Font Size
    $wp_customize->add_setting('developer_header_font_size', array(
        'default'           => '15',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_header_font_size', array(
        'label'       => __('Menu Font Size (px)', 'developer-developer'),
        'section'     => 'developer_header',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 12,
            'max'  => 20,
            'step' => 1,
        ),
    ));
    
    // Menu Font Weight
    $wp_customize->add_setting('developer_header_font_weight', array(
        'default'           => '500',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_header_font_weight', array(
        'label'   => __('Menu Font Weight', 'developer-developer'),
        'section' => 'developer_header',
        'type'    => 'select',
        'choices' => array(
            '400' => 'Normal (400)',
            '500' => 'Medium (500)',
            '600' => 'Semi-Bold (600)',
            '700' => 'Bold (700)',
        ),
    ));
    
    // Menu Text Transform
    $wp_customize->add_setting('developer_header_text_transform', array(
        'default'           => 'none',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_header_text_transform', array(
        'label'   => __('Menu Text Style', 'developer-developer'),
        'section' => 'developer_header',
        'type'    => 'select',
        'choices' => array(
            'none'       => 'Normal',
            'uppercase'  => 'UPPERCASE',
            'capitalize' => 'Capitalize',
        ),
    ));
    
    // Header Border
    $wp_customize->add_setting('developer_header_border', array(
        'default'           => false,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('developer_header_border', array(
        'label'   => __('Show Bottom Border', 'developer-developer'),
        'section' => 'developer_header',
        'type'    => 'checkbox',
    ));
    
    // Header Border Color
    $wp_customize->add_setting('developer_header_border_color', array(
        'default'           => '#e2e8f0',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_header_border_color', array(
        'label'   => __('Border Color', 'developer-developer'),
        'section' => 'developer_header',
    )));
    
    // Header Transparency
    $wp_customize->add_setting('developer_header_transparent', array(
        'default'           => false,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('developer_header_transparent', array(
        'label'       => __('Transparent on Hero', 'developer-developer'),
        'description' => __('Header becomes transparent over hero image', 'developer-developer'),
        'section'     => 'developer_header',
        'type'        => 'checkbox',
    ));
    
    // Sticky Header
    $wp_customize->add_setting('developer_header_sticky', array(
        'default'           => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('developer_header_sticky', array(
        'label'   => __('Sticky Header on Scroll', 'developer-developer'),
        'section' => 'developer_header',
        'type'    => 'checkbox',
    ));
    
    // ===========================================
    // HERO SECTION
    // ===========================================
    $wp_customize->add_section('developer_hero', array(
        'title'    => __('🖼️ Hero Section', 'developer-developer'),
        'priority' => 30,
    ));
    
    // Hero Background Image
    $wp_customize->add_setting('developer_hero_bg', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'developer_hero_bg', array(
        'label'    => __('Hero Background Image', 'developer-developer'),
        'section'  => 'developer_hero',
    )));
    
    // Hero Background Video URL
    $wp_customize->add_setting('developer_hero_video_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('developer_hero_video_url', array(
        'label'       => __('Hero Video URL (MP4)', 'developer-developer'),
        'description' => __('Enter MP4 video URL for hero background. Leave empty to use image only.', 'developer-developer'),
        'section'     => 'developer_hero',
        'type'        => 'url',
    ));
    
    // Hero Overlay Color
    $wp_customize->add_setting('developer_hero_overlay_color', array(
        'default'           => '#0f172a',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_hero_overlay_color', array(
        'label'   => __('Overlay Color', 'developer-developer'),
        'section' => 'developer_hero',
    )));
    
    // Hero Overlay Opacity
    $wp_customize->add_setting('developer_hero_opacity', array(
        'default'           => 30,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_hero_opacity', array(
        'label'       => __('Overlay Darkness (%)', 'developer-developer'),
        'description' => __('0 = No overlay, 100 = Full dark', 'developer-developer'),
        'section'     => 'developer_hero',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 0,
            'max'  => 100,
            'step' => 5,
        ),
    ));
    
    // Hero Height
    $wp_customize->add_setting('developer_hero_height', array(
        'default'           => '90',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_hero_height', array(
        'label'       => __('Hero Height (vh)', 'developer-developer'),
        'description' => __('Percentage of screen height', 'developer-developer'),
        'section'     => 'developer_hero',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 50,
            'max'  => 100,
            'step' => 5,
        ),
    ));
    
    // Hero Badge Text
    $wp_customize->add_setting('developer_hero_badge', array(
        'default'           => 'Welcome to Paradise',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_hero_badge', array(
        'label'   => __('Hero Badge Text', 'developer-developer'),
        'section' => 'developer_hero',
        'type'    => 'text',
    ));
    
    // Hero Badge Link
    $wp_customize->add_setting('developer_hero_badge_link', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('developer_hero_badge_link', array(
        'label'       => __('Badge Link URL', 'developer-developer'),
        'description' => __('Optional - make badge clickable', 'developer-developer'),
        'section'     => 'developer_hero',
        'type'        => 'url',
    ));
    
    // Hero Badge Background Color
    $wp_customize->add_setting('developer_hero_badge_bg', array(
        'default'           => 'rgba(255,255,255,0.15)',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_hero_badge_bg', array(
        'label'       => __('Badge Background', 'developer-developer'),
        'description' => __('Use rgba for transparency, e.g. rgba(255,255,255,0.2)', 'developer-developer'),
        'section'     => 'developer_hero',
        'type'        => 'text',
    ));
    
    // Hero Badge Text Color
    $wp_customize->add_setting('developer_hero_badge_text', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_hero_badge_text', array(
        'label'   => __('Badge Text Color', 'developer-developer'),
        'section' => 'developer_hero',
    )));
    
    // Hero Badge Border Color
    $wp_customize->add_setting('developer_hero_badge_border', array(
        'default'           => 'rgba(255,255,255,0.3)',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_hero_badge_border', array(
        'label'       => __('Badge Border Color', 'developer-developer'),
        'description' => __('Use rgba for transparency', 'developer-developer'),
        'section'     => 'developer_hero',
        'type'        => 'text',
    ));
    
    // Hero Title
    $wp_customize->add_setting('developer_hero_title', array(
        'default'           => 'Find Your Perfect Vacation Rental',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_hero_title', array(
        'label'   => __('Hero Title', 'developer-developer'),
        'section' => 'developer_hero',
        'type'    => 'text',
    ));
    
    // Hero Subtitle
    $wp_customize->add_setting('developer_hero_subtitle', array(
        'default'           => 'Discover stunning vacation rentals with luxury amenities, prime locations, and unforgettable experiences.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_hero_subtitle', array(
        'label'   => __('Hero Subtitle', 'developer-developer'),
        'section' => 'developer_hero',
        'type'    => 'textarea',
    ));
    
    // Hero Trust Badge 1
    $wp_customize->add_setting('developer_hero_trust_1', array(
        'default'           => 'Instant Booking',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_hero_trust_1', array(
        'label'       => __('Trust Badge 1', 'developer-developer'),
        'description' => __('Leave empty to hide', 'developer-developer'),
        'section'     => 'developer_hero',
        'type'        => 'text',
    ));
    
    // Hero Trust Badge 2
    $wp_customize->add_setting('developer_hero_trust_2', array(
        'default'           => 'Best Price Guarantee',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_hero_trust_2', array(
        'label'   => __('Trust Badge 2', 'developer-developer'),
        'section' => 'developer_hero',
        'type'    => 'text',
    ));
    
    // Hero Trust Badge 3
    $wp_customize->add_setting('developer_hero_trust_3', array(
        'default'           => '24/7 Support',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_hero_trust_3', array(
        'label'   => __('Trust Badge 3', 'developer-developer'),
        'section' => 'developer_hero',
        'type'    => 'text',
    ));
    
    // ===========================================
    // SEARCH WIDGET SECTION
    // ===========================================
    $wp_customize->add_section('developer_search_widget', array(
        'title'    => __('🔍 Search Widget', 'developer-developer'),
        'priority' => 30,
    ));
    
    // Search Widget Background Color
    $wp_customize->add_setting('developer_search_bg', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_search_bg', array(
        'label'   => __('Widget Background Color', 'developer-developer'),
        'section' => 'developer_search_widget',
    )));
    
    // Search Widget Background Opacity
    $wp_customize->add_setting('developer_search_opacity', array(
        'default'           => 100,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_search_opacity', array(
        'label'       => __('Background Opacity (%)', 'developer-developer'),
        'description' => __('0 = Fully transparent, 100 = Solid', 'developer-developer'),
        'section'     => 'developer_search_widget',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 0,
            'max'  => 100,
            'step' => 5,
        ),
    ));
    
    // Search Widget Border Radius
    $wp_customize->add_setting('developer_search_radius', array(
        'default'           => '16',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_search_radius', array(
        'label'       => __('Corner Radius (px)', 'developer-developer'),
        'section'     => 'developer_search_widget',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 0,
            'max'  => 30,
            'step' => 2,
        ),
    ));
    
    // Search Button Color
    $wp_customize->add_setting('developer_search_btn_bg', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_search_btn_bg', array(
        'label'   => __('Search Button Color', 'developer-developer'),
        'section' => 'developer_search_widget',
    )));
    
    // Search Button Text Color
    $wp_customize->add_setting('developer_search_btn_text', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_search_btn_text', array(
        'label'   => __('Search Button Text Color', 'developer-developer'),
        'section' => 'developer_search_widget',
    )));
    
    // Text Below Search Widget
    $wp_customize->add_setting('developer_search_below_text', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_search_below_text', array(
        'label'       => __('Text Below Search', 'developer-developer'),
        'description' => __('Additional message shown below the search widget', 'developer-developer'),
        'section'     => 'developer_search_widget',
        'type'        => 'textarea',
    ));
    
    // Search Widget Max Width
    $wp_customize->add_setting('developer_search_max_width', array(
        'default'           => '900',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_search_max_width', array(
        'label'       => __('Max Width (px)', 'developer-developer'),
        'description' => __('Maximum width of the search widget', 'developer-developer'),
        'section'     => 'developer_search_widget',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 500,
            'max'  => 1200,
            'step' => 50,
        ),
    ));
    
    // Search Widget Scale
    $wp_customize->add_setting('developer_search_scale', array(
        'default'           => '100',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_search_scale', array(
        'label'       => __('Size Scale (%)', 'developer-developer'),
        'description' => __('Scale the search widget size (100 = normal)', 'developer-developer'),
        'section'     => 'developer_search_widget',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 70,
            'max'  => 120,
            'step' => 5,
        ),
    ));
    
    // ===========================================
    // INTRO SECTION (between hero and featured)
    // ===========================================
    $wp_customize->add_section('developer_intro', array(
        'title'       => __('📝 Intro Section', 'developer-developer'),
        'description' => __('Optional section between hero and featured properties', 'developer-developer'),
        'priority'    => 30,
    ));
    
    // Enable Intro Section
    $wp_customize->add_setting('developer_intro_enabled', array(
        'default'           => true,
        'sanitize_callback' => 'wp_validate_boolean',
        'transport'         => 'refresh',
    ));
    $wp_customize->add_control('developer_intro_enabled', array(
        'label'   => __('Enable Intro Section', 'developer-developer'),
        'section' => 'developer_intro',
        'type'    => 'checkbox',
    ));
    
    // Intro Background Color
    $wp_customize->add_setting('developer_intro_bg', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_intro_bg', array(
        'label'   => __('Background Color', 'developer-developer'),
        'section' => 'developer_intro',
    )));
    
    // Intro Text Color
    $wp_customize->add_setting('developer_intro_text_color', array(
        'default'           => '#1e293b',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_intro_text_color', array(
        'label'   => __('Text Color', 'developer-developer'),
        'section' => 'developer_intro',
    )));
    
    // Intro Title
    $wp_customize->add_setting('developer_intro_title', array(
        'default'           => 'Welcome to Our Property',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_intro_title', array(
        'label'   => __('Title', 'developer-developer'),
        'section' => 'developer_intro',
        'type'    => 'text',
    ));
    
    // Intro Title Font Size
    $wp_customize->add_setting('developer_intro_title_size', array(
        'default'           => '36',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_intro_title_size', array(
        'label'       => __('Title Font Size (px)', 'developer-developer'),
        'section'     => 'developer_intro',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 20,
            'max'  => 60,
            'step' => 2,
        ),
    ));
    
    // Intro Text
    $wp_customize->add_setting('developer_intro_text', array(
        'default'           => 'We are delighted to have you here. Explore our beautiful accommodations and find your perfect stay.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_intro_text', array(
        'label'   => __('Text', 'developer-developer'),
        'section' => 'developer_intro',
        'type'    => 'textarea',
    ));
    
    // Intro Text Font Size
    $wp_customize->add_setting('developer_intro_text_size', array(
        'default'           => '18',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_intro_text_size', array(
        'label'       => __('Text Font Size (px)', 'developer-developer'),
        'section'     => 'developer_intro',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 14,
            'max'  => 24,
            'step' => 1,
        ),
    ));
    
    // Intro Max Width
    $wp_customize->add_setting('developer_intro_max_width', array(
        'default'           => '800',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_intro_max_width', array(
        'label'       => __('Content Max Width (px)', 'developer-developer'),
        'description' => __('Controls how wide the text spreads', 'developer-developer'),
        'section'     => 'developer_intro',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 600,
            'max'  => 1200,
            'step' => 50,
        ),
    ));
    
    // Intro Button Text
    $wp_customize->add_setting('developer_intro_btn_text', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_intro_btn_text', array(
        'label'       => __('Button Text', 'developer-developer'),
        'description' => __('Leave empty to hide button', 'developer-developer'),
        'section'     => 'developer_intro',
        'type'        => 'text',
    ));
    
    // Intro Button URL
    $wp_customize->add_setting('developer_intro_btn_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('developer_intro_btn_url', array(
        'label'   => __('Button URL', 'developer-developer'),
        'section' => 'developer_intro',
        'type'    => 'url',
    ));
    
    // Intro Button Background Color
    $wp_customize->add_setting('developer_intro_btn_bg', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_intro_btn_bg', array(
        'label'   => __('Button Background Color', 'developer-developer'),
        'section' => 'developer_intro',
    )));
    
    // Intro Button Text Color
    $wp_customize->add_setting('developer_intro_btn_text_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_intro_btn_text_color', array(
        'label'   => __('Button Text Color', 'developer-developer'),
        'section' => 'developer_intro',
    )));
    
    // ===========================================
    // FEATURED PROPERTIES SECTION
    // ===========================================
    $wp_customize->add_section('developer_featured_props', array(
        'title'       => __('🏠 Featured Properties', 'developer-developer'),
        'priority'    => 31,
    ));
    
    // Featured Display Mode
    $wp_customize->add_setting('developer_featured_mode', array(
        'default'           => 'all',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_featured_mode', array(
        'label'   => __('Display Mode', 'developer-developer'),
        'section' => 'developer_featured_props',
        'type'    => 'select',
        'choices' => array(
            'all'      => 'Show All Properties',
            'random'   => 'Random Selection',
            'specific' => 'Specific Rooms (select below)',
        ),
    ));
    
    // Number of Featured Properties (for random)
    $wp_customize->add_setting('developer_featured_count', array(
        'default'           => 3,
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_featured_count', array(
        'label'       => __('Number to Show', 'developer-developer'),
        'description' => __('For "Random" or "All" mode', 'developer-developer'),
        'section'     => 'developer_featured_props',
        'type'        => 'number',
        'input_attrs' => array(
            'min' => 1,
            'max' => 12,
        ),
    ));
    
    // Room Selector (custom control)
    $wp_customize->add_setting('developer_featured_ids', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control(new Developer_Room_Selector_Control($wp_customize, 'developer_featured_ids', array(
        'label'       => __('Select Rooms to Feature', 'developer-developer'),
        'description' => __('Check the rooms you want to display (for "Specific Rooms" mode)', 'developer-developer'),
        'section'     => 'developer_featured_props',
    )));
    
    // Featured Section Title
    $wp_customize->add_setting('developer_featured_title', array(
        'default'           => 'Featured Properties',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_featured_title', array(
        'label'   => __('Section Title', 'developer-developer'),
        'section' => 'developer_featured_props',
        'type'    => 'text',
    ));
    
    // Featured Section Subtitle
    $wp_customize->add_setting('developer_featured_subtitle', array(
        'default'           => 'Discover our handpicked selection of stunning vacation rentals, each offering unique experiences and exceptional comfort.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_featured_subtitle', array(
        'label'   => __('Section Subtitle', 'developer-developer'),
        'section' => 'developer_featured_props',
        'type'    => 'textarea',
    ));
    
    // Featured Button Text
    $wp_customize->add_setting('developer_featured_btn_text', array(
        'default'           => 'View All Properties',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_featured_btn_text', array(
        'label'       => __('Button Text', 'developer-developer'),
        'description' => __('Leave empty to hide button', 'developer-developer'),
        'section'     => 'developer_featured_props',
        'type'        => 'text',
    ));
    
    // Featured Button URL
    $wp_customize->add_setting('developer_featured_btn_url', array(
        'default'           => '/book-now/',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_featured_btn_url', array(
        'label'   => __('Button URL', 'developer-developer'),
        'section' => 'developer_featured_props',
        'type'    => 'text',
    ));
    
    // Featured Button Background Color
    $wp_customize->add_setting('developer_featured_btn_bg', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_featured_btn_bg', array(
        'label'   => __('Button Background Color', 'developer-developer'),
        'section' => 'developer_featured_props',
    )));
    
    // Featured Button Text Color
    $wp_customize->add_setting('developer_featured_btn_text_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_featured_btn_text_color', array(
        'label'   => __('Button Text Color', 'developer-developer'),
        'section' => 'developer_featured_props',
    )));
    
    // ===========================================
    // SECTIONS BACKGROUNDS
    // ===========================================
    $wp_customize->add_section('developer_sections', array(
        'title'    => __('📦 Section Backgrounds', 'developer-developer'),
        'priority' => 32,
    ));
    
    // Featured Section Background
    $wp_customize->add_setting('developer_featured_bg', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_featured_bg', array(
        'label'   => __('Featured Properties Background', 'developer-developer'),
        'section' => 'developer_sections',
    )));
    
    // About Section Background
    $wp_customize->add_setting('developer_about_bg', array(
        'default'           => '#f8fafc',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_about_bg', array(
        'label'   => __('About Section Background', 'developer-developer'),
        'section' => 'developer_sections',
    )));
    
    // Testimonials Background
    $wp_customize->add_setting('developer_testimonials_bg', array(
        'default'           => '#0f172a',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_testimonials_bg', array(
        'label'   => __('Testimonials Background', 'developer-developer'),
        'section' => 'developer_sections',
    )));
    
    // CTA Background (keeping for backwards compatibility)
    $wp_customize->add_setting('developer_cta_bg', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_cta_bg', array(
        'label'   => __('CTA Section Background', 'developer-developer'),
        'section' => 'developer_sections',
    )));
    
    // ===========================================
    // CTA SECTION
    // ===========================================
    $wp_customize->add_section('developer_cta', array(
        'title'       => __('📢 CTA Section', 'developer-developer'),
        'description' => __('Call-to-action banner above the footer', 'developer-developer'),
        'priority'    => 36,
    ));
    
    // Enable CTA Section
    $wp_customize->add_setting('developer_cta_enabled', array(
        'default'           => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('developer_cta_enabled', array(
        'label'   => __('Enable CTA Section', 'developer-developer'),
        'section' => 'developer_cta',
        'type'    => 'checkbox',
    ));
    
    // CTA Title
    $wp_customize->add_setting('developer_cta_title', array(
        'default'           => 'Ready to Book Your Stay?',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_cta_title', array(
        'label'   => __('Title', 'developer-developer'),
        'section' => 'developer_cta',
        'type'    => 'text',
    ));
    
    // CTA Title Font Size
    $wp_customize->add_setting('developer_cta_title_size', array(
        'default'           => '36',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_cta_title_size', array(
        'label'       => __('Title Font Size (px)', 'developer-developer'),
        'section'     => 'developer_cta',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 24,
            'max'  => 60,
            'step' => 2,
        ),
    ));
    
    // CTA Text
    $wp_customize->add_setting('developer_cta_text', array(
        'default'           => 'Find your perfect vacation rental today and create memories that last a lifetime.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_cta_text', array(
        'label'   => __('Text', 'developer-developer'),
        'section' => 'developer_cta',
        'type'    => 'textarea',
    ));
    
    // CTA Text Font Size
    $wp_customize->add_setting('developer_cta_text_size', array(
        'default'           => '18',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_cta_text_size', array(
        'label'       => __('Text Font Size (px)', 'developer-developer'),
        'section'     => 'developer_cta',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 14,
            'max'  => 24,
            'step' => 1,
        ),
    ));
    
    // CTA Background Color
    $wp_customize->add_setting('developer_cta_background', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_cta_background', array(
        'label'   => __('Background Color', 'developer-developer'),
        'section' => 'developer_cta',
    )));
    
    // CTA Text Color
    $wp_customize->add_setting('developer_cta_text_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_cta_text_color', array(
        'label'   => __('Text Color', 'developer-developer'),
        'section' => 'developer_cta',
    )));
    
    // CTA Button Text
    $wp_customize->add_setting('developer_cta_btn_text', array(
        'default'           => 'Browse Properties',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_cta_btn_text', array(
        'label'       => __('Button Text', 'developer-developer'),
        'description' => __('Leave empty to hide button', 'developer-developer'),
        'section'     => 'developer_cta',
        'type'        => 'text',
    ));
    
    // CTA Button URL
    $wp_customize->add_setting('developer_cta_btn_url', array(
        'default'           => '/book-now/',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_cta_btn_url', array(
        'label'   => __('Button URL', 'developer-developer'),
        'section' => 'developer_cta',
        'type'    => 'text',
    ));
    
    // CTA Button Background Color
    $wp_customize->add_setting('developer_cta_btn_bg', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_cta_btn_bg', array(
        'label'   => __('Button Background Color', 'developer-developer'),
        'section' => 'developer_cta',
    )));
    
    // CTA Button Text Color
    $wp_customize->add_setting('developer_cta_btn_text_color', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_cta_btn_text_color', array(
        'label'   => __('Button Text Color', 'developer-developer'),
        'section' => 'developer_cta',
    )));
    
    // ===========================================
    // REVIEWS SECTION
    // ===========================================
    $wp_customize->add_section('developer_reviews', array(
        'title'       => __('⭐ Reviews Section', 'developer-developer'),
        'description' => __('Display reviews from TripAdvisor, Booking.com, Google and more', 'developer-developer'),
        'priority'    => 34,
    ));
    
    // Enable Reviews Section
    $wp_customize->add_setting('developer_reviews_enabled', array(
        'default'           => false,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('developer_reviews_enabled', array(
        'label'   => __('Enable Reviews Section', 'developer-developer'),
        'section' => 'developer_reviews',
        'type'    => 'checkbox',
    ));
    
    // Reviews Section Title
    $wp_customize->add_setting('developer_reviews_title', array(
        'default'           => 'What Our Guests Say',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_reviews_title', array(
        'label'   => __('Section Title', 'developer-developer'),
        'section' => 'developer_reviews',
        'type'    => 'text',
    ));
    
    // Reviews Section Subtitle
    $wp_customize->add_setting('developer_reviews_subtitle', array(
        'default'           => 'Real reviews from real guests across all platforms',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_reviews_subtitle', array(
        'label'   => __('Section Subtitle', 'developer-developer'),
        'section' => 'developer_reviews',
        'type'    => 'text',
    ));
    
    // Reviews Background Color
    $wp_customize->add_setting('developer_reviews_bg', array(
        'default'           => '#0f172a',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_reviews_bg', array(
        'label'   => __('Background Color', 'developer-developer'),
        'section' => 'developer_reviews',
    )));
    
    // Reviews Text Color
    $wp_customize->add_setting('developer_reviews_text_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_reviews_text_color', array(
        'label'   => __('Text Color', 'developer-developer'),
        'section' => 'developer_reviews',
    )));
    
    // Reviews Display Style
    $wp_customize->add_setting('developer_reviews_style', array(
        'default'           => 'slider',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_reviews_style', array(
        'label'   => __('Display Style', 'developer-developer'),
        'section' => 'developer_reviews',
        'type'    => 'select',
        'choices' => array(
            'slider'  => __('Slider (Auto-scrolling testimonials)', 'developer-developer'),
            'grid'    => __('Grid (Review cards)', 'developer-developer'),
            'badges'  => __('Badges Only (Rating scores)', 'developer-developer'),
            'summary' => __('Summary (Overall rating)', 'developer-developer'),
        ),
    ));
    
    // Number of Reviews (for grid)
    $wp_customize->add_setting('developer_reviews_limit', array(
        'default'           => '6',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_reviews_limit', array(
        'label'       => __('Number of Reviews', 'developer-developer'),
        'description' => __('For Grid style only', 'developer-developer'),
        'section'     => 'developer_reviews',
        'type'        => 'select',
        'choices'     => array(
            '3' => '3',
            '6' => '6',
            '9' => '9',
            '12' => '12',
        ),
    ));
    
    // ===========================================
    // ABOUT SECTION
    // ===========================================
    $wp_customize->add_section('developer_about', array(
        'title'    => __('ℹ️ About Section', 'developer-developer'),
        'priority' => 35,
    ));
    
    // About Image
    $wp_customize->add_setting('developer_about_image', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'developer_about_image', array(
        'label'   => __('About Image', 'developer-developer'),
        'section' => 'developer_about',
    )));
    
    // About Title
    $wp_customize->add_setting('developer_about_title', array(
        'default'           => 'Experience Luxury & Comfort',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_title', array(
        'label'   => __('About Title', 'developer-developer'),
        'section' => 'developer_about',
        'type'    => 'text',
    ));
    
    // About Text
    $wp_customize->add_setting('developer_about_text', array(
        'default'           => 'Our carefully curated collection of vacation rentals offers the perfect blend of luxury, comfort, and convenience. Whether you\'re planning a family reunion, a getaway with friends, or a romantic escape, we have the ideal property for you.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_about_text', array(
        'label'   => __('About Text', 'developer-developer'),
        'section' => 'developer_about',
        'type'    => 'textarea',
    ));
    
    // About Layout
    $wp_customize->add_setting('developer_about_layout', array(
        'default'           => 'image-left',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_layout', array(
        'label'   => __('About Layout', 'developer-developer'),
        'section' => 'developer_about',
        'type'    => 'select',
        'choices' => array(
            'image-left'  => 'Image Left, Text Right',
            'image-right' => 'Image Right, Text Left',
            'image-top'   => 'Image Top, Text Below',
        ),
    ));
    
    // About Button Text
    $wp_customize->add_setting('developer_about_btn_text', array(
        'default'           => 'Learn More',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_btn_text', array(
        'label'       => __('Button Text', 'developer-developer'),
        'description' => __('Leave empty to hide button', 'developer-developer'),
        'section'     => 'developer_about',
        'type'        => 'text',
    ));
    
    // About Button URL
    $wp_customize->add_setting('developer_about_btn_url', array(
        'default'           => '/about/',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_btn_url', array(
        'label'   => __('Button URL', 'developer-developer'),
        'section' => 'developer_about',
        'type'    => 'text',
    ));
    
    // About Button Background Color
    $wp_customize->add_setting('developer_about_btn_bg', array(
        'default'           => '#2563eb',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_about_btn_bg', array(
        'label'   => __('Button Background Color', 'developer-developer'),
        'section' => 'developer_about',
    )));
    
    // About Button Text Color
    $wp_customize->add_setting('developer_about_btn_text_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_about_btn_text_color', array(
        'label'   => __('Button Text Color', 'developer-developer'),
        'section' => 'developer_about',
    )));
    
    // About Title Font Size
    $wp_customize->add_setting('developer_about_title_size', array(
        'default'           => '36',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_about_title_size', array(
        'label'       => __('Title Font Size (px)', 'developer-developer'),
        'section'     => 'developer_about',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 24,
            'max'  => 60,
            'step' => 2,
        ),
    ));
    
    // About Text Font Size
    $wp_customize->add_setting('developer_about_text_size', array(
        'default'           => '16',
        'sanitize_callback' => 'absint',
    ));
    $wp_customize->add_control('developer_about_text_size', array(
        'label'       => __('Text Font Size (px)', 'developer-developer'),
        'section'     => 'developer_about',
        'type'        => 'range',
        'input_attrs' => array(
            'min'  => 14,
            'max'  => 22,
            'step' => 1,
        ),
    ));
    
    // About Feature 1
    $wp_customize->add_setting('developer_about_feature_1', array(
        'default'           => 'Spacious Bedrooms',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_feature_1', array(
        'label'       => __('Feature 1', 'developer-developer'),
        'description' => __('Leave empty to hide', 'developer-developer'),
        'section'     => 'developer_about',
        'type'        => 'text',
    ));
    
    // About Feature 2
    $wp_customize->add_setting('developer_about_feature_2', array(
        'default'           => 'Luxury Bathrooms',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_feature_2', array(
        'label'   => __('Feature 2', 'developer-developer'),
        'section' => 'developer_about',
        'type'    => 'text',
    ));
    
    // About Feature 3
    $wp_customize->add_setting('developer_about_feature_3', array(
        'default'           => 'Prime Locations',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_feature_3', array(
        'label'   => __('Feature 3', 'developer-developer'),
        'section' => 'developer_about',
        'type'    => 'text',
    ));
    
    // About Feature 4
    $wp_customize->add_setting('developer_about_feature_4', array(
        'default'           => 'Full Amenities',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_feature_4', array(
        'label'   => __('Feature 4', 'developer-developer'),
        'section' => 'developer_about',
        'type'    => 'text',
    ));
    
    // About Feature 5
    $wp_customize->add_setting('developer_about_feature_5', array(
        'default'           => 'Entertainment Areas',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_feature_5', array(
        'label'   => __('Feature 5', 'developer-developer'),
        'section' => 'developer_about',
        'type'    => 'text',
    ));
    
    // About Feature 6
    $wp_customize->add_setting('developer_about_feature_6', array(
        'default'           => 'Private Parking',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_feature_6', array(
        'label'   => __('Feature 6', 'developer-developer'),
        'section' => 'developer_about',
        'type'    => 'text',
    ));
    
    // ===========================================
    // FOOTER SECTION
    // ===========================================
    $wp_customize->add_section('developer_footer', array(
        'title'    => __('👣 Footer', 'developer-developer'),
        'priority' => 38,
    ));
    
    // Footer Background
    $wp_customize->add_setting('developer_footer_bg', array(
        'default'           => '#0f172a',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_footer_bg', array(
        'label'   => __('Footer Background', 'developer-developer'),
        'section' => 'developer_footer',
    )));
    
    // Footer Text Color
    $wp_customize->add_setting('developer_footer_text', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'developer_footer_text', array(
        'label'   => __('Footer Text Color', 'developer-developer'),
        'section' => 'developer_footer',
    )));
    
    // Footer Layout
    $wp_customize->add_setting('developer_footer_layout', array(
        'default'           => '4-columns',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_footer_layout', array(
        'label'   => __('Footer Layout', 'developer-developer'),
        'section' => 'developer_footer',
        'type'    => 'select',
        'choices' => array(
            '4-columns' => '4 Columns',
            '3-columns' => '3 Columns',
            '2-columns' => '2 Columns',
            'centered'  => 'Centered Simple',
        ),
    ));
    
    // ===========================================
    // CONTACT INFO SECTION
    // ===========================================
    $wp_customize->add_section('developer_contact', array(
        'title'    => __('📞 Contact Info', 'developer-developer'),
        'priority' => 40,
    ));
    
    // Email
    $wp_customize->add_setting('developer_email', array(
        'default'           => 'hello@example.com',
        'sanitize_callback' => 'sanitize_email',
    ));
    $wp_customize->add_control('developer_email', array(
        'label'   => __('Email Address', 'developer-developer'),
        'section' => 'developer_contact',
        'type'    => 'email',
    ));
    
    // Phone
    $wp_customize->add_setting('developer_phone', array(
        'default'           => '+1 (555) 123-4567',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_phone', array(
        'label'   => __('Phone Number', 'developer-developer'),
        'section' => 'developer_contact',
        'type'    => 'text',
    ));
    
    // Address
    $wp_customize->add_setting('developer_address', array(
        'default'           => '123 Main Street, City, State 12345',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_address', array(
        'label'   => __('Address', 'developer-developer'),
        'section' => 'developer_contact',
        'type'    => 'textarea',
    ));
    
    // ===========================================
    // ABOUT PAGE SECTION (Full Page Content)
    // ===========================================
    $wp_customize->add_section('developer_about_page', array(
        'title'       => __('📄 About Page', 'developer-developer'),
        'description' => __('Content for the About Us page. Create a page with slug "about" to use this.', 'developer-developer'),
        'priority'    => 41,
    ));
    
    // Our Story
    $wp_customize->add_setting('developer_about_page_story', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('developer_about_page_story', array(
        'label'       => __('Our Story', 'developer-developer'),
        'description' => __('Tell your story - why you started, what makes you special', 'developer-developer'),
        'section'     => 'developer_about_page',
        'type'        => 'textarea',
    ));
    
    // History
    $wp_customize->add_setting('developer_about_page_history', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('developer_about_page_history', array(
        'label'       => __('History', 'developer-developer'),
        'description' => __('Building history, renovations, significance', 'developer-developer'),
        'section'     => 'developer_about_page',
        'type'        => 'textarea',
    ));
    
    // Host Name
    $wp_customize->add_setting('developer_about_page_host_name', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_page_host_name', array(
        'label'   => __('Host/Owner Name', 'developer-developer'),
        'section' => 'developer_about_page',
        'type'    => 'text',
    ));
    
    // Host Title
    $wp_customize->add_setting('developer_about_page_host_title', array(
        'default'           => 'Owner & Host',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('developer_about_page_host_title', array(
        'label'   => __('Host Title', 'developer-developer'),
        'section' => 'developer_about_page',
        'type'    => 'text',
    ));
    
    // Host Bio
    $wp_customize->add_setting('developer_about_page_host_bio', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_about_page_host_bio', array(
        'label'   => __('Host Bio', 'developer-developer'),
        'section' => 'developer_about_page',
        'type'    => 'textarea',
    ));
    
    // Host Image
    $wp_customize->add_setting('developer_about_page_host_image', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'developer_about_page_host_image', array(
        'label'   => __('Host Photo', 'developer-developer'),
        'section' => 'developer_about_page',
    )));
    
    // Values (one per line: emoji|title|description)
    $wp_customize->add_setting('developer_about_page_values', array(
        'default'           => "🏠|Warm Hospitality|We treat every guest like family\n🌟|Attention to Detail|Every corner is thoughtfully designed\n🍳|Gourmet Breakfast|Start your day with a homemade feast\n📍|Perfect Location|Steps away from the best attractions",
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_about_page_values', array(
        'label'       => __('Values/Features', 'developer-developer'),
        'description' => __('One per line: emoji|title|description', 'developer-developer'),
        'section'     => 'developer_about_page',
        'type'        => 'textarea',
    ));
    
    // Amenities (one per line)
    $wp_customize->add_setting('developer_about_page_amenities', array(
        'default'           => "Free WiFi\nFree Parking\nGourmet Breakfast\nAir Conditioning\nPrivate Bathrooms\nGarden Access",
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_about_page_amenities', array(
        'label'       => __('Amenities List', 'developer-developer'),
        'description' => __('One amenity per line', 'developer-developer'),
        'section'     => 'developer_about_page',
        'type'        => 'textarea',
    ));
    
    // ===========================================
    // CONTACT PAGE SECTION (Full Page Content)
    // ===========================================
    $wp_customize->add_section('developer_contact_page', array(
        'title'       => __('📄 Contact Page', 'developer-developer'),
        'description' => __('Content for the Contact page. Create a page with slug "contact" to use this.', 'developer-developer'),
        'priority'    => 42,
    ));
    
    // Google Maps Embed
    $wp_customize->add_setting('developer_contact_page_map', array(
        'default'           => '',
        'sanitize_callback' => 'developer_sanitize_html',
    ));
    $wp_customize->add_control('developer_contact_page_map', array(
        'label'       => __('Google Maps Embed Code', 'developer-developer'),
        'description' => __('Paste iframe from Google Maps > Share > Embed', 'developer-developer'),
        'section'     => 'developer_contact_page',
        'type'        => 'textarea',
    ));
    
    // Google Maps Link
    $wp_customize->add_setting('developer_contact_page_map_link', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('developer_contact_page_map_link', array(
        'label'       => __('Google Maps Link', 'developer-developer'),
        'description' => __('Direct link to your location', 'developer-developer'),
        'section'     => 'developer_contact_page',
        'type'        => 'url',
    ));
    
    // Business Hours
    $wp_customize->add_setting('developer_contact_page_hours', array(
        'default'           => "Check-in: 3:00 PM - 8:00 PM\nCheck-out: by 11:00 AM\nOffice: 8:00 AM - 10:00 PM",
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_contact_page_hours', array(
        'label'   => __('Business Hours', 'developer-developer'),
        'section' => 'developer_contact_page',
        'type'    => 'textarea',
    ));
    
    // Contact Form Intro
    $wp_customize->add_setting('developer_contact_page_form_intro', array(
        'default'           => "Have a question or want to make a reservation? We'd love to hear from you!",
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('developer_contact_page_form_intro', array(
        'label'   => __('Form Intro Text', 'developer-developer'),
        'section' => 'developer_contact_page',
        'type'    => 'textarea',
    ));
    
    // ===========================================
    // TERMS PAGE SECTION
    // ===========================================
    $wp_customize->add_section('developer_terms_page', array(
        'title'       => __('📄 Terms & Conditions', 'developer-developer'),
        'description' => __('Content for Terms page. Create a page with slug "terms" to use this.', 'developer-developer'),
        'priority'    => 43,
    ));
    
    // Terms Content
    $wp_customize->add_setting('developer_terms_content', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('developer_terms_content', array(
        'label'       => __('Terms & Conditions', 'developer-developer'),
        'description' => __('Your full terms and conditions text', 'developer-developer'),
        'section'     => 'developer_terms_page',
        'type'        => 'textarea',
    ));
    
    // ===========================================
    // PRIVACY PAGE SECTION
    // ===========================================
    $wp_customize->add_section('developer_privacy_page', array(
        'title'       => __('📄 Privacy Policy', 'developer-developer'),
        'description' => __('Content for Privacy page. Create a page with slug "privacy" to use this.', 'developer-developer'),
        'priority'    => 44,
    ));
    
    // Privacy Content
    $wp_customize->add_setting('developer_privacy_content', array(
        'default'           => '',
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('developer_privacy_content', array(
        'label'       => __('Privacy Policy', 'developer-developer'),
        'description' => __('Your full privacy policy text', 'developer-developer'),
        'section'     => 'developer_privacy_page',
        'type'        => 'textarea',
    ));
    
    // ===========================================
    // SOCIAL LINKS SECTION
    // ===========================================
    $wp_customize->add_section('developer_social', array(
        'title'    => __('🔗 Social Media', 'developer-developer'),
        'priority' => 45,
    ));
    
    $social_networks = array('facebook', 'instagram', 'twitter', 'youtube', 'tiktok', 'linkedin');
    foreach ($social_networks as $network) {
        $wp_customize->add_setting('developer_social_' . $network, array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control('developer_social_' . $network, array(
            'label'   => ucfirst($network) . ' URL',
            'section' => 'developer_social',
            'type'    => 'url',
        ));
    }
}
add_action('customize_register', 'developer_developer_customizer');

/**
 * Sanitize HTML for widget embed codes
 * Only admins can access customizer, so we allow unfiltered HTML
 */
function developer_sanitize_html($input) {
    // Allow unfiltered HTML for widget embed codes (admin only)
    if (current_user_can('unfiltered_html')) {
        return $input;
    }
    return wp_kses_post($input);
}

/**
 * Output Custom CSS from Customizer
 */
function developer_developer_custom_css() {
    // Colors - DARK THEME DEFAULTS
    $primary = get_theme_mod('developer_primary_color', '#6366f1');
    $secondary = get_theme_mod('developer_secondary_color', '#f8fafc');
    $accent = get_theme_mod('developer_accent_color', '#f59e0b');
    
    // Global Styles - DARK THEME DEFAULTS
    $btn_primary_bg = get_theme_mod('developer_btn_primary_bg', '#6366f1');
    $btn_primary_text = get_theme_mod('developer_btn_primary_text', '#ffffff');
    $btn_secondary_bg = get_theme_mod('developer_btn_secondary_bg', '#1e293b');
    $btn_secondary_text = get_theme_mod('developer_btn_secondary_text', '#e2e8f0');
    $page_title_size = get_theme_mod('developer_page_title_size', '42');
    $body_text_size = get_theme_mod('developer_body_text_size', '16');
    $btn_radius = get_theme_mod('developer_btn_radius', '8');
    $link_color = get_theme_mod('developer_link_color', '#818cf8');
    $custom_css = get_theme_mod('developer_custom_css', '');
    
    // Header - DARK THEME DEFAULTS
    $header_bg = get_theme_mod('developer_header_bg_color', '#0f172a');
    $header_text = get_theme_mod('developer_header_text_color', '#e2e8f0');
    $header_logo = get_theme_mod('developer_header_logo_color', '#f8fafc');
    $header_cta_bg = get_theme_mod('developer_header_cta_bg', '#6366f1');
    $header_cta_text = get_theme_mod('developer_header_cta_text', '#ffffff');
    $header_font = get_theme_mod('developer_header_font', 'inter');
    $header_font_size = get_theme_mod('developer_header_font_size', '15');
    $header_font_weight = get_theme_mod('developer_header_font_weight', '500');
    $header_text_transform = get_theme_mod('developer_header_text_transform', 'none');
    $header_transparent = get_theme_mod('developer_header_transparent', false);
    
    // Section backgrounds - DARK THEME DEFAULTS
    $featured_bg = get_theme_mod('developer_featured_bg', '#0f172a');
    $about_bg = get_theme_mod('developer_about_bg', '#1e293b');
    $testimonials_bg = get_theme_mod('developer_testimonials_bg', '#1e293b');
    $cta_bg = get_theme_mod('developer_cta_bg', '#6366f1');
    
    // Footer - DARK THEME DEFAULTS
    $footer_bg = get_theme_mod('developer_footer_bg', '#020617');
    $footer_text = get_theme_mod('developer_footer_text', '#e2e8f0');
    
    // Fonts
    $heading_font = get_theme_mod('developer_heading_font', 'playfair');
    $body_font = get_theme_mod('developer_body_font', 'inter');
    
    // Hero
    $hero_height = get_theme_mod('developer_hero_height', '90');
    
    // Font mappings
    $font_families = array(
        'playfair'    => "'Playfair Display', Georgia, serif",
        'montserrat'  => "'Montserrat', sans-serif",
        'lora'        => "'Lora', Georgia, serif",
        'poppins'     => "'Poppins', sans-serif",
        'merriweather'=> "'Merriweather', Georgia, serif",
        'raleway'     => "'Raleway', sans-serif",
        'oswald'      => "'Oswald', sans-serif",
        'inter'       => "'Inter', sans-serif",
        'roboto'      => "'Roboto', sans-serif",
        'opensans'    => "'Open Sans', sans-serif",
        'lato'        => "'Lato', sans-serif",
        'sourcesans'  => "'Source Sans Pro', sans-serif",
        'nunito'      => "'Nunito', sans-serif",
    );
    
    $heading_family = isset($font_families[$heading_font]) ? $font_families[$heading_font] : $font_families['playfair'];
    $body_family = isset($font_families[$body_font]) ? $font_families[$body_font] : $font_families['inter'];
    $header_family = isset($font_families[$header_font]) ? $font_families[$header_font] : $font_families['inter'];
    
    echo '<style id="developer-custom-css">
        :root {
            --developer-primary: ' . esc_attr($primary) . ';
            --developer-primary-dark: ' . esc_attr(developer_adjust_brightness($primary, -20)) . ';
            --developer-secondary: ' . esc_attr($secondary) . ';
            --developer-accent: ' . esc_attr($accent) . ';
            --developer-font-display: ' . $heading_family . ';
            --developer-font: ' . $body_family . ';
            --developer-btn-primary-bg: ' . esc_attr($btn_primary_bg) . ';
            --developer-btn-primary-text: ' . esc_attr($btn_primary_text) . ';
            --developer-btn-secondary-bg: ' . esc_attr($btn_secondary_bg) . ';
            --developer-btn-secondary-text: ' . esc_attr($btn_secondary_text) . ';
            --developer-btn-radius: ' . esc_attr($btn_radius) . 'px;
            --developer-link-color: ' . esc_attr($link_color) . ';
        }
        
        /* Global Button Styles */
        .developer-btn {
            border-radius: ' . esc_attr($btn_radius) . 'px;
        }
        
        .developer-btn-primary,
        .developer-btn:not(.developer-btn-secondary):not(.developer-btn-white) {
            background: ' . esc_attr($btn_primary_bg) . ';
            color: ' . esc_attr($btn_primary_text) . ';
        }
        
        .developer-btn-primary:hover,
        .developer-btn:not(.developer-btn-secondary):not(.developer-btn-white):hover {
            background: ' . esc_attr(developer_adjust_brightness($btn_primary_bg, -20)) . ';
        }
        
        .developer-btn-secondary {
            background: ' . esc_attr($btn_secondary_bg) . ';
            color: ' . esc_attr($btn_secondary_text) . ';
            border: 2px solid ' . esc_attr($btn_secondary_text) . ';
        }
        
        .developer-btn-secondary:hover {
            background: ' . esc_attr($btn_secondary_text) . ';
            color: ' . esc_attr($btn_secondary_bg) . ';
        }
        
        .developer-btn-white {
            background: ' . esc_attr($btn_secondary_bg) . ';
            color: ' . esc_attr($btn_secondary_text) . ';
        }
        
        .developer-btn-white:hover {
            background: ' . esc_attr(developer_adjust_brightness($btn_secondary_bg, -10)) . ';
        }
        
        /* Global Typography */
        body {
            font-size: ' . esc_attr($body_text_size) . 'px;
        }
        
        .developer-page-header h1 {
            font-size: ' . esc_attr($page_title_size) . 'px;
        }
        
        a {
            color: ' . esc_attr($link_color) . ';
        }
        
        a:hover {
            color: ' . esc_attr(developer_adjust_brightness($link_color, -30)) . ';
        }
        
        /* Header Styles */
        .developer-header {
            background-color: ' . esc_attr($header_bg) . ';
        }
        
        .developer-logo {
            color: ' . esc_attr($header_logo) . ';
        }
        
        .developer-nav a {
            color: ' . esc_attr($header_text) . ';
            font-family: ' . $header_family . ';
            font-size: ' . esc_attr($header_font_size) . 'px;
            font-weight: ' . esc_attr($header_font_weight) . ';
            text-transform: ' . esc_attr($header_text_transform) . ';
        }
        
        .developer-nav-cta {
            background: ' . esc_attr($header_cta_bg) . ' !important;
            color: ' . esc_attr($header_cta_text) . ' !important;
        }
        
        .developer-nav-cta:hover {
            background: ' . esc_attr(developer_adjust_brightness($header_cta_bg, -20)) . ' !important;
        }
        
        .developer-menu-toggle span {
            background-color: ' . esc_attr($header_text) . ';
        }';
    
    // Header border
    $header_border = get_theme_mod('developer_header_border', false);
    $header_border_color = get_theme_mod('developer_header_border_color', '#e2e8f0');
    if ($header_border) {
        echo '
        .developer-header {
            border-bottom: 1px solid ' . esc_attr($header_border_color) . ';
        }';
    }
        
    // Transparent header on homepage
    if ($header_transparent) {
        echo '
        .home .developer-header {
            background-color: transparent;
            border-bottom: none;
        }
        
        .home .developer-header .developer-logo,
        .home .developer-header .developer-nav a {
            color: white;
        }
        
        .home .developer-header .developer-menu-toggle span {
            background-color: white;
        }
        
        .home .developer-header.scrolled {
            background-color: ' . esc_attr($header_bg) . ';
        }
        
        .home .developer-header.scrolled .developer-logo {
            color: ' . esc_attr($header_logo) . ';
        }
        
        .home .developer-header.scrolled .developer-nav a {
            color: ' . esc_attr($header_text) . ';
        }
        
        .home .developer-header.scrolled .developer-menu-toggle span {
            background-color: ' . esc_attr($header_text) . ';
        }';
    }
    
    echo '
        .developer-hero {
            min-height: ' . esc_attr($hero_height) . 'vh;
        }
        
        .developer-featured {
            background-color: ' . esc_attr($featured_bg) . ';
        }
        
        .developer-section-alt {
            background-color: ' . esc_attr($about_bg) . ';
        }
        
        .developer-testimonials {
            background-color: ' . esc_attr($testimonials_bg) . ';
        }
        
        .developer-cta {
            background: linear-gradient(135deg, ' . esc_attr($cta_bg) . ' 0%, ' . esc_attr(developer_adjust_brightness($cta_bg, -30)) . ' 100%);
        }
        
        .developer-footer {
            background-color: ' . esc_attr($footer_bg) . ';
            color: ' . esc_attr($footer_text) . ';
        }
        
        .developer-footer h4,
        .developer-footer-brand h3 {
            color: ' . esc_attr($footer_text) . ';
        }
        
        .developer-footer-links a {
            color: ' . esc_attr($footer_text) . ';
            opacity: 0.7;
        }
        
        .developer-footer-links a:hover {
            opacity: 1;
        }
        
        ' . ($custom_css ? '/* Custom CSS */ ' . $custom_css : '') . '
    </style>';
}
add_action('wp_head', 'developer_developer_custom_css', 100);

/**
 * Adjust color brightness
 */
function developer_adjust_brightness($hex, $steps) {
    $hex = ltrim($hex, '#');
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    return '#' . sprintf('%02x%02x%02x', $r, $g, $b);
}

/**
 * Register Widget Areas
 */
function developer_developer_widgets() {
    register_sidebar(array(
        'name'          => __('Footer 1', 'developer-developer'),
        'id'            => 'footer-1',
        'description'   => __('First footer column', 'developer-developer'),
        'before_widget' => '<div class="developer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4>',
        'after_title'   => '</h4>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer 2', 'developer-developer'),
        'id'            => 'footer-2',
        'description'   => __('Second footer column', 'developer-developer'),
        'before_widget' => '<div class="developer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4>',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'developer_developer_widgets');

/**
 * Custom Walker for Navigation
 */
class Developer_Nav_Walker extends Walker_Nav_Menu {
    private $menu_items_count = 0;
    private $current_item_index = 0;
    
    function walk($elements, $max_depth, ...$args) {
        $this->menu_items_count = count($elements);
        $this->current_item_index = 0;
        return parent::walk($elements, $max_depth, ...$args);
    }
    
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $this->current_item_index++;
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $class_names = join(' ', array_filter($classes));
        
        // Auto-detect CTA button: must have CTA class OR be the LAST menu item linking to book-now
        $is_last_item = ($this->current_item_index == $this->menu_items_count);
        $is_cta = in_array('cta', $classes) || 
                  in_array('menu-cta', $classes) || 
                  in_array('developer-nav-cta', $classes) ||
                  ($is_last_item && strpos($item->url, '/book-now') !== false);
        
        $link_class = $is_cta ? 'developer-nav-cta' : '';
        
        // For CTA button, use the theme_mod text instead of menu item title
        $title = $item->title;
        if ($is_cta) {
            $cta_text = get_theme_mod('developer_header_cta_text', '');
            if (!empty($cta_text)) {
                $title = $cta_text;
            }
        }
        
        if ($item->current) {
            $link_class .= ' active';
        }
        
        $output .= '<a href="' . esc_url($item->url) . '" class="' . esc_attr(trim($link_class)) . '">';
        $output .= esc_html($title);
        $output .= '</a>';
    }
    
    function end_el(&$output, $item, $depth = 0, $args = null) {
        // No closing tag needed
    }
    
    function start_lvl(&$output, $depth = 0, $args = null) {
        // No sub-menus in this simple nav
    }
    
    function end_lvl(&$output, $depth = 0, $args = null) {
        // No sub-menus in this simple nav
    }
}

/**
 * Check if GAS Booking Plugin is Active
 */
function developer_has_gas_booking() {
    return class_exists('GAS_Booking');
}

/**
 * Admin Notice if GAS Booking not installed
 */
function developer_admin_notice() {
    if (!developer_has_gas_booking()) {
        echo '<div class="notice notice-warning is-dismissible">
            <p><strong>GAS Developer Theme:</strong> For full functionality, please install and activate the <a href="https://developer-admin.replit.app" target="_blank">GAS Booking Plugin</a>.</p>
        </div>';
    }
}
add_action('admin_notices', 'developer_admin_notice');
