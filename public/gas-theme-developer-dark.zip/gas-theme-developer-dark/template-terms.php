<?php
/**
 * Template Name: Terms & Conditions
 */

get_header();

// Get site configuration from GAS API
$site_config = null;
$gas_api_url = get_option('gas_api_url', '');
$gas_client_id = get_option('gas_client_id', '');

if ($gas_api_url && $gas_client_id) {
    $cache_key = 'gas_site_config_' . $gas_client_id;
    $site_config = get_transient($cache_key);
    
    if ($site_config === false) {
        $response = wp_remote_get($gas_api_url . '/api/public/client/' . $gas_client_id . '/site-config', array(
            'timeout' => 10,
            'sslverify' => false
        ));
        
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if ($body && $body['success']) {
                $site_config = $body['config'];
                set_transient($cache_key, $site_config, 30);
            }
        }
    }
}

$use_api = !empty($site_config) && !empty($site_config['pages']['terms']['sections']);
$terms = $use_api ? $site_config['pages']['terms'] : null;

// Page settings
$page_title = $use_api ? ($terms['title'] ?? 'Terms & Conditions') : get_the_title();
$updated_date = $use_api ? ($terms['updated_date'] ?? '') : '';

// Get sections from API
$sections = $use_api ? ($terms['sections'] ?? []) : [];

// Build displayable sections array
$all_sections = [];

// Booking section
if (!empty($sections['booking']) && $sections['booking']['enabled'] !== false && !empty($sections['booking']['content'])) {
    $all_sections[] = [
        'title' => $sections['booking']['title'] ?? 'Booking & Reservations',
        'content' => $sections['booking']['content']
    ];
}

// Cancellation section
if (!empty($sections['cancellation']) && $sections['cancellation']['enabled'] !== false) {
    $cancel_content = $sections['cancellation']['content'] ?? '';
    if (empty($cancel_content)) {
        // Auto-generate from period/fee
        $period = $sections['cancellation']['cancel_period'] ?? '48';
        $fee = $sections['cancellation']['cancel_fee'] ?? 'first-night';
        
        $period_text = '';
        switch ($period) {
            case '24': $period_text = '24 hours before check-in'; break;
            case '48': $period_text = '48 hours before check-in'; break;
            case '72': $period_text = '72 hours before check-in'; break;
            case '7days': $period_text = '7 days before check-in'; break;
            case '14days': $period_text = '14 days before check-in'; break;
            case 'none': $period_text = ''; break;
        }
        
        $fee_text = '';
        switch ($fee) {
            case 'first-night': $fee_text = 'first night will be charged'; break;
            case '50': $fee_text = '50% of the booking total will be charged'; break;
            case '100': $fee_text = '100% of the booking total will be charged'; break;
        }
        
        if ($period_text) {
            $cancel_content = "Free cancellation is available up to {$period_text}.";
            if ($fee_text) $cancel_content .= " For cancellations after this period, {$fee_text}.";
        }
    }
    if ($cancel_content) {
        $all_sections[] = [
            'title' => $sections['cancellation']['title'] ?? 'Cancellation Policy',
            'content' => $cancel_content
        ];
    }
}

// Check-in section
if (!empty($sections['checkin']) && $sections['checkin']['enabled'] !== false) {
    $checkin_time = $sections['checkin']['checkin_time'] ?? '';
    $checkout_time = $sections['checkin']['checkout_time'] ?? '';
    $details = $sections['checkin']['details'] ?? '';
    
    if ($checkin_time || $checkout_time || $details) {
        $checkin_content = '';
        if ($checkin_time) $checkin_content .= "Check-in: {$checkin_time}\n";
        if ($checkout_time) $checkin_content .= "Check-out: {$checkout_time}\n";
        if ($details) $checkin_content .= "\n{$details}";
        
        $all_sections[] = [
            'title' => $sections['checkin']['title'] ?? 'Check-in & Check-out',
            'content' => trim($checkin_content)
        ];
    }
}

// House Rules section
if (!empty($sections['house_rules']) && $sections['house_rules']['enabled'] !== false && !empty($sections['house_rules']['content'])) {
    $all_sections[] = [
        'title' => $sections['house_rules']['title'] ?? 'House Rules',
        'content' => $sections['house_rules']['content']
    ];
}

// Payment section
if (!empty($sections['payment']) && $sections['payment']['enabled'] !== false && !empty($sections['payment']['content'])) {
    $all_sections[] = [
        'title' => $sections['payment']['title'] ?? 'Payment Terms',
        'content' => $sections['payment']['content']
    ];
}

// Liability section
if (!empty($sections['liability']) && $sections['liability']['enabled'] !== false && !empty($sections['liability']['content'])) {
    $all_sections[] = [
        'title' => $sections['liability']['title'] ?? 'Liability & Damages',
        'content' => $sections['liability']['content']
    ];
}

// Additional section
if (!empty($sections['additional']) && $sections['additional']['enabled'] !== false && !empty($sections['additional']['content'])) {
    $all_sections[] = [
        'title' => $sections['additional']['title'] ?? 'Additional Terms',
        'content' => $sections['additional']['content']
    ];
}
?>

<main id="primary" class="site-main">
    
    <!-- Page Header -->
    <section class="developer-section" style="background: #f8fafc; padding: 120px 0 50px;">
        <div class="developer-container" style="text-align: center;">
            <h1 style="margin-bottom: 0.5rem;"><?php echo esc_html($page_title); ?></h1>
            <?php if ($updated_date) : ?>
            <p style="color: #64748b; font-size: 0.95rem; margin: 0;">Last updated: <?php echo esc_html(date('F j, Y', strtotime($updated_date))); ?></p>
            <?php endif; ?>
        </div>
    </section>

    <?php if ($use_api && count($all_sections) > 0) : ?>
        <?php foreach ($all_sections as $index => $section) : 
            $bg_color = ($index % 2 === 0) ? '#ffffff' : '#f8fafc';
        ?>
        <section class="developer-section developer-terms-section" style="background: <?php echo $bg_color; ?>; padding: 50px 0;">
            <div class="developer-container">
                <div class="developer-terms-content">
                    <h2><?php echo esc_html($section['title']); ?></h2>
                    <div class="developer-terms-text">
                        <?php echo wpautop(esc_html($section['content'])); ?>
                    </div>
                </div>
            </div>
        </section>
        <?php endforeach; ?>
    <?php else : ?>
        <!-- Fallback message -->
        <section class="developer-section" style="background: #ffffff; padding: 50px 0;">
            <div class="developer-container">
                <div class="developer-terms-content">
                    <p style="text-align: center; color: #64748b;">No terms & conditions content has been configured yet. Please add content in GAS Admin → Website Builder → Terms & Conditions.</p>
                </div>
            </div>
        </section>
    <?php endif; ?>

</main>

<?php
// Output FAQ Schema if enabled and FAQs exist
$faq_enabled = $use_api ? ($terms['faq_enabled'] ?? true) : false;
$faqs = $use_api ? ($terms['faqs'] ?? []) : [];

if ($faq_enabled && !empty($faqs) && is_array($faqs)) :
    $faq_schema = [
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => []
    ];
    
    foreach ($faqs as $faq) {
        if (!empty($faq['question']) && !empty($faq['answer'])) {
            $faq_schema['mainEntity'][] = [
                '@type' => 'Question',
                'name' => $faq['question'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text' => $faq['answer']
                ]
            ];
        }
    }
    
    if (!empty($faq_schema['mainEntity'])) :
?>
<script type="application/ld+json">
<?php echo json_encode($faq_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>
</script>
<?php 
    endif;
endif; 
?>

<style>
.developer-terms-content {
    max-width: 800px;
    margin: 0 auto;
}
.developer-terms-content h2 {
    font-size: 1.75rem;
    color: #1e293b;
    margin-bottom: 1.5rem;
    font-weight: 600;
}
.developer-terms-text p {
    line-height: 1.8;
    color: #475569;
    margin-bottom: 1rem;
    font-size: 1rem;
}
.developer-terms-text p:last-child {
    margin-bottom: 0;
}
</style>

<?php get_footer(); ?>
