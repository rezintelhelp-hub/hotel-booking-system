<?php
/**
 * Template Name: Privacy Policy
 */

get_header();

// Get site configuration from GAS API
$site_config = null;
$gas_api_url = get_option('gas_api_url', '');
$gas_client_id = get_option('gas_client_id', '');

if ($gas_api_url && $gas_client_id) {
    $cache_key = 'gas_site_config_' . $gas_client_id;
    $site_config = get_transient($cache_key);
    
    if ($site_config === false) {
        $response = wp_remote_get($gas_api_url . '/api/public/client/' . $gas_client_id . '/site-config', array(
            'timeout' => 10,
            'sslverify' => false
        ));
        
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if ($body && $body['success']) {
                $site_config = $body['config'];
                set_transient($cache_key, $site_config, 30);
            }
        }
    }
}

$use_api = !empty($site_config) && !empty($site_config['pages']['privacy']['sections']);
$privacy = $use_api ? $site_config['pages']['privacy'] : null;

// Page settings
$page_title = $use_api ? ($privacy['title'] ?? 'Privacy Policy') : get_the_title();
$updated_date = $use_api ? ($privacy['updated_date'] ?? '') : '';
$effective_date = $use_api ? ($privacy['effective_date'] ?? '') : '';

// Get sections from API
$sections = $use_api ? ($privacy['sections'] ?? []) : [];

// Build displayable sections array - now with sub_items for sub-headings
$all_sections = [];

// Introduction section
if (!empty($sections['intro']) && $sections['intro']['enabled'] !== false && !empty($sections['intro']['content'])) {
    $sub_items = [];
    $sub_heading = $sections['intro']['sub_heading'] ?? '';
    if ($sub_heading) {
        $sub_items[] = ['heading' => $sub_heading, 'content' => $sections['intro']['content']];
    }
    $all_sections[] = [
        'title' => $sections['intro']['title'] ?? 'Introduction',
        'content' => $sub_heading ? '' : $sections['intro']['content'],
        'sub_items' => $sub_items
    ];
}

// Data Collection section - has two sub-sections
if (!empty($sections['collection']) && $sections['collection']['enabled'] !== false) {
    $collection_content = $sections['collection']['content'] ?? '';
    $how_collect = $sections['collection']['how_collect'] ?? '';
    
    if ($collection_content || $how_collect) {
        $sub_items = [];
        if ($collection_content) {
            $sub_items[] = [
                'heading' => $sections['collection']['sub_heading_1'] ?? 'What Data We Collect',
                'content' => $collection_content
            ];
        }
        if ($how_collect) {
            $sub_items[] = [
                'heading' => $sections['collection']['sub_heading_2'] ?? 'How We Collect Data',
                'content' => $how_collect
            ];
        }
        $all_sections[] = [
            'title' => $sections['collection']['title'] ?? 'Information We Collect',
            'content' => '',
            'sub_items' => $sub_items
        ];
    }
}

// Data Usage section
if (!empty($sections['usage']) && $sections['usage']['enabled'] !== false && !empty($sections['usage']['content'])) {
    $sub_items = [];
    $sub_heading = $sections['usage']['sub_heading'] ?? '';
    if ($sub_heading) {
        $sub_items[] = ['heading' => $sub_heading, 'content' => $sections['usage']['content']];
    }
    $all_sections[] = [
        'title' => $sections['usage']['title'] ?? 'How We Use Your Information',
        'content' => $sub_heading ? '' : $sections['usage']['content'],
        'sub_items' => $sub_items
    ];
}

// Data Sharing section
if (!empty($sections['sharing']) && $sections['sharing']['enabled'] !== false && !empty($sections['sharing']['content'])) {
    $sub_items = [];
    $sub_heading = $sections['sharing']['sub_heading'] ?? '';
    if ($sub_heading) {
        $sub_items[] = ['heading' => $sub_heading, 'content' => $sections['sharing']['content']];
    }
    $all_sections[] = [
        'title' => $sections['sharing']['title'] ?? 'Information Sharing',
        'content' => $sub_heading ? '' : $sections['sharing']['content'],
        'sub_items' => $sub_items
    ];
}

// Cookies section
if (!empty($sections['cookies']) && $sections['cookies']['enabled'] !== false && !empty($sections['cookies']['content'])) {
    $sub_items = [];
    $sub_heading = $sections['cookies']['sub_heading'] ?? '';
    if ($sub_heading) {
        $sub_items[] = ['heading' => $sub_heading, 'content' => $sections['cookies']['content']];
    }
    $all_sections[] = [
        'title' => $sections['cookies']['title'] ?? 'Cookies',
        'content' => $sub_heading ? '' : $sections['cookies']['content'],
        'sub_items' => $sub_items
    ];
}

// Your Rights section
if (!empty($sections['rights']) && $sections['rights']['enabled'] !== false && !empty($sections['rights']['content'])) {
    $sub_items = [];
    $sub_heading = $sections['rights']['sub_heading'] ?? '';
    if ($sub_heading) {
        $sub_items[] = ['heading' => $sub_heading, 'content' => $sections['rights']['content']];
    }
    $all_sections[] = [
        'title' => $sections['rights']['title'] ?? 'Your Rights',
        'content' => $sub_heading ? '' : $sections['rights']['content'],
        'sub_items' => $sub_items
    ];
}

// Data Retention section
if (!empty($sections['retention']) && $sections['retention']['enabled'] !== false && !empty($sections['retention']['content'])) {
    $sub_items = [];
    $sub_heading = $sections['retention']['sub_heading'] ?? '';
    if ($sub_heading) {
        $sub_items[] = ['heading' => $sub_heading, 'content' => $sections['retention']['content']];
    }
    $all_sections[] = [
        'title' => $sections['retention']['title'] ?? 'Data Retention',
        'content' => $sub_heading ? '' : $sections['retention']['content'],
        'sub_items' => $sub_items
    ];
}

// Contact section
if (!empty($sections['contact']) && $sections['contact']['enabled'] !== false && !empty($sections['contact']['content'])) {
    $sub_items = [];
    $sub_heading = $sections['contact']['sub_heading'] ?? '';
    if ($sub_heading) {
        $sub_items[] = ['heading' => $sub_heading, 'content' => $sections['contact']['content']];
    }
    $all_sections[] = [
        'title' => $sections['contact']['title'] ?? 'Contact Us',
        'content' => $sub_heading ? '' : $sections['contact']['content'],
        'sub_items' => $sub_items
    ];
}
?>

<main id="primary" class="site-main">
    
    <!-- Page Header -->
    <section class="developer-section" style="background: #f8fafc; padding: 120px 0 50px;">
        <div class="developer-container" style="text-align: center;">
            <h1 style="margin-bottom: 0.5rem;"><?php echo esc_html($page_title); ?></h1>
            <?php if ($updated_date || $effective_date) : ?>
            <p style="color: #64748b; font-size: 0.95rem; margin: 0;">
                <?php if ($effective_date) : ?>Effective: <?php echo esc_html(date('F j, Y', strtotime($effective_date))); ?><?php endif; ?>
                <?php if ($updated_date && $effective_date) : ?> · <?php endif; ?>
                <?php if ($updated_date) : ?>Last updated: <?php echo esc_html(date('F j, Y', strtotime($updated_date))); ?><?php endif; ?>
            </p>
            <?php endif; ?>
        </div>
    </section>

    <?php if ($use_api && count($all_sections) > 0) : ?>
        <?php foreach ($all_sections as $index => $section) : 
            $bg_color = ($index % 2 === 0) ? '#ffffff' : '#f8fafc';
        ?>
        <section class="developer-section developer-privacy-section" style="background: <?php echo $bg_color; ?>; padding: 50px 0;">
            <div class="developer-container">
                <div class="developer-privacy-content">
                    <h2><?php echo esc_html($section['title']); ?></h2>
                    
                    <?php if (!empty($section['content'])) : ?>
                    <div class="developer-privacy-text">
                        <?php echo wpautop(esc_html($section['content'])); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($section['sub_items'])) : ?>
                        <?php foreach ($section['sub_items'] as $sub_item) : ?>
                        <div class="developer-privacy-sub-section" style="margin-top: 1.5rem;">
                            <?php if (!empty($sub_item['heading'])) : ?>
                            <h3 style="font-size: 1.25rem; color: #334155; margin-bottom: 0.75rem; font-weight: 600;"><?php echo esc_html($sub_item['heading']); ?></h3>
                            <?php endif; ?>
                            <div class="developer-privacy-text">
                                <?php echo wpautop(esc_html($sub_item['content'])); ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php endforeach; ?>
    <?php else : ?>
        <!-- Fallback message -->
        <section class="developer-section" style="background: #ffffff; padding: 50px 0;">
            <div class="developer-container">
                <div class="developer-privacy-content">
                    <p style="text-align: center; color: #64748b;">No privacy policy content has been configured yet. Please add content in GAS Admin → Website Builder → Privacy Policy.</p>
                </div>
            </div>
        </section>
    <?php endif; ?>

</main>

<?php
// Output FAQ Schema if enabled and FAQs exist
$faq_enabled = $use_api ? ($privacy['faq_enabled'] ?? true) : false;
$faqs = $use_api ? ($privacy['faqs'] ?? []) : [];

if ($faq_enabled && !empty($faqs) && is_array($faqs)) :
    $faq_schema = [
        '@context' => 'https://schema.org',
        '@type' => 'FAQPage',
        'mainEntity' => []
    ];
    
    foreach ($faqs as $faq) {
        if (!empty($faq['question']) && !empty($faq['answer'])) {
            $faq_schema['mainEntity'][] = [
                '@type' => 'Question',
                'name' => $faq['question'],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text' => $faq['answer']
                ]
            ];
        }
    }
    
    if (!empty($faq_schema['mainEntity'])) :
?>
<script type="application/ld+json">
<?php echo json_encode($faq_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>
</script>
<?php 
    endif;
endif; 
?>

<style>
.developer-privacy-content {
    max-width: 800px;
    margin: 0 auto;
}
.developer-privacy-content h2 {
    font-size: 1.75rem;
    color: #1e293b;
    margin-bottom: 1.5rem;
    font-weight: 600;
}
.developer-privacy-text p {
    line-height: 1.8;
    color: #475569;
    margin-bottom: 1rem;
    font-size: 1rem;
}
.developer-privacy-text p:last-child {
    margin-bottom: 0;
}
</style>

<?php get_footer(); ?>
