<?php
/**
 * Blog Index Template
 *
 * @package GAS_Developer
 */

get_header();
?>

<div class="developer-page-content" style="padding-top: 120px;">
    <div class="developer-container">
        <h1 style="color: #1e293b; margin: 0 0 8px; font-size: 2rem;"><?php echo is_home() ? 'Blog' : get_the_archive_title(); ?></h1>
        <p style="color: #64748b; margin: 0 0 30px;">News, tips, and stories from our vacation rental community.</p>
        
        <?php if (have_posts()) : ?>
            <div class="developer-blog-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <article class="developer-blog-card">
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="developer-blog-image">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('developer-card'); ?>
                                </a>
                            </div>
                        <?php else : ?>
                            <div class="developer-blog-image">
                                <a href="<?php the_permalink(); ?>">
                                    <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 32px;">📝</div>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="developer-blog-content">
                            <div class="developer-blog-meta">
                                <?php echo get_the_date(); ?> · <?php echo get_the_category_list(', '); ?>
                            </div>
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <p class="developer-blog-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>
            
            <div class="text-center mt-5">
                <?php
                the_posts_pagination(array(
                    'mid_size'  => 2,
                    'prev_text' => '← Previous',
                    'next_text' => 'Next →',
                ));
                ?>
            </div>
        <?php else : ?>
            <div style="text-align: center; padding: 60px;">
                <h3>No Posts Yet</h3>
                <p style="color: var(--developer-text-light);">Check back soon for updates!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
