<?php
/**
 * Archive Template
 * Handles gas_blog and gas_attraction archives
 *
 * @package GAS_Developer
 */

get_header();

$post_type = get_post_type();
$is_gas_blog = ($post_type === 'gas_blog' || is_post_type_archive('gas_blog'));
$is_gas_attraction = ($post_type === 'gas_attraction' || is_post_type_archive('gas_attraction'));

// Determine title
if ($is_gas_blog) {
    $archive_title = 'Blog';
    $archive_desc = 'News, tips, and updates from our property';
} elseif ($is_gas_attraction) {
    $archive_title = 'Things To Do';
    $archive_desc = 'Explore the best attractions near our property';
} else {
    $archive_title = get_the_archive_title();
    $archive_desc = get_the_archive_description();
}
?>

<div class="developer-page-content" style="padding-top: 120px;">
    <div class="developer-container">
        <div style="max-width: 1200px; margin: 0 auto;">
            <h1 style="color: #1e293b; margin: 0 0 8px; font-size: 2rem;"><?php echo esc_html($archive_title); ?></h1>
            <?php if ($archive_desc) : ?>
                <p style="color: #64748b; font-size: 1.1rem; margin: 0 0 30px;"><?php echo esc_html($archive_desc); ?></p>
            <?php endif; ?>
            <?php 
            if ($is_gas_blog) {
                echo do_shortcode('[gas_blog_categories]');
                echo do_shortcode('[gas_blog limit="12"]');
            } elseif ($is_gas_attraction) {
                echo do_shortcode('[gas_attractions_categories]');
                echo do_shortcode('[gas_attractions]');
            } else {
                // Default archive display
                if (have_posts()) : ?>
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px;">
                        <?php while (have_posts()) : the_post(); ?>
                            <article style="background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
                                <?php if (has_post_thumbnail()) : ?>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail('medium_large', array('style' => 'width: 100%; height: 200px; object-fit: cover;')); ?>
                                    </a>
                                <?php endif; ?>
                                <div style="padding: 24px;">
                                    <h2 style="font-size: 1.25rem; margin: 0 0 12px;"><a href="<?php the_permalink(); ?>" style="color: #1e293b; text-decoration: none;"><?php the_title(); ?></a></h2>
                                    <p style="color: #64748b; font-size: 0.95rem; margin: 0;"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                                </div>
                            </article>
                        <?php endwhile; ?>
                    </div>
                    
                    <div style="margin-top: 40px; text-align: center;">
                        <?php the_posts_pagination(); ?>
                    </div>
                <?php else : ?>
                    <p>No posts found.</p>
                <?php endif;
            }
            ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>
