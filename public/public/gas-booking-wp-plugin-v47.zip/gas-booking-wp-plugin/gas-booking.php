<?php
/**
 * Plugin Name: GAS Booking
 * Plugin URI: https://github.com/gas-booking
 * Description: Complete booking system for Guest Accommodation System. Shows room grid immediately.
 * Version: 3.6.0
 * Author: GAS
 * License: GPL v2 or later
 * Text Domain: gas-booking
 */

if (!defined('ABSPATH')) exit;

define('GAS_BOOKING_VERSION', '3.7.0');
define('GAS_BOOKING_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('GAS_BOOKING_PLUGIN_URL', plugin_dir_url(__FILE__));

class GAS_Booking {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Shortcodes
        add_shortcode('gas_search', array($this, 'search_shortcode'));
        add_shortcode('gas_rooms', array($this, 'rooms_shortcode'));
        add_shortcode('gas_room', array($this, 'room_shortcode'));
        add_shortcode('gas_booking', array($this, 'booking_shortcode'));
        add_shortcode('gas_checkout', array($this, 'checkout_shortcode'));
        add_shortcode('gas_offers', array($this, 'offers_shortcode'));
        
        // AJAX handlers
        add_action('wp_ajax_gas_get_availability', array($this, 'ajax_get_availability'));
        add_action('wp_ajax_nopriv_gas_get_availability', array($this, 'ajax_get_availability'));
        add_action('wp_ajax_gas_get_rooms', array($this, 'ajax_get_rooms'));
        add_action('wp_ajax_nopriv_gas_get_rooms', array($this, 'ajax_get_rooms'));
        add_action('wp_ajax_gas_calculate_price', array($this, 'ajax_calculate_price'));
        add_action('wp_ajax_nopriv_gas_calculate_price', array($this, 'ajax_calculate_price'));
        add_action('wp_ajax_gas_create_booking', array($this, 'ajax_create_booking'));
        add_action('wp_ajax_nopriv_gas_create_booking', array($this, 'ajax_create_booking'));
    }
    
    public function add_admin_menu() {
        add_options_page(
            'GAS Booking Settings',
            'GAS Booking',
            'manage_options',
            'gas-booking',
            array($this, 'settings_page')
        );
    }
    
    public function register_settings() {
        // General settings group
        register_setting('gas_booking_general', 'gas_api_url');
        register_setting('gas_booking_general', 'gas_client_id');
        register_setting('gas_booking_general', 'gas_room_url_base');
        register_setting('gas_booking_general', 'gas_search_results_url');
        register_setting('gas_booking_general', 'gas_checkout_url');
        register_setting('gas_booking_general', 'gas_offers_url');
        register_setting('gas_booking_general', 'gas_currency_symbol');
        register_setting('gas_booking_general', 'gas_button_color');
        register_setting('gas_booking_general', 'gas_max_guests_dropdown');
        register_setting('gas_booking_general', 'gas_center_search');
        register_setting('gas_booking_general', 'gas_search_max_width');
        
        // CSS settings group
        register_setting('gas_booking_css', 'gas_css_search_widget');
        register_setting('gas_booking_css', 'gas_css_rooms_grid');
        register_setting('gas_booking_css', 'gas_css_room_cards');
        register_setting('gas_booking_css', 'gas_css_room_detail');
        register_setting('gas_booking_css', 'gas_css_booking_form');
        register_setting('gas_booking_css', 'gas_css_calendar');
        register_setting('gas_booking_css', 'gas_css_map');
        register_setting('gas_booking_css', 'gas_css_buttons');
        register_setting('gas_booking_css', 'gas_css_global');
    }
    
    public function settings_page() {
        $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'general';
        ?>
        <div class="wrap">
            <h1>🏨 GAS Booking Settings</h1>
            
            <nav class="nav-tab-wrapper">
                <a href="?page=gas-booking&tab=general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">⚙️ General</a>
                <a href="?page=gas-booking&tab=builder" class="nav-tab <?php echo $active_tab === 'builder' ? 'nav-tab-active' : ''; ?>">🔧 Shortcode Builder</a>
                <a href="?page=gas-booking&tab=shortcodes" class="nav-tab <?php echo $active_tab === 'shortcodes' ? 'nav-tab-active' : ''; ?>">📋 Reference</a>
                <a href="?page=gas-booking&tab=css" class="nav-tab <?php echo $active_tab === 'css' ? 'nav-tab-active' : ''; ?>">🎨 Custom CSS</a>
                <a href="?page=gas-booking&tab=ai" class="nav-tab <?php echo $active_tab === 'ai' ? 'nav-tab-active' : ''; ?>">🤖 AI Integration</a>
            </nav>
            
            <div class="tab-content" style="margin-top: 20px;">
            
            <?php if ($active_tab === 'general') : ?>
                <!-- GENERAL SETTINGS TAB -->
                <form method="post" action="options.php">
                    <?php settings_fields('gas_booking_general'); ?>
                    <table class="form-table">
                        <tr>
                            <th>GAS API URL</th>
                            <td>
                                <input type="url" name="gas_api_url" value="<?php echo esc_attr(get_option('gas_api_url', 'https://gas-booking-production.up.railway.app')); ?>" class="regular-text" />
                                <p class="description">Your GAS server URL (no trailing slash)</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Client Account ID</th>
                            <td>
                                <input type="number" name="gas_client_id" value="<?php echo esc_attr(get_option('gas_client_id', '')); ?>" class="small-text" />
                                <p class="description"><strong>Required!</strong> Find this in GAS Admin → Clients section</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Room Page URL</th>
                            <td>
                                <input type="text" name="gas_room_url_base" value="<?php echo esc_attr(get_option('gas_room_url_base', '/room/')); ?>" class="regular-text" />
                                <p class="description">URL where [gas_room] shortcode is placed (e.g., /room/)</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Search Results URL</th>
                            <td>
                                <input type="text" name="gas_search_results_url" value="<?php echo esc_attr(get_option('gas_search_results_url', '/book-now/')); ?>" class="regular-text" />
                                <p class="description">URL where [gas_rooms] shortcode is placed (e.g., /book-now/)</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Checkout URL</th>
                            <td>
                                <input type="text" name="gas_checkout_url" value="<?php echo esc_attr(get_option('gas_checkout_url', '/checkout/')); ?>" class="regular-text" />
                                <p class="description">URL where [gas_checkout] shortcode is placed (e.g., /checkout/)</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Offers Page URL</th>
                            <td>
                                <input type="text" name="gas_offers_url" value="<?php echo esc_attr(get_option('gas_offers_url', '/offers/')); ?>" class="regular-text" />
                                <p class="description">URL where [gas_offers] shortcode is placed (e.g., /offers/)</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Currency Symbol</th>
                            <td>
                                <input type="text" name="gas_currency_symbol" value="<?php echo esc_attr(get_option('gas_currency_symbol', '£')); ?>" class="small-text" />
                            </td>
                        </tr>
                    </table>
                    
                    <h3>🎨 Styling Options</h3>
                    <table class="form-table">
                        <tr>
                            <th>Button Color</th>
                            <td>
                                <input type="color" id="gas_button_color_picker" value="<?php echo esc_attr(get_option('gas_button_color', '#667eea')); ?>" />
                                <input type="text" name="gas_button_color" id="gas_button_color_text" value="<?php echo esc_attr(get_option('gas_button_color', '#667eea')); ?>" class="small-text" style="margin-left: 8px;" />
                                <p class="description">Color for all buttons (Check Availability, Book Now, etc.)</p>
                                <script>
                                document.getElementById('gas_button_color_picker').addEventListener('input', function() {
                                    document.getElementById('gas_button_color_text').value = this.value;
                                });
                                document.getElementById('gas_button_color_text').addEventListener('input', function() {
                                    document.getElementById('gas_button_color_picker').value = this.value;
                                });
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <th>Max Guests in Dropdown</th>
                            <td>
                                <input type="number" name="gas_max_guests_dropdown" value="<?php echo esc_attr(get_option('gas_max_guests_dropdown', '10')); ?>" min="1" max="50" class="small-text" />
                                <p class="description">Maximum number of guests shown in the dropdown selector (default: 10)</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Center Search Bar</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="gas_center_search" value="1" <?php checked(get_option('gas_center_search', '0'), '1'); ?> />
                                    Center the date/guest filter bar on the rooms page
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th>Search Bar Max Width</th>
                            <td>
                                <input type="number" name="gas_search_max_width" value="<?php echo esc_attr(get_option('gas_search_max_width', '800')); ?>" class="small-text" /> px
                                <p class="description">Maximum width when centered (default: 800px)</p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
                
                <hr>
                <h2>🚀 Quick Setup</h2>
                <ol>
                    <li>Enter your <strong>Client Account ID</strong> above (from GAS Admin)</li>
                    <li>Create page "Home" → Add <code>[gas_search]</code></li>
                    <li>Create page "Book Now" → Add <code>[gas_rooms]</code></li>
                    <li>Create page "Room" → Add <code>[gas_room]</code></li>
                    <li>Done! Your booking system is ready.</li>
                </ol>
                
                <hr>
                <h2>🏠 Your Room IDs</h2>
                <p>Use these IDs when you want to display specific rooms (e.g., in the theme's Featured Properties section).</p>
                <?php
                $client_id = get_option('gas_client_id', '');
                if (!empty($client_id)) {
                    $api_url = get_option('gas_api_url', 'https://gas-booking-production.up.railway.app');
                    $response = wp_remote_get("{$api_url}/api/public/client/{$client_id}/rooms", array('timeout' => 15, 'sslverify' => false));
                    
                    if (!is_wp_error($response)) {
                        $body = json_decode(wp_remote_retrieve_body($response), true);
                        if (!empty($body['rooms'])) {
                            echo '<table class="widefat striped" style="max-width: 800px; margin-top: 15px;">
                                <thead>
                                    <tr>
                                        <th style="width: 60px;">ID</th>
                                        <th>Room Name</th>
                                        <th>Property</th>
                                        <th style="width: 100px;">Max Guests</th>
                                        <th style="width: 100px;">Price</th>
                                    </tr>
                                </thead>
                                <tbody>';
                            foreach ($body['rooms'] as $room) {
                                $currency = $room['currency'] ?? '$';
                                echo '<tr>
                                    <td><strong style="background: #2563eb; color: white; padding: 2px 8px; border-radius: 4px;">' . esc_html($room['id']) . '</strong></td>
                                    <td>' . esc_html($room['name']) . '</td>
                                    <td>' . esc_html($room['property_name'] ?? 'N/A') . '</td>
                                    <td>' . esc_html($room['max_guests'] ?? '-') . '</td>
                                    <td>' . esc_html($currency . number_format($room['base_price'] ?? 0, 0)) . '</td>
                                </tr>';
                            }
                            echo '</tbody></table>';
                            echo '<p style="margin-top: 10px; color: #666;"><strong>Tip:</strong> To show rooms 1, 3, and 5 on your homepage, use: <code>room_ids="1,3,5"</code></p>';
                        } else {
                            echo '<p style="color: #666;">No rooms found. Make sure you have properties and rooms set up in GAS Admin.</p>';
                        }
                    } else {
                        echo '<p style="color: #dc2626;">Could not fetch rooms. Check your API URL and Client ID.</p>';
                    }
                } else {
                    echo '<p style="color: #666;">Please save your Client Account ID first, then refresh this page to see your rooms.</p>';
                }
                ?>
                
            <?php elseif ($active_tab === 'builder') : ?>
                <!-- SHORTCODE BUILDER TAB -->
                <style>
                    .gas-builder-container {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        gap: 30px;
                        max-width: 1400px;
                    }
                    @media (max-width: 1200px) {
                        .gas-builder-container { grid-template-columns: 1fr; }
                    }
                    .gas-builder-options {
                        background: #fff;
                        padding: 24px;
                        border-radius: 12px;
                        border: 1px solid #ddd;
                    }
                    .gas-builder-preview {
                        background: #f8fafc;
                        padding: 24px;
                        border-radius: 12px;
                        border: 1px solid #ddd;
                    }
                    .gas-builder-section {
                        margin-bottom: 24px;
                        padding-bottom: 24px;
                        border-bottom: 1px solid #eee;
                    }
                    .gas-builder-section:last-child {
                        border-bottom: none;
                        margin-bottom: 0;
                        padding-bottom: 0;
                    }
                    .gas-builder-section h4 {
                        margin: 0 0 12px 0;
                        color: #1e293b;
                        font-size: 14px;
                    }
                    .gas-builder-row {
                        display: flex;
                        align-items: center;
                        margin-bottom: 12px;
                        gap: 12px;
                    }
                    .gas-builder-row label {
                        min-width: 120px;
                        font-size: 13px;
                        color: #64748b;
                    }
                    .gas-builder-row select,
                    .gas-builder-row input[type="text"],
                    .gas-builder-row input[type="number"] {
                        flex: 1;
                        padding: 8px 12px;
                        border: 1px solid #ddd;
                        border-radius: 6px;
                        font-size: 13px;
                        max-width: 200px;
                    }
                    .gas-builder-row input[type="color"] {
                        width: 50px;
                        height: 36px;
                        padding: 2px;
                        border: 1px solid #ddd;
                        border-radius: 6px;
                        cursor: pointer;
                    }
                    .gas-builder-row input[type="checkbox"] {
                        width: 18px;
                        height: 18px;
                    }
                    .gas-shortcode-output {
                        background: #1e293b;
                        color: #e2e8f0;
                        padding: 16px 20px;
                        border-radius: 8px;
                        font-family: monospace;
                        font-size: 14px;
                        margin: 20px 0;
                        word-break: break-all;
                        position: relative;
                    }
                    .gas-copy-btn {
                        position: absolute;
                        top: 8px;
                        right: 8px;
                        background: #3b82f6;
                        color: white;
                        border: none;
                        padding: 6px 12px;
                        border-radius: 4px;
                        font-size: 12px;
                        cursor: pointer;
                    }
                    .gas-copy-btn:hover {
                        background: #2563eb;
                    }
                    .gas-copy-btn.copied {
                        background: #10b981;
                    }
                    .gas-widget-selector {
                        display: flex;
                        gap: 12px;
                        margin-bottom: 24px;
                    }
                    .gas-widget-btn {
                        flex: 1;
                        padding: 16px;
                        border: 2px solid #ddd;
                        border-radius: 8px;
                        background: #fff;
                        cursor: pointer;
                        text-align: center;
                        transition: all 0.2s;
                    }
                    .gas-widget-btn:hover {
                        border-color: #3b82f6;
                    }
                    .gas-widget-btn.active {
                        border-color: #3b82f6;
                        background: #eff6ff;
                    }
                    .gas-widget-btn .icon {
                        font-size: 24px;
                        display: block;
                        margin-bottom: 8px;
                    }
                    .gas-widget-btn .label {
                        font-weight: 600;
                        font-size: 13px;
                        color: #1e293b;
                    }
                    .gas-preview-frame {
                        background: #fff;
                        border: 1px solid #ddd;
                        border-radius: 8px;
                        padding: 30px;
                        min-height: 200px;
                        margin-top: 16px;
                    }
                    /* Preview widget styles */
                    .gas-preview-widget {
                        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                    }
                    .gas-preview-widget.vertical .fields { display: flex; flex-direction: column; gap: 12px; }
                    .gas-preview-widget.horizontal .fields { display: flex; flex-direction: row; gap: 12px; align-items: flex-end; }
                    .gas-preview-widget.inline .fields { display: flex; flex-direction: row; gap: 8px; align-items: center; }
                    .gas-preview-widget .field { flex: 1; }
                    .gas-preview-widget .field label { display: block; font-size: 11px; font-weight: 600; text-transform: uppercase; margin-bottom: 6px; }
                    .gas-preview-widget.inline .field label { display: none; }
                    .gas-preview-widget .field input,
                    .gas-preview-widget .field select { width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px; box-sizing: border-box; }
                    .gas-preview-widget .submit-field { flex: 0 0 auto; }
                    .gas-preview-widget.vertical .submit-field { margin-top: 8px; }
                    .gas-preview-widget .preview-btn { padding: 10px 24px; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; color: white; }
                </style>
                
                <h2>🔧 Shortcode Builder</h2>
                <p>Select options below to build your shortcode, then copy and paste it into any page.</p>
                
                <div class="gas-builder-container">
                    <div class="gas-builder-options">
                        <!-- Widget Type Selector -->
                        <div class="gas-widget-selector">
                            <button type="button" class="gas-widget-btn active" data-widget="search" onclick="selectWidget('search')">
                                <span class="icon">🔍</span>
                                <span class="label">Search Widget</span>
                            </button>
                            <button type="button" class="gas-widget-btn" data-widget="rooms" onclick="selectWidget('rooms')">
                                <span class="icon">🏠</span>
                                <span class="label">Rooms Grid</span>
                            </button>
                            <button type="button" class="gas-widget-btn" data-widget="room" onclick="selectWidget('room')">
                                <span class="icon">🛏️</span>
                                <span class="label">Room Detail</span>
                            </button>
                        </div>
                        
                        <!-- Search Widget Options -->
                        <div id="options-search" class="gas-options-panel">
                            <div class="gas-builder-section">
                                <h4>📐 Layout</h4>
                                <div class="gas-builder-row">
                                    <label>Layout Style</label>
                                    <select id="search-layout" onchange="updateShortcode()">
                                        <option value="vertical">Vertical (stacked)</option>
                                        <option value="horizontal">Horizontal (row)</option>
                                        <option value="inline">Inline (compact)</option>
                                    </select>
                                </div>
                                <div class="gas-builder-row">
                                    <label>Max Width</label>
                                    <input type="text" id="search-max-width" value="600px" onchange="updateShortcode()" />
                                </div>
                            </div>
                            
                            <div class="gas-builder-section">
                                <h4>📝 Fields</h4>
                                <div class="gas-builder-row">
                                    <label>Show Location</label>
                                    <input type="checkbox" id="search-location" onchange="updateShortcode()" />
                                </div>
                                <div class="gas-builder-row">
                                    <label>Location Placeholder</label>
                                    <input type="text" id="search-location-placeholder" value="Where are you going?" onchange="updateShortcode()" />
                                </div>
                                <div class="gas-builder-row">
                                    <label>Max Guests</label>
                                    <input type="number" id="search-max-guests" value="10" min="1" max="50" onchange="updateShortcode()" />
                                </div>
                            </div>
                            
                            <div class="gas-builder-section">
                                <h4>🔘 Button</h4>
                                <div class="gas-builder-row">
                                    <label>Button Text</label>
                                    <input type="text" id="search-button-text" value="Search" onchange="updateShortcode()" />
                                </div>
                                <div class="gas-builder-row">
                                    <label>Full Width Button</label>
                                    <input type="checkbox" id="search-button-full" onchange="updateShortcode()" />
                                </div>
                            </div>
                            
                            <div class="gas-builder-section">
                                <h4>🎨 Colors</h4>
                                <div class="gas-builder-row">
                                    <label>Button Color</label>
                                    <input type="color" id="search-primary-color" value="#2563eb" onchange="updateShortcode()" />
                                    <input type="text" id="search-primary-color-text" value="#2563eb" style="width: 80px;" onchange="document.getElementById('search-primary-color').value = this.value; updateShortcode();" />
                                </div>
                                <div class="gas-builder-row">
                                    <label>Background</label>
                                    <input type="color" id="search-bg-color" value="#ffffff" onchange="updateShortcode()" />
                                    <input type="text" id="search-bg-color-text" value="#ffffff" style="width: 80px;" onchange="document.getElementById('search-bg-color').value = this.value; updateShortcode();" />
                                </div>
                                <div class="gas-builder-row">
                                    <label>Border Radius</label>
                                    <input type="text" id="search-border-radius" value="12px" onchange="updateShortcode()" />
                                </div>
                            </div>
                            
                            <div class="gas-builder-section">
                                <h4>🏷️ Custom Class</h4>
                                <div class="gas-builder-row">
                                    <label>CSS Class</label>
                                    <input type="text" id="search-class" placeholder="my-custom-class" onchange="updateShortcode()" />
                                </div>
                            </div>
                        </div>
                        
                        <!-- Rooms Grid Options -->
                        <div id="options-rooms" class="gas-options-panel" style="display: none;">
                            <div class="gas-builder-section">
                                <h4>📐 Layout</h4>
                                <div class="gas-builder-row">
                                    <label>Columns</label>
                                    <select id="rooms-columns" onchange="updateShortcode()">
                                        <option value="2">2 Columns</option>
                                        <option value="3" selected>3 Columns</option>
                                        <option value="4">4 Columns</option>
                                    </select>
                                </div>
                                <div class="gas-builder-row">
                                    <label>Show Map</label>
                                    <input type="checkbox" id="rooms-show-map" checked onchange="updateShortcode()" />
                                </div>
                            </div>
                            
                            <div class="gas-builder-section">
                                <h4>🔍 Filter</h4>
                                <div class="gas-builder-row">
                                    <label>Property ID</label>
                                    <input type="number" id="rooms-property-id" placeholder="All properties" onchange="updateShortcode()" />
                                    <span style="font-size: 11px; color: #64748b;">Leave empty for all</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Room Detail Options -->
                        <div id="options-room" class="gas-options-panel" style="display: none;">
                            <div class="gas-builder-section">
                                <h4>🛏️ Room Settings</h4>
                                <div class="gas-builder-row">
                                    <label>Unit ID</label>
                                    <input type="number" id="room-unit-id" placeholder="From URL parameter" onchange="updateShortcode()" />
                                    <span style="font-size: 11px; color: #64748b;">Optional - uses ?unit_id from URL</span>
                                </div>
                                <div class="gas-builder-row">
                                    <label>Show Map</label>
                                    <input type="checkbox" id="room-show-map" checked onchange="updateShortcode()" />
                                </div>
                            </div>
                            <p style="color: #64748b; font-size: 13px; margin-top: 16px;">
                                💡 <strong>Tip:</strong> This shortcode is typically placed on a single page template. 
                                The room ID comes from the URL (e.g., /room/?unit_id=123).
                            </p>
                        </div>
                    </div>
                    
                    <div class="gas-builder-preview">
                        <h3 style="margin-top: 0;">Generated Shortcode</h3>
                        <div class="gas-shortcode-output" id="shortcode-output">
                            [gas_search]
                            <button type="button" class="gas-copy-btn" onclick="copyShortcode()">📋 Copy</button>
                        </div>
                        
                        <h3>Live Preview</h3>
                        <div class="gas-preview-frame" id="preview-frame">
                            <!-- Preview will be rendered here -->
                        </div>
                    </div>
                </div>
                
                <script>
                    var currentWidget = 'search';
                    
                    function selectWidget(type) {
                        currentWidget = type;
                        
                        // Update button states
                        document.querySelectorAll('.gas-widget-btn').forEach(btn => {
                            btn.classList.toggle('active', btn.dataset.widget === type);
                        });
                        
                        // Show/hide option panels
                        document.querySelectorAll('.gas-options-panel').forEach(panel => {
                            panel.style.display = 'none';
                        });
                        document.getElementById('options-' + type).style.display = 'block';
                        
                        updateShortcode();
                    }
                    
                    function updateShortcode() {
                        var shortcode = '';
                        var previewHtml = '';
                        
                        if (currentWidget === 'search') {
                            shortcode = buildSearchShortcode();
                            previewHtml = buildSearchPreview();
                        } else if (currentWidget === 'rooms') {
                            shortcode = buildRoomsShortcode();
                            previewHtml = '<div style="text-align: center; padding: 40px; color: #64748b;"><span style="font-size: 48px;">🏠</span><br><br>Rooms grid with ' + document.getElementById('rooms-columns').value + ' columns' + (document.getElementById('rooms-show-map').checked ? ' + map' : '') + '</div>';
                        } else if (currentWidget === 'room') {
                            shortcode = buildRoomShortcode();
                            previewHtml = '<div style="text-align: center; padding: 40px; color: #64748b;"><span style="font-size: 48px;">🛏️</span><br><br>Room detail page with gallery, booking form' + (document.getElementById('room-show-map').checked ? ', and map' : '') + '</div>';
                        }
                        
                        document.getElementById('shortcode-output').innerHTML = shortcode + '<button type="button" class="gas-copy-btn" onclick="copyShortcode()">📋 Copy</button>';
                        document.getElementById('preview-frame').innerHTML = previewHtml;
                    }
                    
                    function buildSearchShortcode() {
                        var parts = ['[gas_search'];
                        
                        var layout = document.getElementById('search-layout').value;
                        if (layout !== 'vertical') parts.push('layout="' + layout + '"');
                        
                        var maxWidth = document.getElementById('search-max-width').value;
                        if (maxWidth !== '600px') parts.push('max_width="' + maxWidth + '"');
                        
                        if (document.getElementById('search-location').checked) {
                            parts.push('show_location="true"');
                            var placeholder = document.getElementById('search-location-placeholder').value;
                            if (placeholder !== 'Where are you going?') parts.push('location_placeholder="' + placeholder + '"');
                        }
                        
                        var maxGuests = document.getElementById('search-max-guests').value;
                        if (maxGuests !== '10') parts.push('max_guests="' + maxGuests + '"');
                        
                        var buttonText = document.getElementById('search-button-text').value;
                        if (buttonText !== 'Search') parts.push('button_text="' + buttonText + '"');
                        
                        if (document.getElementById('search-button-full').checked) parts.push('button_full_width="true"');
                        
                        var primaryColor = document.getElementById('search-primary-color').value;
                        if (primaryColor !== '#2563eb') parts.push('primary_color="' + primaryColor + '"');
                        
                        var bgColor = document.getElementById('search-bg-color').value;
                        if (bgColor !== '#ffffff') parts.push('background_color="' + bgColor + '"');
                        
                        var borderRadius = document.getElementById('search-border-radius').value;
                        if (borderRadius !== '12px') parts.push('border_radius="' + borderRadius + '"');
                        
                        var customClass = document.getElementById('search-class').value;
                        if (customClass) parts.push('class="' + customClass + '"');
                        
                        return parts.join(' ') + ']';
                    }
                    
                    function buildSearchPreview() {
                        var layout = document.getElementById('search-layout').value;
                        var showLocation = document.getElementById('search-location').checked;
                        var locationPlaceholder = document.getElementById('search-location-placeholder').value;
                        var buttonText = document.getElementById('search-button-text').value;
                        var primaryColor = document.getElementById('search-primary-color').value;
                        var bgColor = document.getElementById('search-bg-color').value;
                        var borderRadius = document.getElementById('search-border-radius').value;
                        var buttonFull = document.getElementById('search-button-full').checked;
                        var maxWidth = document.getElementById('search-max-width').value;
                        
                        var html = '<div class="gas-preview-widget ' + layout + '" style="background: ' + bgColor + '; padding: 20px; border-radius: ' + borderRadius + '; max-width: ' + maxWidth + '; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">';
                        html += '<div class="fields">';
                        
                        if (showLocation) {
                            html += '<div class="field"><label style="color: #1e293b;">Location</label><input type="text" placeholder="' + locationPlaceholder + '" /></div>';
                        }
                        
                        html += '<div class="field"><label style="color: #1e293b;">Check-in</label><input type="text" placeholder="Select date" /></div>';
                        html += '<div class="field"><label style="color: #1e293b;">Check-out</label><input type="text" placeholder="Select date" /></div>';
                        html += '<div class="field"><label style="color: #1e293b;">Guests</label><select><option>1 Guest</option><option>2 Guests</option></select></div>';
                        
                        var btnStyle = 'background: ' + primaryColor + ';';
                        if (buttonFull && layout === 'vertical') btnStyle += ' width: 100%;';
                        html += '<div class="field submit-field"><button class="preview-btn" style="' + btnStyle + '">' + buttonText + '</button></div>';
                        
                        html += '</div></div>';
                        return html;
                    }
                    
                    function buildRoomsShortcode() {
                        var parts = ['[gas_rooms'];
                        
                        var columns = document.getElementById('rooms-columns').value;
                        if (columns !== '3') parts.push('columns="' + columns + '"');
                        
                        if (!document.getElementById('rooms-show-map').checked) parts.push('show_map="false"');
                        
                        var propertyId = document.getElementById('rooms-property-id').value;
                        if (propertyId) parts.push('property_id="' + propertyId + '"');
                        
                        return parts.join(' ') + ']';
                    }
                    
                    function buildRoomShortcode() {
                        var parts = ['[gas_room'];
                        
                        var unitId = document.getElementById('room-unit-id').value;
                        if (unitId) parts.push('unit_id="' + unitId + '"');
                        
                        if (!document.getElementById('room-show-map').checked) parts.push('show_map="false"');
                        
                        return parts.join(' ') + ']';
                    }
                    
                    function copyShortcode() {
                        var output = document.getElementById('shortcode-output');
                        var text = output.innerText.replace('📋 Copy', '').trim();
                        
                        navigator.clipboard.writeText(text).then(function() {
                            var btn = output.querySelector('.gas-copy-btn');
                            btn.innerText = '✓ Copied!';
                            btn.classList.add('copied');
                            setTimeout(function() {
                                btn.innerText = '📋 Copy';
                                btn.classList.remove('copied');
                            }, 2000);
                        });
                    }
                    
                    // Sync color inputs
                    document.getElementById('search-primary-color').addEventListener('input', function() {
                        document.getElementById('search-primary-color-text').value = this.value;
                        updateShortcode();
                    });
                    document.getElementById('search-bg-color').addEventListener('input', function() {
                        document.getElementById('search-bg-color-text').value = this.value;
                        updateShortcode();
                    });
                    
                    // Initialize
                    updateShortcode();
                </script>
                
            <?php elseif ($active_tab === 'shortcodes') : ?>
                <!-- SHORTCODES TAB -->
                <h2>📋 Available Shortcodes</h2>
                <table class="widefat" style="max-width: 900px;">
                    <thead>
                        <tr><th>Shortcode</th><th>Description</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>[gas_search]</code></td>
                            <td><strong>Search Widget</strong> - Date/guest selector for your homepage</td>
                        </tr>
                        <tr>
                            <td><code>[gas_rooms]</code></td>
                            <td><strong>Rooms Grid</strong> - Shows all rooms with map <em>(for Book Now page)</em></td>
                        </tr>
                        <tr>
                            <td><code>[gas_room]</code></td>
                            <td><strong>Room Detail</strong> - Single room page with booking form</td>
                        </tr>
                    </tbody>
                </table>
                
                <hr>
                <h2>🎨 Search Widget Options</h2>
                <p>Example: <code>[gas_search layout="horizontal" show_location="true" primary_color="#ff6600"]</code></p>
                <table class="widefat" style="max-width: 900px;">
                    <thead>
                        <tr><th>Option</th><th>Values</th><th>Default</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>layout</code></td><td>vertical, horizontal, inline</td><td>vertical</td></tr>
                        <tr><td><code>show_location</code></td><td>true, false</td><td>false</td></tr>
                        <tr><td><code>width</code></td><td>Any CSS width</td><td>100%</td></tr>
                        <tr><td><code>max_width</code></td><td>Any CSS width</td><td>600px</td></tr>
                        <tr><td><code>button_text</code></td><td>Any text</td><td>Search</td></tr>
                        <tr><td><code>button_full_width</code></td><td>true, false</td><td>false</td></tr>
                        <tr><td><code>primary_color</code></td><td>Any color</td><td>#2563eb</td></tr>
                        <tr><td><code>background_color</code></td><td>Any color</td><td>white</td></tr>
                        <tr><td><code>border_radius</code></td><td>Any CSS radius</td><td>12px</td></tr>
                        <tr><td><code>class</code></td><td>Custom CSS class</td><td>-</td></tr>
                    </tbody>
                </table>
                
                <hr>
                <h2>🗺️ Rooms Grid Options</h2>
                <p>Example: <code>[gas_rooms columns="3" show_map="true"]</code></p>
                <table class="widefat" style="max-width: 900px;">
                    <thead>
                        <tr><th>Option</th><th>Values</th><th>Default</th></tr>
                    </thead>
                    <tbody>
                        <tr><td><code>columns</code></td><td>1, 2, 3, 4</td><td>3</td></tr>
                        <tr><td><code>show_map</code></td><td>true, false</td><td>true</td></tr>
                        <tr><td><code>property_id</code></td><td>Property ID number</td><td>all</td></tr>
                    </tbody>
                </table>
                
            <?php elseif ($active_tab === 'css') : ?>
                <!-- CUSTOM CSS TAB -->
                <form method="post" action="options.php">
                    <?php settings_fields('gas_booking_css'); ?>
                    
                    <p style="background: #e7f3ff; padding: 15px; border-radius: 8px; border-left: 4px solid #2563eb;">
                        💡 <strong>Tip:</strong> Add custom CSS to style any component. Use the CSS selectors shown below each box. Changes apply site-wide.
                    </p>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(450px, 1fr)); gap: 20px; margin-top: 20px;">
                        
                        <!-- Global CSS -->
                        <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                            <h3 style="margin-top: 0;">🌐 Global / Variables</h3>
                            <p class="description">Override CSS variables and global styles</p>
                            <textarea name="gas_css_global" rows="8" style="width: 100%; font-family: monospace; font-size: 13px;"><?php echo esc_textarea(get_option('gas_css_global', '')); ?></textarea>
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #2563eb;">View CSS Variables</summary>
                                <pre style="background: #f5f5f5; padding: 10px; font-size: 11px; overflow-x: auto;">:root {
  --gas-primary: #2563eb;
  --gas-primary-dark: #1d4ed8;
  --gas-text: #1e293b;
  --gas-text-light: #64748b;
  --gas-border: #e2e8f0;
  --gas-bg: #f8fafc;
  --gas-radius: 8px;
  --gas-radius-lg: 12px;
}</pre>
                            </details>
                        </div>
                        
                        <!-- Search Widget CSS -->
                        <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                            <h3 style="margin-top: 0;">🔍 Search Widget</h3>
                            <p class="description">Style the search/booking widget on homepage</p>
                            <textarea name="gas_css_search_widget" rows="8" style="width: 100%; font-family: monospace; font-size: 13px;"><?php echo esc_textarea(get_option('gas_css_search_widget', '')); ?></textarea>
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #2563eb;">View Selectors</summary>
                                <pre style="background: #f5f5f5; padding: 10px; font-size: 11px;">.gas-search-widget { }
.gas-search-vertical { }
.gas-search-horizontal { }
.gas-search-inline { }
.gas-search-field { }
.gas-search-field label { }
.gas-search-field input { }
.gas-search-field select { }
.gas-search-button { }</pre>
                            </details>
                        </div>
                        
                        <!-- Room Cards CSS -->
                        <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                            <h3 style="margin-top: 0;">🏠 Room Cards</h3>
                            <p class="description">Style the room cards in the grid</p>
                            <textarea name="gas_css_room_cards" rows="8" style="width: 100%; font-family: monospace; font-size: 13px;"><?php echo esc_textarea(get_option('gas_css_room_cards', '')); ?></textarea>
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #2563eb;">View Selectors</summary>
                                <pre style="background: #f5f5f5; padding: 10px; font-size: 11px;">.gas-rooms-grid { }
.gas-room-card { }
.gas-room-card:hover { }
.gas-room-image { }
.gas-room-details { }
.gas-room-details h3 { }
.gas-room-property { }
.gas-room-meta { }
.gas-room-price { }
.gas-view-btn { }</pre>
                            </details>
                        </div>
                        
                        <!-- Rooms Grid/Filter CSS -->
                        <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                            <h3 style="margin-top: 0;">📋 Rooms Page Layout</h3>
                            <p class="description">Style the rooms page filter and layout</p>
                            <textarea name="gas_css_rooms_grid" rows="8" style="width: 100%; font-family: monospace; font-size: 13px;"><?php echo esc_textarea(get_option('gas_css_rooms_grid', '')); ?></textarea>
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #2563eb;">View Selectors</summary>
                                <pre style="background: #f5f5f5; padding: 10px; font-size: 11px;">.gas-rooms-page-wrapper { }
.gas-rooms-wrapper { }
.gas-rooms-list { }
.gas-date-filter { }
.gas-filter-field { }
.gas-filter-btn { }</pre>
                            </details>
                        </div>
                        
                        <!-- Room Detail CSS -->
                        <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                            <h3 style="margin-top: 0;">🛏️ Room Detail Page</h3>
                            <p class="description">Style the single room detail page</p>
                            <textarea name="gas_css_room_detail" rows="8" style="width: 100%; font-family: monospace; font-size: 13px;"><?php echo esc_textarea(get_option('gas_css_room_detail', '')); ?></textarea>
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #2563eb;">View Selectors</summary>
                                <pre style="background: #f5f5f5; padding: 10px; font-size: 11px;">.gas-room-widget { }
.gas-room-layout { }
.gas-room-main { }
.gas-room-sidebar { }
.gas-room-header { }
.gas-room-title { }
.gas-gallery { }
.gas-tabs { }
.gas-tab-btn { }
.gas-description { }</pre>
                            </details>
                        </div>
                        
                        <!-- Booking Form CSS -->
                        <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                            <h3 style="margin-top: 0;">📝 Booking Form</h3>
                            <p class="description">Style the booking card and form</p>
                            <textarea name="gas_css_booking_form" rows="8" style="width: 100%; font-family: monospace; font-size: 13px;"><?php echo esc_textarea(get_option('gas_css_booking_form', '')); ?></textarea>
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #2563eb;">View Selectors</summary>
                                <pre style="background: #f5f5f5; padding: 10px; font-size: 11px;">.gas-booking-card { }
.gas-booking-card-header { }
.gas-price-display { }
.gas-date-inputs { }
.gas-date-field { }
.gas-guest-field { }
.gas-price-breakdown { }
.gas-book-btn { }
.gas-booking-form { }
.gas-submit-btn { }</pre>
                            </details>
                        </div>
                        
                        <!-- Calendar CSS -->
                        <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                            <h3 style="margin-top: 0;">📅 Availability Calendar</h3>
                            <p class="description">Style the availability calendar</p>
                            <textarea name="gas_css_calendar" rows="8" style="width: 100%; font-family: monospace; font-size: 13px;"><?php echo esc_textarea(get_option('gas_css_calendar', '')); ?></textarea>
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #2563eb;">View Selectors</summary>
                                <pre style="background: #f5f5f5; padding: 10px; font-size: 11px;">.gas-calendar-container { }
.gas-calendar { }
.gas-calendar-header { }
.gas-calendar-grid { }
.gas-cal-day { }
.gas-cal-day.available { }
.gas-cal-day.unavailable { }
.gas-calendar-legend { }</pre>
                            </details>
                        </div>
                        
                        <!-- Map CSS -->
                        <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                            <h3 style="margin-top: 0;">🗺️ Map</h3>
                            <p class="description">Style the map and markers</p>
                            <textarea name="gas_css_map" rows="8" style="width: 100%; font-family: monospace; font-size: 13px;"><?php echo esc_textarea(get_option('gas_css_map', '')); ?></textarea>
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #2563eb;">View Selectors</summary>
                                <pre style="background: #f5f5f5; padding: 10px; font-size: 11px;">.gas-rooms-map-panel { }
.gas-rooms-map { }
.gas-map-container { }
.gas-map { }
.gas-marker-pin { }
.gas-map-popup { }
.gas-map-popup-title { }
.gas-map-popup-link { }</pre>
                            </details>
                        </div>
                        
                        <!-- Buttons CSS -->
                        <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                            <h3 style="margin-top: 0;">🔘 Buttons</h3>
                            <p class="description">Style all buttons globally</p>
                            <textarea name="gas_css_buttons" rows="8" style="width: 100%; font-family: monospace; font-size: 13px;"><?php echo esc_textarea(get_option('gas_css_buttons', '')); ?></textarea>
                            <details style="margin-top: 10px;">
                                <summary style="cursor: pointer; color: #2563eb;">View Selectors</summary>
                                <pre style="background: #f5f5f5; padding: 10px; font-size: 11px;">.gas-search-button { }
.gas-filter-btn { }
.gas-view-btn { }
.gas-book-btn { }
.gas-submit-btn { }
.gas-tab-btn { }
.gas-tab-btn.active { }</pre>
                            </details>
                        </div>
                        
                    </div>
                    
                    <?php submit_button('Save Custom CSS'); ?>
                </form>
                
            <?php elseif ($active_tab === 'ai') : ?>
                <!-- AI INTEGRATION TAB -->
                <h2>🤖 AI Builder Integration</h2>
                <p>This plugin is designed to work seamlessly with AI website builders. Here's how AI tools can customize the booking system:</p>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; margin-top: 20px;">
                    
                    <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                        <h3 style="margin-top: 0;">📝 Shortcode Customization</h3>
                        <p>AI can generate shortcodes with inline styling:</p>
                        <pre style="background: #1e293b; color: #e2e8f0; padding: 15px; border-radius: 8px; overflow-x: auto; font-size: 12px;">[gas_search 
    layout="horizontal"
    primary_color="#your-brand-color"
    background_color="#f5f5f5"
    border_radius="20px"
    class="ai-custom-search"
]</pre>
                    </div>
                    
                    <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                        <h3 style="margin-top: 0;">🎨 CSS Class Hooks</h3>
                        <p>All components have semantic CSS classes for targeting:</p>
                        <pre style="background: #1e293b; color: #e2e8f0; padding: 15px; border-radius: 8px; overflow-x: auto; font-size: 12px;">/* AI can add to theme CSS */
.gas-search-widget {
    /* Search widget styles */
}
.gas-room-card {
    /* Room card styles */
}
.gas-booking-card {
    /* Booking form styles */
}</pre>
                    </div>
                    
                    <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                        <h3 style="margin-top: 0;">🔧 CSS Variables</h3>
                        <p>Override theme colors using CSS variables:</p>
                        <pre style="background: #1e293b; color: #e2e8f0; padding: 15px; border-radius: 8px; overflow-x: auto; font-size: 12px;">:root {
    --gas-primary: #ff6600;
    --gas-primary-dark: #cc5200;
    --gas-radius: 16px;
    --gas-radius-lg: 24px;
}</pre>
                    </div>
                    
                    <div style="background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                        <h3 style="margin-top: 0;">📋 Complete Class Reference</h3>
                        <p>Full list of CSS classes available:</p>
                        <div style="max-height: 200px; overflow-y: auto; background: #f5f5f5; padding: 10px; border-radius: 4px; font-size: 11px; font-family: monospace;">
                            <strong>Search:</strong> .gas-search-widget, .gas-search-vertical, .gas-search-horizontal, .gas-search-inline, .gas-search-field, .gas-search-button<br><br>
                            <strong>Rooms Grid:</strong> .gas-rooms-page-wrapper, .gas-rooms-wrapper, .gas-rooms-list, .gas-rooms-grid, .gas-rooms-map-panel, .gas-date-filter<br><br>
                            <strong>Room Cards:</strong> .gas-room-card, .gas-room-image, .gas-room-details, .gas-room-property, .gas-room-meta, .gas-room-price, .gas-view-btn<br><br>
                            <strong>Room Detail:</strong> .gas-room-widget, .gas-room-layout, .gas-room-main, .gas-room-sidebar, .gas-room-header, .gas-room-title, .gas-gallery, .gas-lightbox<br><br>
                            <strong>Tabs:</strong> .gas-tabs, .gas-tabs-nav, .gas-tab-btn, .gas-tab-content<br><br>
                            <strong>Booking:</strong> .gas-booking-card, .gas-price-display, .gas-date-inputs, .gas-book-btn, .gas-booking-form, .gas-submit-btn<br><br>
                            <strong>Calendar:</strong> .gas-calendar-container, .gas-calendar, .gas-calendar-header, .gas-calendar-grid, .gas-cal-day<br><br>
                            <strong>Map:</strong> .gas-rooms-map, .gas-map-container, .gas-map, .gas-marker-pin, .gas-map-popup
                        </div>
                    </div>
                    
                </div>
                
                <hr>
                <h3>🚀 AI Prompt Example</h3>
                <p>Here's a prompt AI builders can use:</p>
                <div style="background: #fef3c7; padding: 20px; border-radius: 8px; border: 1px solid #f59e0b;">
                    <em>"Create a hotel booking page using the GAS Booking plugin. Use [gas_search layout="horizontal"] on the homepage hero section with a dark background overlay. On the /book-now/ page, use [gas_rooms] to show available rooms. Style the .gas-room-card with rounded corners and subtle shadows. Use brand color #2563eb for all .gas-search-button and .gas-book-btn elements."</em>
                </div>
                
            <?php endif; ?>
            
            </div>
        </div>
        <?php
    }
    
    public function enqueue_scripts() {
        // Flatpickr date picker
        wp_enqueue_style('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css', array(), '4.6.13');
        wp_enqueue_script('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr', array(), '4.6.13', true);
        
        // Leaflet map library
        wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', array(), '1.9.4');
        wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', array(), '1.9.4', true);
        
        wp_enqueue_style('gas-booking', GAS_BOOKING_PLUGIN_URL . 'assets/css/gas-booking.css', array('flatpickr', 'leaflet'), GAS_BOOKING_VERSION);
        wp_enqueue_script('gas-booking', GAS_BOOKING_PLUGIN_URL . 'assets/js/gas-booking.js', array('jquery', 'flatpickr', 'leaflet'), GAS_BOOKING_VERSION, true);
        
        wp_localize_script('gas-booking', 'gasBooking', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'apiUrl' => get_option('gas_api_url', 'https://gas-booking-production.up.railway.app'),
            'clientId' => get_option('gas_client_id', ''),
            'roomUrlBase' => get_option('gas_room_url_base', '/room/'),
            'searchResultsUrl' => get_option('gas_search_results_url', '/book-now/'),
            'checkoutUrl' => get_option('gas_checkout_url', '/checkout/'),
            'currency' => get_option('gas_currency_symbol', '£'),
            'nonce' => wp_create_nonce('gas_booking_nonce')
        ));
        
        // Output custom CSS from settings - add to footer so it overrides inline styles
        add_action('wp_footer', array($this, 'output_custom_css'));
    }
    
    /**
     * Output custom CSS in footer to override inline styles
     */
    public function output_custom_css() {
        $custom_css = '';
        
        $css_sections = array(
            'gas_css_global',
            'gas_css_search_widget',
            'gas_css_room_cards',
            'gas_css_rooms_grid',
            'gas_css_room_detail',
            'gas_css_booking_form',
            'gas_css_calendar',
            'gas_css_map',
            'gas_css_buttons'
        );
        
        foreach ($css_sections as $section) {
            $css = get_option($section, '');
            if (!empty(trim($css))) {
                $custom_css .= "/* " . str_replace('gas_css_', '', $section) . " */\n" . $css . "\n\n";
            }
        }
        
        if (!empty($custom_css)) {
            echo "\n<style id=\"gas-custom-css\">\n" . $custom_css . "</style>\n";
        }
    }
    
    /**
     * Search Bar Shortcode
     */
    public function search_shortcode($atts) {
        $atts = shortcode_atts(array(
            // Layout options
            'layout' => 'vertical',          // vertical, horizontal, inline
            'width' => '100%',               // Any CSS width value
            'max_width' => '600px',          // Max width for widget
            
            // Field options
            'show_location' => 'false',      // Show location/destination field
            'location_label' => 'Location',
            'location_placeholder' => 'Where are you going?',
            'checkin_label' => 'Check-in',
            'checkout_label' => 'Check-out',
            'guests_label' => 'Guests',
            'max_guests' => get_option('gas_max_guests_dropdown', '10'),
            
            // Button options  
            'button_text' => 'Search',
            'button_full_width' => 'false',  // Button spans full width (for vertical)
            
            // Color customization
            'primary_color' => '',           // Button background color
            'text_color' => '',              // Button text color
            'background_color' => '',        // Widget background
            'border_color' => '',            // Input border color
            'label_color' => '',             // Label text color
            'border_radius' => '',           // Border radius for widget
            
            // Custom CSS class
            'class' => '',                   // Additional CSS class for AI builders
            'css' => ''                      // Inline custom CSS
        ), $atts);
        
        // Generate unique ID for this widget instance
        $widget_id = 'gas-search-' . wp_rand(1000, 9999);
        
        // Determine layout class
        $layout_class = 'gas-search-' . $atts['layout'];
        $custom_class = !empty($atts['class']) ? ' ' . esc_attr($atts['class']) : '';
        $show_location = $atts['show_location'] === 'true';
        $button_full = $atts['button_full_width'] === 'true';
        
        // Build inline styles
        $widget_styles = array();
        if (!empty($atts['width'])) $widget_styles[] = 'width: ' . esc_attr($atts['width']);
        if (!empty($atts['max_width'])) $widget_styles[] = 'max-width: ' . esc_attr($atts['max_width']);
        if (!empty($atts['background_color'])) $widget_styles[] = 'background-color: ' . esc_attr($atts['background_color']);
        if (!empty($atts['border_radius'])) $widget_styles[] = 'border-radius: ' . esc_attr($atts['border_radius']);
        
        $widget_style_attr = !empty($widget_styles) ? ' style="' . implode('; ', $widget_styles) . '"' : '';
        
        ob_start();
        ?>
        <?php if (!empty($atts['primary_color']) || !empty($atts['text_color']) || !empty($atts['border_color']) || !empty($atts['label_color']) || !empty($atts['css'])) : ?>
        <style>
            <?php if (!empty($atts['primary_color'])) : ?>
            #<?php echo $widget_id; ?> .gas-search-button { background-color: <?php echo esc_attr($atts['primary_color']); ?>; }
            #<?php echo $widget_id; ?> .gas-search-button:hover { background-color: <?php echo esc_attr($atts['primary_color']); ?>; filter: brightness(0.9); }
            <?php endif; ?>
            <?php if (!empty($atts['text_color'])) : ?>
            #<?php echo $widget_id; ?> .gas-search-button { color: <?php echo esc_attr($atts['text_color']); ?>; }
            <?php endif; ?>
            <?php if (!empty($atts['border_color'])) : ?>
            #<?php echo $widget_id; ?> .gas-search-field input,
            #<?php echo $widget_id; ?> .gas-search-field select { border-color: <?php echo esc_attr($atts['border_color']); ?>; }
            <?php endif; ?>
            <?php if (!empty($atts['label_color'])) : ?>
            #<?php echo $widget_id; ?> .gas-search-field label { color: <?php echo esc_attr($atts['label_color']); ?>; }
            <?php endif; ?>
            <?php if (!empty($atts['css'])) : ?>
            #<?php echo $widget_id; ?> { <?php echo wp_strip_all_tags($atts['css']); ?> }
            <?php endif; ?>
        </style>
        <?php endif; ?>
        
        <div id="<?php echo $widget_id; ?>" class="gas-search-widget <?php echo $layout_class . $custom_class; ?>"<?php echo $widget_style_attr; ?>>
            <div class="gas-search-fields">
                <?php if ($show_location) : ?>
                <div class="gas-search-field gas-search-location">
                    <label><?php echo esc_html($atts['location_label']); ?></label>
                    <input type="text" class="gas-location-input" placeholder="<?php echo esc_attr($atts['location_placeholder']); ?>" />
                </div>
                <?php endif; ?>
                
                <div class="gas-search-field gas-search-checkin">
                    <label><?php echo esc_html($atts['checkin_label']); ?></label>
                    <input type="text" class="gas-checkin-date" placeholder="Select date" readonly />
                </div>
                
                <div class="gas-search-field gas-search-checkout">
                    <label><?php echo esc_html($atts['checkout_label']); ?></label>
                    <input type="text" class="gas-checkout-date" placeholder="Select date" readonly />
                </div>
                
                <div class="gas-search-field gas-search-guests">
                    <label><?php echo esc_html($atts['guests_label']); ?></label>
                    <select class="gas-guests-select">
                        <?php for ($i = 1; $i <= intval($atts['max_guests']); $i++) : ?>
                            <option value="<?php echo $i; ?>"><?php echo $i; ?> Guest<?php echo $i > 1 ? 's' : ''; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <div class="gas-search-field gas-search-submit<?php echo $button_full ? ' gas-button-full' : ''; ?>">
                    <button type="button" class="gas-search-button"><?php echo esc_html($atts['button_text']); ?></button>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Room Listing Shortcode - Shows rooms with availability check
     */
    public function rooms_shortcode($atts) {
        $atts = shortcode_atts(array(
            'client_id' => get_option('gas_client_id', ''),
            'property_id' => '',
            'columns' => 3,
            'show_map' => 'true',
            'limit' => 0,           // 0 = show all
            'random' => 'false',    // Randomize order
            'room_ids' => '',       // Comma-separated room IDs to show
        ), $atts);
        
        $client_id = $atts['client_id'];
        $show_map = $atts['show_map'] === 'true';
        $limit = intval($atts['limit']);
        $random = $atts['random'] === 'true';
        $room_ids = !empty($atts['room_ids']) ? array_map('intval', explode(',', $atts['room_ids'])) : array();
        
        if (empty($client_id)) {
            return '<div style="padding: 40px; text-align: center; background: #fff3cd; border: 1px solid #ffc107; border-radius: 8px;">
                <h3 style="margin: 0 0 10px;">⚠️ Setup Required</h3>
                <p>Please set your <strong>Client Account ID</strong> in WordPress Admin → Settings → GAS Booking</p>
            </div>';
        }
        
        // Get dates from URL if passed from search
        $checkin = isset($_GET['checkin']) ? sanitize_text_field($_GET['checkin']) : '';
        $checkout = isset($_GET['checkout']) ? sanitize_text_field($_GET['checkout']) : '';
        $guests = isset($_GET['guests']) ? intval($_GET['guests']) : 1;
        
        // Fetch rooms from API
        $api_url = get_option('gas_api_url', 'https://gas-booking-production.up.railway.app');
        $endpoint = "{$api_url}/api/public/client/{$client_id}/rooms";
        
        if (!empty($atts['property_id'])) {
            $endpoint .= "?property_id=" . intval($atts['property_id']);
        }
        
        $response = wp_remote_get($endpoint, array(
            'timeout' => 30,
            'sslverify' => false
        ));
        
        if (is_wp_error($response)) {
            return '<div style="padding: 20px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 8px; color: #721c24;">
                <strong>Connection Error:</strong> ' . esc_html($response->get_error_message()) . '
            </div>';
        }
        
        $http_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($http_code !== 200 || !isset($data['success']) || !$data['success']) {
            $error_msg = $data['error'] ?? 'API returned status ' . $http_code;
            return '<div style="padding: 20px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 8px; color: #721c24;">
                <strong>API Error:</strong> ' . esc_html($error_msg) . '<br>
                <small>Endpoint: ' . esc_html($endpoint) . '</small>
            </div>';
        }
        
        $rooms = $data['rooms'] ?? array();
        
        if (empty($rooms)) {
            return '<div style="padding: 40px; text-align: center; background: #e7f3ff; border: 1px solid #b6d4fe; border-radius: 8px;">
                <h3 style="margin: 0 0 10px;">No Rooms Found</h3>
                <p>No rooms are currently available. Check that properties are assigned to Client ID ' . esc_html($client_id) . '</p>
            </div>';
        }
        
        // Filter by specific room IDs if provided
        if (!empty($room_ids)) {
            $rooms = array_filter($rooms, function($room) use ($room_ids) {
                return in_array($room['id'], $room_ids);
            });
            $rooms = array_values($rooms); // Re-index array
        }
        
        // Randomize if requested
        if ($random) {
            shuffle($rooms);
        }
        
        // Limit number of rooms if specified
        if ($limit > 0 && count($rooms) > $limit) {
            $rooms = array_slice($rooms, 0, $limit);
        }
        
        // Check if any rooms have coordinates for the map
        $has_coordinates = false;
        foreach ($rooms as $room) {
            if (!empty($room['latitude']) && !empty($room['longitude'])) {
                $has_coordinates = true;
                break;
            }
        }
        
        $currency = get_option('gas_currency_symbol', '£');
        $room_url_base = get_option('gas_room_url_base', '/room/');
        $columns = intval($atts['columns']);
        
        // If showing map, use 3 columns for the grid
        $grid_columns = ($show_map && $has_coordinates) ? 3 : $columns;
        
        ob_start();
        ?>
        <style>
        /* Rooms page wrapper - split view - break out of container */
        .gas-rooms-page-wrapper {
            max-width: 1600px;
            margin: 0 auto;
            padding: 0 16px;
            padding-top: 100px;
            width: 100vw;
            position: relative;
            left: 50%;
            right: 50%;
            margin-left: -50vw;
            margin-right: -50vw;
            box-sizing: border-box;
        }
        
        /* When embedded in a section (like Featured Rooms on homepage) */
        .developer-section .gas-rooms-page-wrapper,
        .developer-featured .gas-rooms-page-wrapper {
            padding-top: 0;
            width: 100%;
            left: auto;
            right: auto;
            margin-left: auto;
            margin-right: auto;
            position: static;
        }
        
        .developer-section .gas-date-filter,
        .developer-featured .gas-date-filter {
            display: none; /* Hide search bar in featured section */
        }
        
        .developer-section .gas-rooms-grid,
        .developer-featured .gas-rooms-grid {
            justify-content: center;
        }
        
        .gas-rooms-wrapper {
            display: flex;
            gap: 24px;
            align-items: flex-start;
            width: 100%;
            max-width: 1600px;
            margin: 0 auto;
        }
        .gas-rooms-list {
            flex: 1 1 65%;
            min-width: 0;
        }
        .gas-rooms-map-panel {
            flex: 0 0 35%;
            max-width: 400px;
            position: sticky;
            top: 20px;
            align-self: flex-start;
        }
        .gas-rooms-map {
            height: calc(100vh - 180px);
            min-height: 500px;
            max-height: 800px;
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid #e0e0e0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            background: #f0f0f0;
        }
        .gas-rooms-map .leaflet-popup-content-wrapper {
            border-radius: 8px;
        }
        .gas-rooms-map .leaflet-popup-content {
            margin: 12px 16px;
        }
        .gas-map-popup {
            min-width: 200px;
        }
        .gas-map-popup-image {
            width: 100%;
            height: 100px;
            object-fit: cover;
            border-radius: 6px;
            margin-bottom: 8px;
        }
        .gas-map-popup-title {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 4px;
            color: #333;
        }
        .gas-map-popup-property {
            font-size: 12px;
            color: #666;
            margin-bottom: 8px;
        }
        .gas-map-popup-price {
            font-weight: 700;
            font-size: 16px;
            color: #333;
        }
        .gas-map-popup-link {
            display: inline-block;
            margin-top: 8px;
            background: <?php echo esc_attr(get_option('gas_button_color', '#667eea')); ?>;
            color: white !important;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 12px;
            font-weight: 600;
        }
        .gas-map-popup-link:hover {
            filter: brightness(0.9);
            color: white !important;
        }
        /* Tablet and below - stack vertically */
        @media (max-width: 1100px) {
            .gas-rooms-wrapper {
                flex-direction: column;
            }
            .gas-rooms-list {
                flex: 1 1 100%;
                max-width: 100%;
                order: 2;
            }
            .gas-rooms-map-panel {
                flex: 1 1 100%;
                width: 100%;
                position: relative;
                top: 0;
                order: 1;
                margin-bottom: 24px;
            }
            .gas-rooms-map {
                height: 350px;
                min-height: 300px;
            }
        }
        .gas-date-filter {
            background: #f8f9fa;
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            flex-wrap: nowrap;
            gap: 12px;
            align-items: flex-end;
            <?php if (get_option('gas_center_search', '0') === '1') : ?>
            max-width: <?php echo intval(get_option('gas_search_max_width', '800')); ?>px;
            margin-left: auto;
            margin-right: auto;
            justify-content: center;
            <?php endif; ?>
        }
        .gas-date-filter .gas-filter-field {
            flex: 1 1 auto;
            min-width: 120px;
            max-width: 200px;
        }
        .gas-date-filter .gas-filter-field:last-of-type {
            max-width: 140px;
        }
        .gas-date-filter label {
            display: block;
            font-weight: 600;
            margin-bottom: 6px;
            color: #333;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .gas-date-filter input,
        .gas-date-filter select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
        }
        .gas-date-filter .gas-filter-btn {
            background: <?php echo esc_attr(get_option('gas_button_color', '#667eea')); ?>;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
            white-space: nowrap;
            flex-shrink: 0;
        }
        .gas-date-filter .gas-filter-btn:hover {
            filter: brightness(0.9);
        }
        @media (max-width: 768px) {
            .gas-date-filter {
                flex-wrap: wrap;
            }
            .gas-date-filter .gas-filter-field {
                flex: 1 1 calc(50% - 6px);
                max-width: none;
            }
            .gas-date-filter .gas-filter-btn {
                width: 100%;
                margin-top: 8px;
            }
        }
        .gas-rooms-grid {
            display: grid;
            grid-template-columns: repeat(<?php echo $grid_columns; ?>, 1fr);
            gap: 20px;
            margin: 0;
        }
        @media (max-width: 1200px) {
            .gas-rooms-grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 600px) {
            .gas-rooms-grid { grid-template-columns: 1fr; }
        }
        .gas-room-card {
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            overflow: hidden;
            background: #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            transition: all 0.2s ease;
            cursor: pointer;
        }
        .gas-room-card:hover,
        .gas-room-card.highlighted {
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
            transform: translateY(-4px);
            border-color: <?php echo esc_attr(get_option('gas_button_color', '#667eea')); ?>;
        }
        .gas-room-card.unavailable {
            opacity: 0.7;
        }
        .gas-room-card.unavailable .gas-room-image {
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
        }
        .gas-room-card.guest-exceeded {
            opacity: 0.6;
            order: 999;
        }
        .gas-room-card.guest-exceeded .gas-view-btn {
            background: #9ca3af;
            pointer-events: none;
        }
        .gas-too-small {
            color: #ef4444;
            font-size: 13px;
            font-weight: 500;
        }
        .gas-room-image {
            height: 180px;
            background: linear-gradient(135deg, <?php echo esc_attr(get_option('gas_button_color', '#667eea')); ?> 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 48px;
        }
        .gas-room-details {
            padding: 20px;
        }
        .gas-room-details h3 {
            margin: 0 0 8px;
            font-size: 18px;
            color: #333;
        }
        .gas-room-property {
            color: #666;
            font-size: 13px;
            margin-bottom: 12px;
        }
        .gas-room-meta {
            display: flex;
            gap: 12px;
            color: #666;
            font-size: 13px;
            margin-bottom: 16px;
        }
        .gas-room-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 16px;
            border-top: 1px solid #eee;
        }
        .gas-room-price {
            font-size: 22px;
            font-weight: 700;
            color: #333;
        }
        .gas-room-price span {
            font-size: 13px;
            font-weight: 400;
            color: #666;
        }
        .gas-room-price.unavailable-price {
            font-size: 14px;
            color: #dc3545;
            font-weight: 600;
        }
        .gas-view-btn {
            background: <?php echo esc_attr(get_option('gas_button_color', '#667eea')); ?>;
            color: white !important;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: background 0.2s;
        }
        .gas-view-btn:hover {
            filter: brightness(0.9);
            color: white !important;
        }
        .gas-view-btn.unavailable-btn {
            background: #6c757d;
        }
        .gas-view-btn.unavailable-btn:hover {
            background: #5a6268;
        }
        .gas-section-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin: 32px 0 16px;
            padding-bottom: 8px;
            border-bottom: 2px solid <?php echo esc_attr(get_option('gas_button_color', '#667eea')); ?>;
        }
        .gas-section-title.unavailable-title {
            border-bottom-color: #6c757d;
            color: #666;
        }
        </style>
        
        <div class="gas-rooms-page-wrapper">
        <!-- Date Filter -->
        <div class="gas-date-filter">
            <div class="gas-filter-field">
                <label>Check-in</label>
                <input type="text" class="gas-filter-checkin" value="<?php echo esc_attr($checkin); ?>" placeholder="Select date" />
            </div>
            <div class="gas-filter-field">
                <label>Check-out</label>
                <input type="text" class="gas-filter-checkout" value="<?php echo esc_attr($checkout); ?>" placeholder="Select date" />
            </div>
            <div class="gas-filter-field">
                <label>Guests</label>
                <select class="gas-filter-guests">
                    <?php 
                    $max_guests_dropdown = intval(get_option('gas_max_guests_dropdown', '10'));
                    for ($i = 1; $i <= $max_guests_dropdown; $i++) : ?>
                        <option value="<?php echo $i; ?>" <?php selected($guests, $i); ?>><?php echo $i; ?> Guest<?php echo $i > 1 ? 's' : ''; ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <button type="button" class="gas-filter-btn" onclick="gasFilterRooms()">Check Availability</button>
        </div>
        
        <div class="gas-rooms-wrapper">
            <div class="gas-rooms-list">
                <div id="gas-rooms-container">
                    <div class="gas-rooms-grid">
                        <?php foreach ($rooms as $room) : 
                            $room_url = $room_url_base . '?unit_id=' . $room['id'];
                            if ($checkin) $room_url .= '&checkin=' . urlencode($checkin);
                            if ($checkout) $room_url .= '&checkout=' . urlencode($checkout);
                            if ($guests) $room_url .= '&guests=' . intval($guests);
                            
                            $price = floatval($room['base_price'] ?? 0);
                            $max_guests = intval($room['max_guests'] ?? $room['max_adults'] ?? 2);
                            $bedrooms = intval($room['bedroom_count'] ?? 0);
                            $bathrooms = intval($room['bathroom_count'] ?? 0);
                            $image_url = $room['image_url'] ?? '';
                            $lat = $room['latitude'] ?? '';
                            $lng = $room['longitude'] ?? '';
                        ?>
                        <div class="gas-room-card" 
                             data-room-id="<?php echo esc_attr($room['id']); ?>" 
                             data-max-guests="<?php echo $max_guests; ?>" 
                             data-price="<?php echo $price; ?>"
                             data-lat="<?php echo esc_attr($lat); ?>"
                             data-lng="<?php echo esc_attr($lng); ?>"
                             data-url="<?php echo esc_url($room_url); ?>">
                            <?php if (!empty($image_url)) : ?>
                            <div class="gas-room-image" style="background: url('<?php echo esc_url($image_url); ?>') center/cover;"></div>
                            <?php else : ?>
                            <div class="gas-room-image">🏠</div>
                            <?php endif; ?>
                            <div class="gas-room-details">
                                <h3><?php echo esc_html($room['name']); ?></h3>
                                <?php if (!empty($room['property_name'])) : ?>
                                <div class="gas-room-property">📍 <?php echo esc_html($room['property_name']); ?><?php if (!empty($room['city'])) echo ', ' . esc_html($room['city']); ?></div>
                                <?php endif; ?>
                                
                                <div class="gas-room-meta">
                                    <span>👥 <?php echo $max_guests; ?> guest<?php echo $max_guests > 1 ? 's' : ''; ?></span>
                                    <?php if ($bedrooms > 0) : ?>
                                    <span>🛏️ <?php echo $bedrooms; ?> bed<?php echo $bedrooms > 1 ? 's' : ''; ?></span>
                                    <?php endif; ?>
                                    <?php if ($bathrooms > 0) : ?>
                                    <span>🚿 <?php echo $bathrooms; ?> bath</span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="gas-room-footer">
                                    <div class="gas-room-price">
                                        <?php if ($price > 0) : ?>
                                            <?php echo esc_html($currency); ?><?php echo number_format($price, 0); ?>
                                            <span>/ night</span>
                                        <?php else : ?>
                                            <span>Price on request</span>
                                        <?php endif; ?>
                                    </div>
                                    <a href="<?php echo esc_url($room_url); ?>" class="gas-view-btn">View &amp; Book</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <?php if ($show_map && $has_coordinates) : ?>
            <div class="gas-rooms-map-panel">
                <div id="gas-rooms-map" class="gas-rooms-map"></div>
            </div>
            <?php endif; ?>
        </div>
        </div><!-- .gas-rooms-page-wrapper -->
        
        <script type="text/javascript">
        var gasRoomsConfig = <?php echo wp_json_encode(array(
            'checkin' => $checkin,
            'checkout' => $checkout,
            'guests' => intval($guests),
            'apiUrl' => $api_url,
            'currency' => $currency,
            'roomUrlBase' => $room_url_base,
            'showMap' => $show_map && $has_coordinates
        )); ?>;
        
        <?php if ($show_map && $has_coordinates) : ?>
        // Build rooms data for map
        var gasRoomsMapData = <?php 
            $map_rooms = array();
            foreach ($rooms as $room) {
                if (!empty($room['latitude']) && !empty($room['longitude'])) {
                    $room_url = $room_url_base . '?unit_id=' . $room['id'];
                    if ($checkin) $room_url .= '&checkin=' . urlencode($checkin);
                    if ($checkout) $room_url .= '&checkout=' . urlencode($checkout);
                    if ($guests) $room_url .= '&guests=' . intval($guests);
                    
                    $map_rooms[] = array(
                        'id' => $room['id'],
                        'name' => $room['name'],
                        'property_name' => $room['property_name'] ?? '',
                        'price' => floatval($room['base_price'] ?? 0),
                        'image_url' => $room['image_url'] ?? '',
                        'lat' => floatval($room['latitude']),
                        'lng' => floatval($room['longitude']),
                        'url' => $room_url,
                        'property_id' => $room['property_id'] ?? ''
                    );
                }
            }
            echo wp_json_encode($map_rooms);
        ?>;
        <?php endif; ?>
        </script>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Single Room Detail Shortcode
     */
    public function room_shortcode($atts) {
        $atts = shortcode_atts(array(
            'unit_id' => '',
            'show_map' => 'true'
        ), $atts);
        
        $unit_id = !empty($atts['unit_id']) ? $atts['unit_id'] : (isset($_GET['unit_id']) ? intval($_GET['unit_id']) : '');
        $show_map = $atts['show_map'] === 'true';
        
        if (empty($unit_id)) {
            return '<p class="gas-error">Room ID not specified. Use: <code>[gas_room unit_id="123"]</code> or add <code>?unit_id=123</code> to the URL.</p>';
        }
        
        // Get dates from URL if passed
        $checkin = isset($_GET['checkin']) ? sanitize_text_field($_GET['checkin']) : '';
        $checkout = isset($_GET['checkout']) ? sanitize_text_field($_GET['checkout']) : '';
        $guests = isset($_GET['guests']) ? intval($_GET['guests']) : 1;
        
        $currency = get_option('gas_currency_symbol', '$');
        $button_color = get_option('gas_button_color', '#667eea');
        
        ob_start();
        ?>
        <style>
        /* Dynamic button color from settings */
        :root {
            --gas-primary: <?php echo esc_attr($button_color); ?>;
            --gas-primary-dark: <?php echo esc_attr($button_color); ?>;
        }
        .gas-book-btn {
            background: <?php echo esc_attr($button_color); ?> !important;
        }
        .gas-book-btn:hover:not(:disabled) {
            background: <?php echo esc_attr($button_color); ?> !important;
            filter: brightness(0.9);
        }
        .gas-tab-btn.active {
            background: <?php echo esc_attr($button_color); ?> !important;
            color: white !important;
        }
        .gas-submit-btn {
            background: <?php echo esc_attr($button_color); ?> !important;
        }
        .gas-submit-btn:hover {
            filter: brightness(0.9);
        }
        </style>
        <div class="gas-room-widget" data-unit-id="<?php echo esc_attr($unit_id); ?>" data-checkin="<?php echo esc_attr($checkin); ?>" data-checkout="<?php echo esc_attr($checkout); ?>" data-guests="<?php echo esc_attr($guests); ?>" data-show-map="<?php echo $show_map ? 'true' : 'false'; ?>">
            <div class="gas-room-loading">
                <div class="gas-spinner"></div>
                <p style="margin-top: 16px;">Loading room details...</p>
            </div>
            
            <div class="gas-room-content" style="display:none;">
                <!-- Image Gallery - Dwellfort Style -->
                <div class="gas-gallery"></div>
                
                <!-- Lightbox for gallery -->
                <div class="gas-lightbox">
                    <button class="gas-lightbox-close">&times;</button>
                    <button class="gas-lightbox-nav gas-lightbox-prev">&#8249;</button>
                    <div class="gas-lightbox-content">
                        <img src="" alt="Gallery image">
                    </div>
                    <button class="gas-lightbox-nav gas-lightbox-next">&#8250;</button>
                    <div class="gas-lightbox-counter"></div>
                </div>
                
                <div class="gas-room-layout">
                    <!-- Left Column: Details with Tabs -->
                    <div class="gas-room-main">
                        <!-- Room Header with Icons -->
                        <div class="gas-room-header">
                            <h1 class="gas-room-title"></h1>
                            <p class="gas-room-location"></p>
                            <div class="gas-room-meta"></div>
                        </div>
                        
                        <!-- Tabs Navigation -->
                        <div class="gas-tabs">
                            <div class="gas-tabs-nav">
                                <button class="gas-tab-btn active" data-tab="description">Description</button>
                                <button class="gas-tab-btn" data-tab="availability">Availability</button>
                                <button class="gas-tab-btn" data-tab="features">Features</button>
                                <button class="gas-tab-btn" data-tab="terms">Terms</button>
                            </div>
                            
                            <!-- Description Tab -->
                            <div class="gas-tab-content active" data-tab="description">
                                <div class="gas-description">
                                    <div class="gas-description-short"></div>
                                    <button type="button" class="gas-more-info-toggle" style="display:none;">
                                        <span>More Information</span>
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                    </button>
                                    <div class="gas-description-full"></div>
                                </div>
                            </div>
                            
                            <!-- Availability Tab -->
                            <div class="gas-tab-content" data-tab="availability">
                                <div class="gas-calendar-container">
                                    <!-- Month 1 -->
                                    <div class="gas-calendar" data-month="current">
                                        <div class="gas-calendar-header">
                                            <div class="gas-calendar-title"></div>
                                            <div class="gas-calendar-nav">
                                                <button class="gas-cal-prev">&#8249;</button>
                                            </div>
                                        </div>
                                        <div class="gas-calendar-grid"></div>
                                    </div>
                                    <!-- Month 2 -->
                                    <div class="gas-calendar" data-month="next">
                                        <div class="gas-calendar-header">
                                            <div class="gas-calendar-title"></div>
                                            <div class="gas-calendar-nav">
                                                <button class="gas-cal-next">&#8250;</button>
                                            </div>
                                        </div>
                                        <div class="gas-calendar-grid"></div>
                                    </div>
                                    <!-- Legend -->
                                    <div class="gas-calendar-legend">
                                        <div class="gas-legend-item">
                                            <div class="gas-legend-dot available"></div>
                                            <span>Available</span>
                                        </div>
                                        <div class="gas-legend-item">
                                            <div class="gas-legend-dot unavailable"></div>
                                            <span>Unavailable</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Features Tab -->
                            <div class="gas-tab-content" data-tab="features">
                                <div class="gas-amenities-container"></div>
                            </div>
                            
                            <!-- Terms Tab -->
                            <div class="gas-tab-content" data-tab="terms">
                                <div class="gas-accordion">
                                    <div class="gas-accordion-item" data-accordion="general">
                                        <button class="gas-accordion-header">
                                            <span>General Terms</span>
                                            <span class="gas-accordion-icon">+</span>
                                        </button>
                                        <div class="gas-accordion-content gas-general-terms">
                                            <p>No general terms provided.</p>
                                        </div>
                                    </div>
                                    <div class="gas-accordion-item" data-accordion="rules">
                                        <button class="gas-accordion-header">
                                            <span>House Rules</span>
                                            <span class="gas-accordion-icon">+</span>
                                        </button>
                                        <div class="gas-accordion-content gas-house-rules">
                                            <p>No house rules provided.</p>
                                        </div>
                                    </div>
                                    <div class="gas-accordion-item" data-accordion="cancellation">
                                        <button class="gas-accordion-header">
                                            <span>Cancellation Policy</span>
                                            <span class="gas-accordion-icon">+</span>
                                        </button>
                                        <div class="gas-accordion-content gas-cancellation-policy">
                                            <p>No cancellation policy provided.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Map Section (optional) -->
                        <div class="gas-map-container" style="display:none;">
                            <h3 class="gas-map-title">Location</h3>
                            <div class="gas-map"></div>
                        </div>
                    </div>
                    
                    <!-- Right Column: Booking Card -->
                    <div class="gas-room-sidebar">
                        <!-- Offers Banner (generic teaser) -->
                        <div class="gas-offers-banner" style="display: none;">
                            <div class="gas-offer-badge">🎉 Special Offer</div>
                            <div class="gas-offer-teaser">We have special rates available for your dates!</div>
                            <div class="gas-offer-hint">See rate options below ↓</div>
                        </div>
                        
                        <div class="gas-booking-card">
                            <div class="gas-booking-card-header">
                                <div class="gas-price-display">
                                    <span class="gas-price-amount"></span>
                                    <span class="gas-price-period">/ night</span>
                                </div>
                            </div>
                            
                            <div class="gas-booking-card-body">
                                <div class="gas-date-inputs">
                                    <div class="gas-date-field">
                                        <label>CHECK-IN</label>
                                        <input type="date" class="gas-checkin" value="<?php echo esc_attr($checkin); ?>" min="<?php echo date('Y-m-d'); ?>" />
                                    </div>
                                    <div class="gas-date-field">
                                        <label>CHECK-OUT</label>
                                        <input type="date" class="gas-checkout" value="<?php echo esc_attr($checkout); ?>" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" />
                                    </div>
                                </div>
                                
                                <div class="gas-guest-field">
                                    <label>GUESTS</label>
                                    <select class="gas-guests"></select>
                                </div>
                                
                                <div class="gas-price-breakdown" style="display: none;">
                                    <div class="gas-price-row">
                                        <span class="gas-nights-text"></span>
                                        <span class="gas-nights-price"></span>
                                    </div>
                                    <div class="gas-price-row gas-upsells-row" style="display: none;">
                                        <span>Extras</span>
                                        <span class="gas-upsells-total"></span>
                                    </div>
                                    <div class="gas-price-row gas-offer-row" style="display: none;">
                                        <span class="gas-offer-label">Offer discount</span>
                                        <span class="gas-offer-amount"></span>
                                    </div>
                                    <div class="gas-price-row gas-total-row">
                                        <span>Total</span>
                                        <span class="gas-total-price"></span>
                                    </div>
                                </div>
                                
                                <button type="button" class="gas-book-btn" disabled>
                                    Select dates to check availability
                                </button>
                            </div>
                            
                            <!-- Booking Form -->
                            <div class="gas-booking-form-section" style="display: none;">
                                <h3 class="gas-form-title">Complete your booking</h3>
                                <form class="gas-booking-form">
                                    <div class="gas-form-grid">
                                        <div class="gas-form-field">
                                            <label>First Name *</label>
                                            <input type="text" name="first_name" required />
                                        </div>
                                        <div class="gas-form-field">
                                            <label>Last Name *</label>
                                            <input type="text" name="last_name" required />
                                        </div>
                                        <div class="gas-form-field">
                                            <label>Email *</label>
                                            <input type="email" name="email" required />
                                        </div>
                                        <div class="gas-form-field">
                                            <label>Phone</label>
                                            <input type="tel" name="phone" />
                                        </div>
                                        <div class="gas-form-field full-width">
                                            <label>Special Requests</label>
                                            <textarea name="notes" rows="3"></textarea>
                                        </div>
                                    </div>
                                    <button type="submit" class="gas-submit-btn">
                                        Confirm Booking
                                    </button>
                                </form>
                            </div>
                            
                            <!-- Confirmation -->
                            <div class="gas-booking-confirmation" style="display: none;">
                                <div class="gas-confirmation-icon">✓</div>
                                <h3 class="gas-confirmation-title">Booking Confirmed!</h3>
                                <p class="gas-confirmation-text"></p>
                                <div class="gas-booking-id"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Compact Booking Widget
     */
    public function booking_shortcode($atts) {
        return $this->room_shortcode($atts);
    }
    
    /**
     * Checkout Page Shortcode
     * Usage: [gas_checkout]
     * Displays full checkout form with booking summary, upsells, guest details
     */
    public function checkout_shortcode($atts) {
        $atts = shortcode_atts(array(), $atts);
        
        $api_url = get_option('gas_api_url', 'https://gas-booking-production.up.railway.app');
        $client_id = get_option('gas_client_id', '');
        $currency = get_option('gas_currency_symbol', '£');
        $button_color = get_option('gas_button_color', '#667eea');
        
        // Get booking details from URL params
        $unit_id = isset($_GET['room']) ? intval($_GET['room']) : 0;
        $checkin = isset($_GET['checkin']) ? sanitize_text_field($_GET['checkin']) : '';
        $checkout = isset($_GET['checkout']) ? sanitize_text_field($_GET['checkout']) : '';
        $guests = isset($_GET['guests']) ? intval($_GET['guests']) : 1;
        $rate_type = isset($_GET['rate']) ? sanitize_text_field($_GET['rate']) : 'standard';
        
        if (!$unit_id || !$checkin || !$checkout) {
            return '<div class="gas-checkout-error">
                <h2>Missing Booking Details</h2>
                <p>Please select a room and dates first.</p>
                <a href="' . esc_url(get_option('gas_search_results_url', '/book-now/')) . '" class="gas-btn-back">Browse Rooms</a>
            </div>';
        }
        
        ob_start();
        ?>
        <div class="gas-checkout-page" 
             data-unit-id="<?php echo esc_attr($unit_id); ?>"
             data-checkin="<?php echo esc_attr($checkin); ?>"
             data-checkout="<?php echo esc_attr($checkout); ?>"
             data-guests="<?php echo esc_attr($guests); ?>"
             data-rate-type="<?php echo esc_attr($rate_type); ?>"
             data-api-url="<?php echo esc_attr($api_url); ?>"
             data-client-id="<?php echo esc_attr($client_id); ?>">
            
            <h1 class="gas-checkout-title">Complete Your Booking</h1>
            
            <div class="gas-checkout-container">
                <!-- LEFT COLUMN: Booking Summary (50%) -->
                <div class="gas-checkout-summary-col">
                    <div class="gas-booking-summary">
                        <h2 class="gas-summary-title">Your Booking</h2>
                        
                        <!-- Room Info -->
                        <div class="gas-summary-room">
                            <div class="gas-summary-image">
                                <img src="" alt="Room" class="gas-room-thumb" />
                            </div>
                            <div class="gas-summary-room-info">
                                <h3 class="gas-summary-room-name">Loading...</h3>
                                <p class="gas-summary-property"></p>
                            </div>
                        </div>
                        
                        <!-- Dates & Guests -->
                        <div class="gas-summary-details">
                            <div class="gas-summary-row">
                                <div class="gas-summary-date-block">
                                    <span class="gas-date-label">CHECK-IN</span>
                                    <span class="gas-date-value"><?php echo esc_html(date('D, M j, Y', strtotime($checkin))); ?></span>
                                    <span class="gas-date-time">From 3:00 PM</span>
                                </div>
                                <div class="gas-summary-date-block">
                                    <span class="gas-date-label">CHECK-OUT</span>
                                    <span class="gas-date-value"><?php echo esc_html(date('D, M j, Y', strtotime($checkout))); ?></span>
                                    <span class="gas-date-time">By 11:00 AM</span>
                                </div>
                            </div>
                            
                            <div class="gas-summary-info-row">
                                <span>👤 <?php echo esc_html($guests); ?> Guest<?php echo $guests > 1 ? 's' : ''; ?></span>
                                <span class="gas-rate-badge <?php echo $rate_type === 'offer' ? 'offer' : ''; ?>">
                                    <?php echo $rate_type === 'offer' ? '🎉 Special Offer' : 'Standard Rate'; ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="gas-summary-divider"></div>
                        
                        <!-- Price Breakdown -->
                        <div class="gas-price-breakdown">
                            <h4>Price Details</h4>
                            
                            <div class="gas-price-line">
                                <span class="gas-nights-label">Loading...</span>
                                <span class="gas-nights-total"></span>
                            </div>
                            
                            <div class="gas-price-line gas-discount-line" style="display:none;">
                                <span>Offer Discount</span>
                                <span class="gas-discount-amount"></span>
                            </div>
                            
                            <!-- Selected Extras -->
                            <div class="gas-selected-extras" style="display:none;">
                                <div class="gas-extras-header">Your Extras</div>
                                <div class="gas-extras-list"></div>
                            </div>
                            
                            <div class="gas-price-line gas-voucher-line" style="display:none;">
                                <span class="gas-voucher-label">Promo Code</span>
                                <span class="gas-voucher-discount"></span>
                            </div>
                            
                            <!-- Taxes -->
                            <div class="gas-taxes-section" style="display:none;">
                                <div class="gas-taxes-header">Taxes & Fees</div>
                                <div class="gas-taxes-list"></div>
                            </div>
                        </div>
                        
                        <div class="gas-summary-divider"></div>
                        
                        <!-- Total -->
                        <div class="gas-summary-total">
                            <span>Total</span>
                            <span class="gas-grand-total">--</span>
                        </div>
                        <p class="gas-tax-note">Includes all taxes and fees</p>
                        
                        <!-- Cancellation Policy -->
                        <div class="gas-cancellation-box">
                            <div class="gas-policy-header">📋 Cancellation Policy</div>
                            <p class="gas-policy-standard" style="display:none;">
                                <strong>Free cancellation</strong> until 48 hours before check-in.
                            </p>
                            <p class="gas-policy-nonrefund" style="display:none;">
                                <strong>Non-refundable.</strong> This rate cannot be cancelled or modified.
                            </p>
                        </div>
                        
                        <!-- Trust Badges -->
                        <div class="gas-trust-badges">
                            <div class="gas-trust-badge">🔒 Secure Booking</div>
                            <div class="gas-trust-badge">✓ Instant Confirmation</div>
                            <div class="gas-trust-badge">💬 24/7 Support</div>
                        </div>
                    </div>
                </div>
                
                <!-- RIGHT COLUMN: Booking Steps (50%) -->
                <div class="gas-checkout-steps-col">
                    <!-- Progress Indicator -->
                    <div class="gas-checkout-steps">
                        <div class="gas-step active" data-step="1">
                            <span class="gas-step-number">1</span>
                            <span class="gas-step-label">Your Details</span>
                        </div>
                        <div class="gas-step" data-step="2">
                            <span class="gas-step-number">2</span>
                            <span class="gas-step-label">Extras</span>
                        </div>
                        <div class="gas-step" data-step="3">
                            <span class="gas-step-number">3</span>
                            <span class="gas-step-label">Payment</span>
                        </div>
                    </div>
                    
                    <!-- Step 1: Guest Details -->
                    <div class="gas-checkout-step-content" data-step="1">
                        <div class="gas-checkout-section">
                            <h2 class="gas-section-title">Guest Details</h2>
                            <p class="gas-section-subtitle">Please enter your details. We'll send the booking confirmation to your email.</p>
                            
                            <form class="gas-checkout-form" id="gas-guest-form">
                                <div class="gas-form-row">
                                    <div class="gas-form-field">
                                        <label>First Name <span class="required">*</span></label>
                                        <input type="text" name="first_name" required placeholder="John" />
                                    </div>
                                    <div class="gas-form-field">
                                        <label>Last Name <span class="required">*</span></label>
                                        <input type="text" name="last_name" required placeholder="Smith" />
                                    </div>
                                </div>
                                
                                <div class="gas-form-row">
                                    <div class="gas-form-field">
                                        <label>Email Address <span class="required">*</span></label>
                                        <input type="email" name="email" id="gas-email" required placeholder="john@example.com" />
                                    </div>
                                    <div class="gas-form-field">
                                        <label>Confirm Email <span class="required">*</span></label>
                                        <input type="email" name="email_confirm" id="gas-email-confirm" required placeholder="john@example.com" />
                                        <span class="gas-email-match" style="display:none;">✓ Emails match</span>
                                        <span class="gas-email-mismatch" style="display:none;">✗ Emails don't match</span>
                                    </div>
                                </div>
                                
                                <div class="gas-form-row">
                                    <div class="gas-form-field">
                                        <label>Phone Number <span class="required">*</span></label>
                                        <input type="tel" name="phone" required placeholder="+44 7700 900000" />
                                    </div>
                                    <div class="gas-form-field">
                                        <label>Country</label>
                                        <select name="country">
                                            <option value="GB">United Kingdom</option>
                                            <option value="US">United States</option>
                                            <option value="CA">Canada</option>
                                            <option value="AU">Australia</option>
                                            <option value="DE">Germany</option>
                                            <option value="FR">France</option>
                                            <option value="ES">Spain</option>
                                            <option value="IT">Italy</option>
                                            <option value="NL">Netherlands</option>
                                            <option value="OTHER">Other</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="gas-form-row">
                                    <div class="gas-form-field full-width">
                                        <label>Special Requests <span class="optional">(optional)</span></label>
                                        <textarea name="notes" rows="3" placeholder="E.g., late check-in, dietary requirements, special occasion..."></textarea>
                                        <p class="gas-field-hint">Special requests are subject to availability and cannot be guaranteed.</p>
                                    </div>
                                </div>
                                
                                <div class="gas-form-row">
                                    <div class="gas-form-field full-width">
                                        <label class="gas-checkbox-label">
                                            <input type="checkbox" name="marketing" value="1" />
                                            <span>Send me special offers and updates (you can unsubscribe anytime)</span>
                                        </label>
                                    </div>
                                </div>
                            </form>
                        </div>
                        
                        <div class="gas-checkout-nav">
                            <a href="javascript:history.back()" class="gas-btn-secondary">← Back to Room</a>
                            <button type="button" class="gas-btn-primary gas-next-step" data-next="2" style="background:<?php echo esc_attr($button_color); ?>">
                                Continue to Extras →
                            </button>
                        </div>
                    </div>
                    
                    <!-- Step 2: Upsells -->
                    <div class="gas-checkout-step-content" data-step="2" style="display:none;">
                        <div class="gas-checkout-section">
                            <h2 class="gas-section-title">✨ Enhance Your Stay</h2>
                            <p class="gas-section-subtitle">Add extras to make your stay even more special.</p>
                            
                            <div class="gas-upsells-loading">Loading available extras...</div>
                            <div class="gas-checkout-upsells"></div>
                            <div class="gas-no-upsells" style="display:none;">
                                <p>No extras available for this booking.</p>
                            </div>
                        </div>
                        
                        <!-- Voucher Code -->
                        <div class="gas-checkout-section">
                            <h2 class="gas-section-title">🎟️ Promo Code</h2>
                            <div class="gas-voucher-row">
                                <input type="text" name="voucher_code" class="gas-voucher-input" placeholder="Enter promo code" />
                                <button type="button" class="gas-btn-apply">Apply</button>
                            </div>
                            <div class="gas-voucher-result"></div>
                        </div>
                        
                        <div class="gas-checkout-nav">
                            <button type="button" class="gas-btn-secondary gas-prev-step" data-prev="1">← Back</button>
                            <button type="button" class="gas-btn-primary gas-next-step" data-next="3" style="background:<?php echo esc_attr($button_color); ?>">
                                Continue to Payment →
                            </button>
                        </div>
                    </div>
                    
                    <!-- Step 3: Payment -->
                    <div class="gas-checkout-step-content" data-step="3" style="display:none;">
                        <div class="gas-checkout-section">
                            <h2 class="gas-section-title">💳 Payment</h2>
                            
                            <div class="gas-payment-options">
                                <label class="gas-payment-option selected">
                                    <input type="radio" name="payment_method" value="pay_at_property" checked />
                                    <div class="gas-payment-option-content">
                                        <div class="gas-payment-icon">🏠</div>
                                        <div class="gas-payment-details">
                                            <strong>Pay at Property</strong>
                                            <span>Pay when you arrive - no payment needed now</span>
                                        </div>
                                    </div>
                                </label>
                                
                                <label class="gas-payment-option disabled">
                                    <input type="radio" name="payment_method" value="card" disabled />
                                    <div class="gas-payment-option-content">
                                        <div class="gas-payment-icon">💳</div>
                                        <div class="gas-payment-details">
                                            <strong>Pay by Card</strong>
                                            <span>Coming soon - Secure payment via Stripe</span>
                                        </div>
                                    </div>
                                </label>
                                
                                <label class="gas-payment-option disabled">
                                    <input type="radio" name="payment_method" value="paypal" disabled />
                                    <div class="gas-payment-option-content">
                                        <div class="gas-payment-icon">🅿️</div>
                                        <div class="gas-payment-details">
                                            <strong>PayPal</strong>
                                            <span>Coming soon</span>
                                        </div>
                                    </div>
                                </label>
                            </div>
                            
                            <!-- Deposit Option (future) -->
                            <div class="gas-deposit-info" style="display:none;">
                                <p>A deposit of <strong class="gas-deposit-amount"></strong> will be charged now. The remaining balance is due at check-in.</p>
                            </div>
                        </div>
                        
                        <!-- Terms & Conditions -->
                        <div class="gas-checkout-section">
                            <div class="gas-terms-box">
                                <label class="gas-checkbox-label">
                                    <input type="checkbox" name="terms" id="gas-terms" required />
                                    <span>I agree to the <a href="#" class="gas-terms-link">Terms & Conditions</a> and <a href="#" class="gas-privacy-link">Privacy Policy</a>. I understand that my booking is subject to the property's cancellation policy.</span>
                                </label>
                            </div>
                        </div>
                        
                        <div class="gas-checkout-nav">
                            <button type="button" class="gas-btn-secondary gas-prev-step" data-prev="2">← Back</button>
                            <button type="button" class="gas-btn-confirm" id="gas-confirm-booking" style="background:<?php echo esc_attr($button_color); ?>">
                                <span class="gas-btn-text">Confirm Booking</span>
                                <span class="gas-btn-loading" style="display:none;">Processing...</span>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Confirmation (shown after booking) -->
                    <div class="gas-checkout-confirmation" style="display:none;">
                        <div class="gas-confirmation-icon">✓</div>
                        <h2 class="gas-confirmation-title">Booking Confirmed!</h2>
                        <p class="gas-confirmation-ref">Your booking reference: <strong class="gas-booking-ref"></strong></p>
                        <p class="gas-confirmation-email">A confirmation email has been sent to <strong class="gas-guest-email"></strong></p>
                        
                        <div class="gas-confirmation-summary">
                            <h3>Booking Details</h3>
                            <div class="gas-confirmation-details"></div>
                        </div>
                        
                        <div class="gas-confirmation-actions">
                            <a href="/" class="gas-btn-secondary">Return Home</a>
                            <button type="button" class="gas-btn-primary" onclick="window.print()" style="background:<?php echo esc_attr($button_color); ?>">Print Confirmation</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        /* Hide page hero/title when checkout is displayed */
        .gas-checkout-page ~ .page-hero,
        .gas-checkout-page ~ .entry-header,
        body:has(.gas-checkout-page) .page-hero,
        body:has(.gas-checkout-page) .entry-header,
        body:has(.gas-checkout-page) .page-title-section,
        body:has(.gas-checkout-page) .hero-section,
        body:has(.gas-checkout-page) article > header,
        body:has(.gas-checkout-page) .wp-block-post-title { display: none !important; }
        
        /* Checkout page - 50/50 split layout */
        .gas-checkout-page { width: 100%; max-width: 1600px; margin: 0 auto; padding: 30px 40px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; box-sizing: border-box; }
        .gas-checkout-title { font-size: 32px; font-weight: 700; margin-bottom: 32px; color: #1e293b; text-align: center; }
        .gas-checkout-container { display: flex; gap: 40px; justify-content: center; }
        
        /* Left Column: Summary */
        .gas-checkout-summary-col { flex: 0 0 480px; position: sticky; top: 20px; height: fit-content; }
        .gas-booking-summary { background: white; border: 1px solid #e2e8f0; border-radius: 16px; padding: 32px; box-shadow: 0 4px 20px rgba(0,0,0,0.06); }
        
        /* Right Column: Steps */
        .gas-checkout-steps-col { flex: 0 0 580px; }
        .gas-summary-title { font-size: 22px; font-weight: 700; margin-bottom: 24px; color: #1e293b; }
        
        .gas-summary-room { display: flex; gap: 20px; margin-bottom: 24px; padding-bottom: 24px; border-bottom: 1px solid #e2e8f0; }
        .gas-summary-image { width: 140px; height: 100px; border-radius: 12px; overflow: hidden; background: #f1f5f9; flex-shrink: 0; }
        .gas-summary-image img { width: 100%; height: 100%; object-fit: cover; }
        .gas-summary-room-name { font-size: 18px; font-weight: 600; color: #1e293b; margin: 0 0 8px 0; }
        .gas-summary-property { font-size: 14px; color: #64748b; margin: 0; }
        
        .gas-summary-details { margin-bottom: 20px; }
        .gas-summary-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .gas-summary-date-block { background: #f8fafc; padding: 16px; border-radius: 12px; }
        .gas-date-label { display: block; font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: 600; margin-bottom: 6px; letter-spacing: 0.5px; }
        .gas-date-value { display: block; font-weight: 600; color: #1e293b; font-size: 16px; }
        .gas-date-time { font-size: 13px; color: #94a3b8; margin-top: 4px; }
        
        .gas-summary-info-row { display: flex; justify-content: space-between; align-items: center; }
        .gas-summary-info-row > span { font-size: 15px; color: #475569; }
        .gas-rate-badge { font-size: 13px; padding: 6px 12px; border-radius: 20px; background: #f1f5f9; color: #475569; }
        .gas-rate-badge.offer { background: #fef3c7; color: #92400e; }
        
        .gas-summary-divider { height: 1px; background: #e2e8f0; margin: 24px 0; }
        
        .gas-price-breakdown h4 { font-size: 14px; font-weight: 600; color: #64748b; margin: 0 0 16px 0; text-transform: uppercase; letter-spacing: 0.5px; }
        .gas-price-line { display: flex; justify-content: space-between; font-size: 16px; color: #475569; margin-bottom: 12px; }
        .gas-discount-line span { color: #10b981; }
        .gas-voucher-line span { color: #10b981; }
        
        .gas-selected-extras { margin: 20px 0; padding: 16px; background: #f8fafc; border-radius: 10px; }
        .gas-extras-header, .gas-taxes-header { font-size: 12px; font-weight: 600; color: #64748b; text-transform: uppercase; margin-bottom: 10px; }
        .gas-extras-list .gas-extra-item, .gas-taxes-list .gas-tax-item { display: flex; justify-content: space-between; font-size: 15px; color: #475569; margin-bottom: 8px; }
        
        .gas-taxes-section { margin: 20px 0; padding: 16px; background: #f8fafc; border-radius: 10px; }
        
        .gas-summary-total { display: flex; justify-content: space-between; align-items: center; }
        .gas-summary-total span:first-child { font-size: 18px; font-weight: 600; color: #1e293b; }
        .gas-grand-total { font-size: 28px; font-weight: 700; color: <?php echo esc_attr($button_color); ?>; }
        .gas-tax-note { font-size: 12px; color: #94a3b8; margin: 8px 0 0 0; text-align: right; }
        
        .gas-cancellation-box { margin-top: 20px; padding: 16px; background: #fefce8; border-radius: 10px; border: 1px solid #fef08a; }
        .gas-policy-header { font-size: 14px; font-weight: 600; color: #854d0e; margin-bottom: 8px; }
        .gas-cancellation-box p { font-size: 13px; color: #713f12; margin: 0; line-height: 1.5; }
        
        .gas-trust-badges { display: flex; gap: 8px; margin-top: 20px; flex-wrap: wrap; }
        .gas-trust-badge { font-size: 12px; padding: 6px 12px; background: #f1f5f9; border-radius: 20px; color: #475569; }
        
        /* Right Column: Steps */
        .gas-checkout-steps-col { }
        .gas-checkout-steps { display: flex; gap: 12px; margin-bottom: 32px; }
        .gas-step { display: flex; align-items: center; gap: 10px; padding: 14px 20px; background: #f1f5f9; border-radius: 10px; flex: 1; }
        .gas-step.active { background: <?php echo esc_attr($button_color); ?>; color: white; }
        .gas-step.completed { background: #10b981; color: white; }
        .gas-step-number { width: 28px; height: 28px; border-radius: 50%; background: rgba(0,0,0,0.1); display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 13px; }
        .gas-step.active .gas-step-number, .gas-step.completed .gas-step-number { background: rgba(255,255,255,0.3); }
        .gas-step-label { font-size: 14px; font-weight: 500; }
        
        /* Form styles */
        .gas-checkout-section { background: white; border: 1px solid #e2e8f0; border-radius: 14px; padding: 28px; margin-bottom: 24px; }
        .gas-section-title { font-size: 20px; font-weight: 600; margin-bottom: 10px; color: #1e293b; }
        .gas-section-subtitle { color: #64748b; font-size: 15px; margin-bottom: 24px; }
        .gas-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .gas-form-field { display: flex; flex-direction: column; gap: 8px; }
        .gas-form-field.full-width { grid-column: 1 / -1; }
        .gas-form-field label { font-weight: 500; font-size: 15px; color: #374151; }
        .gas-form-field label .required { color: #ef4444; }
        .gas-form-field label .optional { color: #9ca3af; font-weight: 400; }
        .gas-form-field input, .gas-form-field select, .gas-form-field textarea { padding: 14px 16px; border: 1px solid #d1d5db; border-radius: 10px; font-size: 16px; transition: border-color 0.2s, box-shadow 0.2s; }
        .gas-form-field input:focus, .gas-form-field select:focus, .gas-form-field textarea:focus { outline: none; border-color: <?php echo esc_attr($button_color); ?>; box-shadow: 0 0 0 3px <?php echo esc_attr($button_color); ?>20; }
        .gas-field-hint { font-size: 13px; color: #9ca3af; margin-top: 4px; }
        .gas-email-match { color: #10b981; font-size: 13px; }
        .gas-email-mismatch { color: #ef4444; font-size: 13px; }
        
        /* Checkbox */
        .gas-checkbox-label { display: flex; align-items: flex-start; gap: 12px; cursor: pointer; font-size: 15px; color: #4b5563; }
        .gas-checkbox-label input { width: 20px; height: 20px; margin-top: 2px; }
        
        /* Navigation */
        .gas-checkout-nav { display: flex; justify-content: space-between; gap: 20px; margin-top: 28px; }
        .gas-btn-primary, .gas-btn-secondary, .gas-btn-confirm { padding: 16px 32px; border-radius: 10px; font-size: 16px; font-weight: 600; cursor: pointer; transition: all 0.2s; border: none; }
        .gas-btn-primary, .gas-btn-confirm { background: <?php echo esc_attr($button_color); ?>; color: white; }
        .gas-btn-primary:hover, .gas-btn-confirm:hover { filter: brightness(0.9); }
        .gas-btn-secondary { background: white; border: 1px solid #d1d5db; color: #374151; }
        .gas-btn-secondary:hover { background: #f9fafb; }
        .gas-btn-confirm { width: 100%; padding: 18px; font-size: 17px; }
        
        /* Payment Options */
        .gas-payment-options { display: flex; flex-direction: column; gap: 12px; }
        .gas-payment-option { display: block; cursor: pointer; }
        .gas-payment-option input { display: none; }
        .gas-payment-option-content { display: flex; align-items: center; gap: 16px; padding: 16px; border: 2px solid #e2e8f0; border-radius: 10px; transition: all 0.2s; }
        .gas-payment-option.selected .gas-payment-option-content { border-color: <?php echo esc_attr($button_color); ?>; background: <?php echo esc_attr($button_color); ?>08; }
        .gas-payment-option.disabled { opacity: 0.5; cursor: not-allowed; }
        .gas-payment-icon { font-size: 24px; }
        .gas-payment-details strong { display: block; font-size: 15px; color: #1e293b; }
        .gas-payment-details span { font-size: 13px; color: #64748b; }
        
        /* Upsells */
        .gas-checkout-upsells { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
        .gas-upsell-card { display: flex; flex-direction: column; padding: 20px; border: 2px solid #e2e8f0; border-radius: 12px; cursor: pointer; transition: all 0.2s; position: relative; text-align: center; }
        .gas-upsell-card:hover { border-color: #cbd5e1; background: #f8fafc; }
        .gas-upsell-card.selected { border-color: <?php echo esc_attr($button_color); ?>; background: <?php echo esc_attr($button_color); ?>08; }
        .gas-upsell-check { position: absolute; top: 10px; right: 10px; width: 24px; height: 24px; border: 2px solid #d1d5db; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.2s; font-size: 12px; color: transparent; }
        .gas-upsell-card.selected .gas-upsell-check { background: <?php echo esc_attr($button_color); ?>; border-color: <?php echo esc_attr($button_color); ?>; color: white; }
        .gas-upsell-image { width: 80px; height: 80px; margin: 0 auto 12px; border-radius: 8px; overflow: hidden; }
        .gas-upsell-image img { width: 100%; height: 100%; object-fit: cover; }
        .gas-upsell-icon { width: 60px; height: 60px; margin: 0 auto 12px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; }
        .gas-upsell-info { flex: 1; }
        .gas-upsell-name { font-weight: 600; font-size: 15px; color: #1e293b; margin-bottom: 4px; }
        .gas-upsell-desc { font-size: 12px; color: #64748b; margin-bottom: 8px; line-height: 1.4; }
        .gas-upsell-price { font-weight: 700; font-size: 16px; color: <?php echo esc_attr($button_color); ?>; }
        .gas-upsell-price small { font-weight: 400; font-size: 12px; color: #94a3b8; }
        
        /* Voucher */
        .gas-voucher-row { display: flex; gap: 8px; }
        .gas-voucher-input { flex: 1; padding: 12px 14px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; text-transform: uppercase; }
        .gas-btn-apply { padding: 12px 20px; background: #f1f5f9; border: 1px solid #d1d5db; border-radius: 8px; font-weight: 600; cursor: pointer; }
        .gas-voucher-result { margin-top: 8px; font-size: 14px; }
        .gas-voucher-success { color: #10b981; }
        .gas-voucher-error { color: #ef4444; }
        
        /* Confirmation */
        .gas-checkout-confirmation { text-align: center; padding: 60px 20px; }
        .gas-confirmation-icon { width: 80px; height: 80px; background: #10b981; color: white; font-size: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 24px; }
        .gas-confirmation-title { font-size: 28px; font-weight: 700; color: #1e293b; margin-bottom: 16px; }
        .gas-confirmation-ref { font-size: 16px; color: #475569; margin-bottom: 8px; }
        .gas-confirmation-ref strong { color: <?php echo esc_attr($button_color); ?>; font-size: 18px; }
        .gas-confirmation-email { font-size: 14px; color: #64748b; margin-bottom: 32px; }
        .gas-confirmation-summary { background: #f8fafc; border-radius: 12px; padding: 24px; text-align: left; margin-bottom: 32px; }
        .gas-confirmation-actions { display: flex; justify-content: center; gap: 16px; }
        
        /* Error */
        .gas-checkout-error { text-align: center; padding: 60px 20px; }
        .gas-checkout-error h2 { color: #ef4444; margin-bottom: 16px; }
        .gas-btn-back { display: inline-block; margin-top: 20px; padding: 12px 24px; background: <?php echo esc_attr($button_color); ?>; color: white; text-decoration: none; border-radius: 8px; }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .gas-checkout-page { padding: 20px 30px; }
            .gas-checkout-summary-col { flex: 0 0 420px; }
            .gas-checkout-steps-col { flex: 0 0 500px; }
        }
        @media (max-width: 1000px) {
            .gas-checkout-container { flex-direction: column; align-items: center; }
            .gas-checkout-summary-col { flex: none; width: 100%; max-width: 600px; position: static; }
            .gas-checkout-steps-col { flex: none; width: 100%; max-width: 600px; }
            .gas-checkout-upsells { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 600px) {
            .gas-checkout-page { padding: 15px; }
            .gas-form-row { grid-template-columns: 1fr; }
            .gas-checkout-steps { flex-direction: column; }
            .gas-checkout-upsells { grid-template-columns: 1fr; }
            .gas-summary-row { grid-template-columns: 1fr; }
        }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Offers Showcase Page Shortcode
     * Usage: [gas_offers]
     * Displays all active offers and public voucher codes
     */
    public function offers_shortcode($atts) {
        $atts = shortcode_atts(array(
            'show_vouchers' => 'yes',
        ), $atts);
        
        $api_url = get_option('gas_api_url', 'https://gas-booking-production.up.railway.app');
        $client_id = get_option('gas_client_id', '');
        $currency = get_option('gas_currency_symbol', '£');
        $button_color = get_option('gas_button_color', '#667eea');
        $book_now_url = get_option('gas_search_results_url', '/book-now/');
        
        if (empty($client_id)) {
            return '<p>Please configure your GAS Client ID in Settings.</p>';
        }
        
        ob_start();
        ?>
        <div class="gas-offers-page" data-api-url="<?php echo esc_attr($api_url); ?>" data-client-id="<?php echo esc_attr($client_id); ?>">
            
            <!-- Hero Section -->
            <div class="gas-offers-hero">
                <h1 class="gas-offers-title">🎉 Special Offers & Deals</h1>
                <p class="gas-offers-subtitle">Take advantage of our exclusive rates and promotions for your perfect stay.</p>
            </div>
            
            <!-- Offers Section -->
            <div class="gas-offers-section">
                <h2 class="gas-section-heading">Current Offers</h2>
                <div class="gas-offers-loading">Loading offers...</div>
                <div class="gas-offers-grid"></div>
                <div class="gas-no-offers" style="display:none;">
                    <p>No special offers available at the moment. Check back soon!</p>
                </div>
            </div>
            
            <?php if ($atts['show_vouchers'] === 'yes') : ?>
            <!-- Vouchers Section -->
            <div class="gas-vouchers-section">
                <h2 class="gas-section-heading">🎟️ Promo Codes</h2>
                <p class="gas-vouchers-intro">Use these codes at checkout to save on your booking!</p>
                <div class="gas-vouchers-loading">Loading promo codes...</div>
                <div class="gas-vouchers-grid"></div>
                <div class="gas-no-vouchers" style="display:none;">
                    <p>No promo codes available at the moment.</p>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- CTA Section -->
            <div class="gas-offers-cta">
                <h3>Ready to Book?</h3>
                <p>Browse our rooms and apply these offers at checkout.</p>
                <a href="<?php echo esc_url($book_now_url); ?>" class="gas-offers-cta-btn" style="background:<?php echo esc_attr($button_color); ?>">
                    View Available Rooms →
                </a>
            </div>
        </div>
        
        <style>
        .gas-offers-page { max-width: 1000px; margin: 0 auto; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        
        /* Hero */
        .gas-offers-hero { text-align: center; padding: 40px 20px; margin-bottom: 40px; background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-radius: 16px; }
        .gas-offers-title { font-size: 32px; font-weight: 700; color: #92400e; margin: 0 0 12px 0; }
        .gas-offers-subtitle { font-size: 16px; color: #a16207; margin: 0; }
        
        /* Sections */
        .gas-offers-section, .gas-vouchers-section { margin-bottom: 48px; }
        .gas-section-heading { font-size: 24px; font-weight: 700; color: #1e293b; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 2px solid #e2e8f0; }
        .gas-vouchers-intro { color: #64748b; margin-bottom: 20px; }
        
        /* Offers Grid */
        .gas-offers-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
        .gas-offer-card { background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 24px; transition: all 0.2s; position: relative; overflow: hidden; }
        .gas-offer-card:hover { box-shadow: 0 10px 40px rgba(0,0,0,0.1); transform: translateY(-2px); }
        .gas-offer-card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: <?php echo esc_attr($button_color); ?>; }
        .gas-offer-card-badge { display: inline-block; background: #f59e0b; color: white; font-size: 11px; font-weight: 700; text-transform: uppercase; padding: 4px 10px; border-radius: 20px; margin-bottom: 12px; }
        .gas-offer-card-name { font-size: 20px; font-weight: 700; color: #1e293b; margin-bottom: 8px; }
        .gas-offer-card-description { font-size: 14px; color: #64748b; margin-bottom: 16px; line-height: 1.5; }
        .gas-offer-card-discount { font-size: 28px; font-weight: 700; color: <?php echo esc_attr($button_color); ?>; margin-bottom: 16px; }
        .gas-offer-card-conditions { font-size: 12px; color: #94a3b8; }
        .gas-offer-card-conditions ul { margin: 8px 0 0 0; padding-left: 18px; }
        .gas-offer-card-conditions li { margin-bottom: 4px; }
        
        /* Vouchers Grid */
        .gas-vouchers-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }
        .gas-voucher-card { background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border: 2px dashed #22c55e; border-radius: 12px; padding: 20px; text-align: center; position: relative; }
        .gas-voucher-code-label { font-size: 12px; color: #166534; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; }
        .gas-voucher-code { font-size: 24px; font-weight: 700; color: #166534; font-family: monospace; background: white; padding: 10px 20px; border-radius: 8px; display: inline-block; margin-bottom: 12px; cursor: pointer; transition: all 0.2s; }
        .gas-voucher-code:hover { background: #f0fdf4; }
        .gas-voucher-code.copied { background: #166534; color: white; }
        .gas-voucher-name { font-size: 16px; font-weight: 600; color: #1e293b; margin-bottom: 4px; }
        .gas-voucher-discount { font-size: 14px; color: #16a34a; font-weight: 600; margin-bottom: 8px; }
        .gas-voucher-conditions { font-size: 12px; color: #64748b; }
        .gas-voucher-validity { font-size: 11px; color: #94a3b8; margin-top: 12px; }
        .gas-click-to-copy { font-size: 11px; color: #94a3b8; margin-top: 4px; }
        
        /* CTA */
        .gas-offers-cta { text-align: center; padding: 48px 24px; background: #f8fafc; border-radius: 16px; margin-top: 48px; }
        .gas-offers-cta h3 { font-size: 24px; font-weight: 700; color: #1e293b; margin: 0 0 8px 0; }
        .gas-offers-cta p { color: #64748b; margin: 0 0 24px 0; }
        .gas-offers-cta-btn { display: inline-block; padding: 14px 32px; color: white; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px; transition: all 0.2s; }
        .gas-offers-cta-btn:hover { filter: brightness(0.9); color: white; }
        
        /* Loading */
        .gas-offers-loading, .gas-vouchers-loading { text-align: center; padding: 40px; color: #64748b; }
        .gas-no-offers, .gas-no-vouchers { text-align: center; padding: 40px; color: #94a3b8; background: #f8fafc; border-radius: 12px; }
        
        /* Mobile */
        @media (max-width: 640px) {
            .gas-offers-title { font-size: 24px; }
            .gas-offers-grid, .gas-vouchers-grid { grid-template-columns: 1fr; }
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            var apiUrl = $('.gas-offers-page').data('api-url');
            var clientId = $('.gas-offers-page').data('client-id');
            var currency = '<?php echo esc_js($currency); ?>';
            
            // Load offers
            $.ajax({
                url: apiUrl + '/api/public/client/' + clientId + '/offers',
                method: 'GET',
                success: function(response) {
                    $('.gas-offers-loading').hide();
                    if (response.success && response.offers && response.offers.length > 0) {
                        var html = '';
                        response.offers.forEach(function(offer) {
                            html += '<div class="gas-offer-card">';
                            html += '<span class="gas-offer-card-badge">Special Offer</span>';
                            html += '<div class="gas-offer-card-name">' + offer.name + '</div>';
                            if (offer.description) {
                                html += '<div class="gas-offer-card-description">' + offer.description + '</div>';
                            }
                            
                            // Discount display
                            if (offer.discount_type === 'percentage') {
                                html += '<div class="gas-offer-card-discount">Save ' + offer.discount_value + '%</div>';
                            } else {
                                html += '<div class="gas-offer-card-discount">Save ' + currency + offer.discount_value + '</div>';
                            }
                            
                            // Conditions
                            html += '<div class="gas-offer-card-conditions">';
                            html += '<strong>Conditions:</strong><ul>';
                            if (offer.min_nights) html += '<li>Minimum ' + offer.min_nights + ' nights</li>';
                            if (offer.max_nights) html += '<li>Maximum ' + offer.max_nights + ' nights</li>';
                            if (offer.min_guests) html += '<li>Minimum ' + offer.min_guests + ' guests</li>';
                            if (offer.valid_from) html += '<li>Valid from ' + offer.valid_from + '</li>';
                            if (offer.valid_until) html += '<li>Valid until ' + offer.valid_until + '</li>';
                            if (!offer.min_nights && !offer.max_nights && !offer.min_guests && !offer.valid_from && !offer.valid_until) {
                                html += '<li>Available for all bookings</li>';
                            }
                            html += '</ul></div>';
                            html += '</div>';
                        });
                        $('.gas-offers-grid').html(html);
                    } else {
                        $('.gas-no-offers').show();
                    }
                },
                error: function() {
                    $('.gas-offers-loading').hide();
                    $('.gas-no-offers').show();
                }
            });
            
            // Load vouchers (public ones)
            $.ajax({
                url: apiUrl + '/api/public/client/' + clientId + '/vouchers',
                method: 'GET',
                success: function(response) {
                    $('.gas-vouchers-loading').hide();
                    if (response.success && response.vouchers && response.vouchers.length > 0) {
                        var html = '';
                        response.vouchers.forEach(function(voucher) {
                            html += '<div class="gas-voucher-card">';
                            html += '<div class="gas-voucher-code-label">Promo Code</div>';
                            html += '<div class="gas-voucher-code" data-code="' + voucher.code + '">' + voucher.code + '</div>';
                            html += '<div class="gas-click-to-copy">Click to copy</div>';
                            html += '<div class="gas-voucher-name">' + voucher.name + '</div>';
                            
                            if (voucher.discount_type === 'percentage') {
                                html += '<div class="gas-voucher-discount">' + voucher.discount_value + '% off</div>';
                            } else {
                                html += '<div class="gas-voucher-discount">' + currency + voucher.discount_value + ' off</div>';
                            }
                            
                            var conditions = [];
                            if (voucher.min_nights) conditions.push('Min ' + voucher.min_nights + ' nights');
                            if (voucher.min_booking_value) conditions.push('Min spend ' + currency + voucher.min_booking_value);
                            if (conditions.length > 0) {
                                html += '<div class="gas-voucher-conditions">' + conditions.join(' • ') + '</div>';
                            }
                            
                            if (voucher.valid_until) {
                                html += '<div class="gas-voucher-validity">Expires: ' + voucher.valid_until + '</div>';
                            }
                            
                            html += '</div>';
                        });
                        $('.gas-vouchers-grid').html(html);
                    } else {
                        $('.gas-no-vouchers').show();
                    }
                },
                error: function() {
                    $('.gas-vouchers-loading').hide();
                    $('.gas-no-vouchers').show();
                }
            });
            
            // Copy voucher code
            $(document).on('click', '.gas-voucher-code', function() {
                var code = $(this).data('code');
                var $el = $(this);
                
                navigator.clipboard.writeText(code).then(function() {
                    $el.addClass('copied').text('Copied!');
                    setTimeout(function() {
                        $el.removeClass('copied').text(code);
                    }, 2000);
                });
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }
    
    // AJAX Handlers
    public function ajax_get_availability() {
        check_ajax_referer('gas_booking_nonce', 'nonce');
        
        $unit_id = intval($_POST['unit_id']);
        $from = sanitize_text_field($_POST['from']);
        $to = sanitize_text_field($_POST['to']);
        
        $api_url = get_option('gas_api_url', 'https://gas-booking-production.up.railway.app');
        $response = wp_remote_get("{$api_url}/api/public/availability/{$unit_id}?from={$from}&to={$to}", array(
            'timeout' => 30,
            'sslverify' => false
        ));
        
        if (is_wp_error($response)) {
            wp_send_json(array('success' => false, 'error' => $response->get_error_message()));
            return;
        }
        
        wp_send_json(json_decode(wp_remote_retrieve_body($response), true));
    }
    
    public function ajax_get_rooms() {
        check_ajax_referer('gas_booking_nonce', 'nonce');
        
        $client_id = intval($_POST['client_id'] ?? get_option('gas_client_id', ''));
        
        $api_url = get_option('gas_api_url', 'https://gas-booking-production.up.railway.app');
        $response = wp_remote_get("{$api_url}/api/public/client/{$client_id}/rooms", array(
            'timeout' => 30,
            'sslverify' => false
        ));
        
        if (is_wp_error($response)) {
            wp_send_json(array('success' => false, 'error' => $response->get_error_message()));
            return;
        }
        
        wp_send_json(json_decode(wp_remote_retrieve_body($response), true));
    }
    
    public function ajax_calculate_price() {
        check_ajax_referer('gas_booking_nonce', 'nonce');
        
        $api_url = get_option('gas_api_url', 'https://gas-booking-production.up.railway.app');
        
        $data = array(
            'unit_id' => intval($_POST['unit_id']),
            'check_in' => sanitize_text_field($_POST['check_in']),
            'check_out' => sanitize_text_field($_POST['check_out']),
            'guests' => intval($_POST['guests'])
        );
        
        $response = wp_remote_post("{$api_url}/api/public/calculate-price", array(
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($data),
            'timeout' => 30,
            'sslverify' => false
        ));
        
        if (is_wp_error($response)) {
            wp_send_json(array('success' => false, 'error' => $response->get_error_message()));
            return;
        }
        
        wp_send_json(json_decode(wp_remote_retrieve_body($response), true));
    }
    
    public function ajax_create_booking() {
        check_ajax_referer('gas_booking_nonce', 'nonce');
        
        $api_url = get_option('gas_api_url', 'https://gas-booking-production.up.railway.app');
        
        $data = array(
            'unit_id' => intval($_POST['unit_id']),
            'check_in' => sanitize_text_field($_POST['check_in']),
            'check_out' => sanitize_text_field($_POST['check_out']),
            'guests' => intval($_POST['guests']),
            'guest_first_name' => sanitize_text_field($_POST['first_name']),
            'guest_last_name' => sanitize_text_field($_POST['last_name']),
            'guest_email' => sanitize_email($_POST['email']),
            'guest_phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'notes' => sanitize_textarea_field($_POST['notes'] ?? ''),
            'total_price' => floatval($_POST['total_price'] ?? 0)
        );
        
        $response = wp_remote_post("{$api_url}/api/public/book", array(
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($data),
            'timeout' => 30,
            'sslverify' => false
        ));
        
        if (is_wp_error($response)) {
            wp_send_json(array('success' => false, 'error' => $response->get_error_message()));
            return;
        }
        
        wp_send_json(json_decode(wp_remote_retrieve_body($response), true));
    }
}

// Initialize
GAS_Booking::get_instance();
