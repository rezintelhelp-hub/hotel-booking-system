/**
 * GAS Booking Plugin JavaScript - Dwellfort-Inspired Design
 */
jQuery(document).ready(function($) {
    
    // Currency formatting function
    // Converts currency code to symbol and formats price
    function formatPrice(amount, currencyCode) {
        var symbols = {
            'USD': '$', 'GBP': '£', 'EUR': '€', 'AUD': 'A$', 'CAD': 'C$',
            'JPY': '¥', 'CNY': '¥', 'INR': '₹', 'CHF': 'CHF ', 'SEK': 'kr',
            'NOK': 'kr', 'DKK': 'kr', 'NZD': 'NZ$', 'SGD': 'S$', 'HKD': 'HK$',
            'MXN': 'MX$', 'BRL': 'R$', 'ZAR': 'R', 'THB': '฿', 'MYR': 'RM',
            '$': '$', '£': '£', '€': '€'
        };
        var symbol = symbols[currencyCode] || currencyCode || '$';
        var num = parseFloat(amount) || 0;
        // Format with 2 decimal places
        return symbol + num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
    
    // Short format (no decimals) for compact displays
    function formatPriceShort(amount, currencyCode) {
        var symbols = {
            'USD': '$', 'GBP': '£', 'EUR': '€', 'AUD': 'A$', 'CAD': 'C$',
            'JPY': '¥', 'CNY': '¥', 'INR': '₹', 'CHF': 'CHF ', 'SEK': 'kr',
            'NOK': 'kr', 'DKK': 'kr', 'NZD': 'NZ$', 'SGD': 'S$', 'HKD': 'HK$',
            'MXN': 'MX$', 'BRL': 'R$', 'ZAR': 'R', 'THB': '฿', 'MYR': 'RM',
            '$': '$', '£': '£', '€': '€'
        };
        var symbol = symbols[currencyCode] || currencyCode || '$';
        var num = parseFloat(amount) || 0;
        return symbol + Math.round(num).toLocaleString();
    }
    
    // Initialize Flatpickr date pickers
    function initDatePickers() {
        if (typeof flatpickr === 'undefined') return;
        
        var today = new Date();
        var tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        // Room page date pickers
        if ($('.gas-checkin').length) {
            flatpickr('.gas-checkin', {
                dateFormat: 'Y-m-d',
                minDate: 'today',
                altInput: true,
                altFormat: 'd M Y',
                onChange: function(selectedDates, dateStr, instance) {
                    // Update checkout min date and auto-open
                    var checkoutInput = instance.element.closest('.gas-room-widget, .gas-booking-card')?.querySelector('.gas-checkout');
                    if (!checkoutInput) checkoutInput = document.querySelector('.gas-checkout');
                    
                    if (checkoutInput && checkoutInput._flatpickr) {
                        var nextDay = new Date(selectedDates[0]);
                        nextDay.setDate(nextDay.getDate() + 1);
                        checkoutInput._flatpickr.set('minDate', nextDay);
                        // Auto-open checkout picker
                        setTimeout(function() {
                            checkoutInput._flatpickr.open();
                        }, 100);
                    }
                }
            });
        }
        
        if ($('.gas-checkout').length) {
            flatpickr('.gas-checkout', {
                dateFormat: 'Y-m-d',
                minDate: tomorrow,
                altInput: true,
                altFormat: 'd M Y'
            });
        }
        
        // Search widget date pickers - initialize each widget separately
        $('.gas-search-widget').each(function() {
            var $widget = $(this);
            var $checkin = $widget.find('.gas-checkin-date');
            var $checkout = $widget.find('.gas-checkout-date');
            
            if ($checkin.length) {
                flatpickr($checkin[0], {
                    dateFormat: 'Y-m-d',
                    minDate: 'today',
                    altInput: true,
                    altFormat: 'd M Y',
                    onChange: function(selectedDates, dateStr, instance) {
                        if (selectedDates.length && $checkout.length) {
                            var nextDay = new Date(selectedDates[0]);
                            nextDay.setDate(nextDay.getDate() + 1);
                            
                            if ($checkout[0]._flatpickr) {
                                $checkout[0]._flatpickr.set('minDate', nextDay);
                                // Auto-open checkout picker
                                setTimeout(function() {
                                    $checkout[0]._flatpickr.open();
                                }, 100);
                            }
                        }
                    }
                });
            }
            
            if ($checkout.length) {
                flatpickr($checkout[0], {
                    dateFormat: 'Y-m-d',
                    minDate: tomorrow,
                    altInput: true,
                    altFormat: 'd M Y'
                });
            }
        });
        
        // Filter date pickers (on rooms page) - same logic
        $('.gas-date-filter').each(function() {
            var $filter = $(this);
            var $checkin = $filter.find('.gas-filter-checkin');
            var $checkout = $filter.find('.gas-filter-checkout');
            
            if ($checkin.length) {
                flatpickr($checkin[0], {
                    dateFormat: 'Y-m-d',
                    minDate: 'today',
                    altInput: true,
                    altFormat: 'd M Y',
                    onChange: function(selectedDates, dateStr, instance) {
                        if (selectedDates.length && $checkout.length) {
                            var nextDay = new Date(selectedDates[0]);
                            nextDay.setDate(nextDay.getDate() + 1);
                            
                            if ($checkout[0]._flatpickr) {
                                $checkout[0]._flatpickr.set('minDate', nextDay);
                                // Auto-open checkout picker
                                setTimeout(function() {
                                    $checkout[0]._flatpickr.open();
                                }, 100);
                            }
                        }
                    }
                });
            }
            
            if ($checkout.length) {
                flatpickr($checkout[0], {
                    dateFormat: 'Y-m-d',
                    minDate: tomorrow,
                    altInput: true,
                    altFormat: 'd M Y'
                });
            }
        });
    }
    
    // Initialize date pickers after a small delay to ensure DOM is ready
    setTimeout(initDatePickers, 100);
    
    // SVG Icons
    var icons = {
        users: '<svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        bed: '<svg viewBox="0 0 24 24"><path d="M2 4v16"></path><path d="M2 8h18a2 2 0 0 1 2 2v10"></path><path d="M2 17h20"></path><path d="M6 8v9"></path></svg>',
        bath: '<svg viewBox="0 0 24 24"><path d="M9 6 6.5 3.5a1.5 1.5 0 0 0-1-.5C4.683 3 4 3.683 4 4.5V17a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5"></path><line x1="10" x2="8" y1="5" y2="7"></line><line x1="2" x2="22" y1="12" y2="12"></line><line x1="7" x2="7" y1="19" y2="21"></line><line x1="17" x2="17" y1="19" y2="21"></line></svg>',
        home: '<svg viewBox="0 0 24 24"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>',
        wifi: '<svg viewBox="0 0 24 24"><path d="M5 13a10 10 0 0 1 14 0"></path><path d="M8.5 16.5a5 5 0 0 1 7 0"></path><line x1="12" x2="12.01" y1="20" y2="20"></line></svg>',
        tv: '<svg viewBox="0 0 24 24"><rect width="20" height="15" x="2" y="7" rx="2" ry="2"></rect><polyline points="17 2 12 7 7 2"></polyline></svg>',
        coffee: '<svg viewBox="0 0 24 24"><path d="M17 8h1a4 4 0 1 1 0 8h-1"></path><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"></path><line x1="6" x2="6" y1="2" y2="4"></line><line x1="10" x2="10" y1="2" y2="4"></line><line x1="14" x2="14" y1="2" y2="4"></line></svg>',
        car: '<svg viewBox="0 0 24 24"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.5 2.8C1.4 11.3 1 12.1 1 13v3c0 .6.4 1 1 1h2"></path><circle cx="7" cy="17" r="2"></circle><circle cx="17" cy="17" r="2"></circle></svg>',
        aircon: '<svg viewBox="0 0 24 24"><path d="M8 16a4 4 0 1 1 8 0"></path><path d="M12 4v8"></path><path d="m4.93 10.93 1.41 1.41"></path><path d="M2 18h2"></path><path d="M20 18h2"></path><path d="m19.07 10.93-1.41 1.41"></path><path d="M22 22H2"></path></svg>',
        kitchen: '<svg viewBox="0 0 24 24"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"></path><path d="M7 2v20"></path><path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"></path></svg>',
        check: '<svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"></polyline></svg>'
    };
    
    // Amenity icon mapping
    var amenityIcons = {
        'wifi': icons.wifi,
        'tv': icons.tv,
        'television': icons.tv,
        'air conditioning': icons.aircon,
        'air-conditioning': icons.aircon,
        'ac': icons.aircon,
        'heating': icons.aircon,
        'kitchen': icons.kitchen,
        'parking': icons.car,
        'coffee': icons.coffee,
        'breakfast': icons.coffee
    };
    
    function getAmenityIcon(name) {
        var lowerName = name.toLowerCase();
        for (var key in amenityIcons) {
            if (lowerName.includes(key)) {
                return amenityIcons[key];
            }
        }
        return icons.check;
    }
    
    // Search button click handler
    $(document).on('click', '.gas-search-button', function(e) {
        e.preventDefault();
        
        // Find the parent widget to get values from the correct form
        var $widget = $(this).closest('.gas-search-widget');
        
        var checkin = $widget.find('.gas-checkin-date').val();
        var checkout = $widget.find('.gas-checkout-date').val();
        var guests = $widget.find('.gas-guests-select').val();
        var location = $widget.find('.gas-location-input').val();
        
        var baseUrl = gasBooking.searchResultsUrl || '/book-now/';
        var params = [];
        
        if (location) params.push('location=' + encodeURIComponent(location));
        if (checkin) params.push('checkin=' + checkin);
        if (checkout) params.push('checkout=' + checkout);
        if (guests) params.push('guests=' + guests);
        
        var url = baseUrl;
        if (params.length > 0) {
            url += (baseUrl.indexOf('?') > -1 ? '&' : '?') + params.join('&');
        }
        
        window.location.href = url;
    });
    
    // Rooms grid - check availability on page load if dates provided
    if (typeof gasRoomsConfig !== 'undefined' && gasRoomsConfig.checkin && gasRoomsConfig.checkout) {
        checkAllAvailability(gasRoomsConfig.checkin, gasRoomsConfig.checkout, gasRoomsConfig.guests);
    }
    
    // Room detail widget
    var $roomWidget = $('.gas-room-widget');
    if ($roomWidget.length) {
        var unitId = $roomWidget.data('unit-id');
        var checkin = $roomWidget.data('checkin') || '';
        var checkout = $roomWidget.data('checkout') || '';
        var guests = $roomWidget.data('guests') || 1;
        
        loadRoomDetails(unitId, checkin, checkout, guests);
    }
    
    function loadRoomDetails(unitId, checkin, checkout, guests) {
        $.ajax({
            url: gasBooking.apiUrl + '/api/public/unit/' + unitId,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success && response.unit) {
                    renderRoomDetails(response.unit, response.images || [], response.amenities || [], checkin, checkout, guests);
                    // Also load property info for terms
                    if (response.unit.property_id) {
                        loadPropertyTerms(response.unit.property_id);
                    }
                } else {
                    $('.gas-room-loading').html('<p class="gas-error">Unable to load room details: ' + (response.error || 'Unknown error') + '</p>');
                }
            },
            error: function() {
                $('.gas-room-loading').html('<p class="gas-error">Connection error. Please try again.</p>');
            }
        });
    }
    
    function loadPropertyTerms(propertyId) {
        $.ajax({
            url: gasBooking.apiUrl + '/api/public/property/' + propertyId + '/terms',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    if (response.house_rules) {
                        $('.gas-house-rules').html('<p>' + response.house_rules.replace(/\n/g, '</p><p>') + '</p>');
                    }
                    if (response.cancellation_policy) {
                        $('.gas-cancellation-policy').html('<p>' + response.cancellation_policy.replace(/\n/g, '</p><p>') + '</p>');
                    }
                    if (response.general_terms) {
                        $('.gas-general-terms').html('<p>' + response.general_terms.replace(/\n/g, '</p><p>') + '</p>');
                    }
                }
            }
        });
    }
    
    function renderRoomDetails(room, images, amenities, checkin, checkout, guests) {
        var currency = room.currency || gasBooking.currency || '$';
        
        // Set title and location
        $('.gas-room-title').text(room.name);
        $('.gas-room-location').text(room.property_name || '');
        
        // Set meta with icons
        var metaHtml = '';
        if (room.max_guests) {
            metaHtml += '<div class="gas-meta-item"><span class="gas-meta-icon">' + icons.users + '</span><span>Guests: ' + room.max_guests + '</span></div>';
        }
        if (room.bedroom_count) {
            metaHtml += '<div class="gas-meta-item"><span class="gas-meta-icon">' + icons.bed + '</span><span>Bedrooms: ' + room.bedroom_count + '</span></div>';
        }
        if (room.bathroom_count) {
            metaHtml += '<div class="gas-meta-item"><span class="gas-meta-icon">' + icons.bath + '</span><span>Bathrooms: ' + room.bathroom_count + '</span></div>';
        }
        if (room.unit_type) {
            metaHtml += '<div class="gas-meta-item"><span class="gas-meta-icon">' + icons.home + '</span><span>' + room.unit_type + '</span></div>';
        }
        $('.gas-room-meta').html(metaHtml);
        
        // Set base price
        var basePrice = parseFloat(room.base_price) || 0;
        $('.gas-price-amount').text(formatPriceShort(basePrice, currency));
        
        // Render gallery
        renderGallery(images);
        
        // Set descriptions - use short_description and full_description fields
        var shortDesc = parseDescription(room.short_description) || parseDescription(room.description) || '';
        var fullDesc = parseDescription(room.full_description) || '';
        
        if (shortDesc) {
            $('.gas-description-short').html('<p>' + shortDesc.replace(/\n/g, '</p><p>') + '</p>');
        } else {
            $('.gas-description-short').html('<p style="color: #64748b; font-style: italic;">No description available.</p>');
        }
        
        // Show More Info toggle only if there's a full description different from short
        if (fullDesc && fullDesc !== shortDesc) {
            $('.gas-description-full').html('<p>' + fullDesc.replace(/\n/g, '</p><p>') + '</p>');
            $('.gas-more-info-toggle').show();
        } else {
            $('.gas-more-info-toggle').hide();
            $('.gas-description-full').hide();
        }
        
        // Render amenities grouped by category
        renderAmenities(amenities);
        
        // Build guest dropdown
        var maxGuests = room.max_guests || 2;
        var $guestsSelect = $('.gas-guests');
        $guestsSelect.empty();
        for (var i = 1; i <= maxGuests; i++) {
            $guestsSelect.append('<option value="' + i + '"' + (i == guests ? ' selected' : '') + '>' + i + ' Guest' + (i > 1 ? 's' : '') + '</option>');
        }
        
        // Store room data
        $roomWidget.data('room', room);
        $roomWidget.data('currency', currency);
        
        // Load initial calendar
        loadAvailabilityCalendar(room.id || $roomWidget.data('unit-id'), new Date());
        
        // Show map if coordinates available
        if (room.latitude && room.longitude) {
            renderMap(room.latitude, room.longitude, room.property_name || room.name);
        } else if (room.city || room.country) {
            // Use city/country for a general location map
            renderMapByAddress((room.city || '') + ', ' + (room.country || ''));
        }
        
        // Show content
        $('.gas-room-loading').hide();
        $('.gas-room-content').show();
        
        // Load offers (upsells are shown on checkout page only)
        var unitId = room.id || $roomWidget.data('unit-id');
        loadOffers(unitId, checkin, checkout, guests);
        
        // If dates were passed, auto-calculate price
        if (checkin && checkout) {
            calculatePrice(unitId, checkin, checkout, guests);
        }
    }
    
    function renderGallery(images) {
        var $gallery = $('.gas-gallery');
        
        if (!images || images.length === 0) {
            $gallery.html('<div class="gas-gallery-placeholder">🏠</div>');
            return;
        }
        
        var html = '';
        var mainUrl = images[0].url || images[0].image_url || '';
        
        // Main large image
        html += '<img class="gas-gallery-main" src="' + mainUrl + '" alt="Room image" data-index="0">';
        
        // Grid of 4 smaller images
        if (images.length > 1) {
            html += '<div class="gas-gallery-grid">';
            for (var i = 1; i < Math.min(5, images.length); i++) {
                var url = images[i].url || images[i].image_url || '';
                if (i === 4 && images.length > 5) {
                    // Show "View all" overlay on last thumbnail
                    html += '<div class="gas-gallery-more" data-index="' + i + '">';
                    html += '<img class="gas-gallery-thumb" src="' + url + '" alt="Thumbnail">';
                    html += '<div class="gas-gallery-more-overlay">View all ' + images.length + ' images</div>';
                    html += '</div>';
                } else {
                    html += '<img class="gas-gallery-thumb" src="' + url + '" alt="Thumbnail" data-index="' + i + '">';
                }
            }
            html += '</div>';
        }
        
        $gallery.html(html);
        
        // Store images for lightbox
        $roomWidget.data('images', images);
    }
    
    function renderAmenities(amenities) {
        if (!amenities || amenities.length === 0) {
            $('.gas-tab-btn[data-tab="features"]').hide();
            return;
        }
        
        // Group by category
        var categories = {};
        amenities.forEach(function(amenity) {
            var cat = amenity.category || 'General';
            if (!categories[cat]) {
                categories[cat] = [];
            }
            categories[cat].push(amenity.name);
        });
        
        var html = '';
        for (var cat in categories) {
            html += '<div class="gas-amenities-category">';
            html += '<h4 class="gas-amenities-category-title">' + cat + '</h4>';
            html += '<div class="gas-amenities-list">';
            categories[cat].forEach(function(name) {
                var displayName = parseDescription(name) || name;
                var icon = getAmenityIcon(displayName);
                html += '<div class="gas-amenity-tag"><span class="gas-amenity-icon">' + icon + '</span>' + displayName + '</div>';
            });
            html += '</div></div>';
        }
        
        $('.gas-amenities-container').html(html);
    }
    
    // Gallery click - open lightbox
    $(document).on('click', '.gas-gallery-main, .gas-gallery-thumb, .gas-gallery-more', function() {
        var index = parseInt($(this).data('index')) || 0;
        openLightbox(index);
    });
    
    function openLightbox(index) {
        var images = $roomWidget.data('images');
        if (!images || images.length === 0) return;
        
        var $lightbox = $('.gas-lightbox');
        $lightbox.data('current', index);
        updateLightboxImage(index);
        $lightbox.addClass('active');
        $('body').css('overflow', 'hidden');
    }
    
    function updateLightboxImage(index) {
        var images = $roomWidget.data('images');
        var url = images[index].url || images[index].image_url || '';
        $('.gas-lightbox img').attr('src', url);
        $('.gas-lightbox-counter').text((index + 1) + ' / ' + images.length);
    }
    
    $(document).on('click', '.gas-lightbox-close', function() {
        $('.gas-lightbox').removeClass('active');
        $('body').css('overflow', '');
    });
    
    // Click on lightbox image to close
    $(document).on('click', '.gas-lightbox img', function() {
        $('.gas-lightbox').removeClass('active');
        $('body').css('overflow', '');
    });
    
    $(document).on('click', '.gas-lightbox-prev', function(e) {
        e.stopPropagation();
        var images = $roomWidget.data('images');
        var current = $('.gas-lightbox').data('current');
        var newIndex = (current - 1 + images.length) % images.length;
        $('.gas-lightbox').data('current', newIndex);
        updateLightboxImage(newIndex);
    });
    
    $(document).on('click', '.gas-lightbox-next', function(e) {
        e.stopPropagation();
        var images = $roomWidget.data('images');
        var current = $('.gas-lightbox').data('current');
        var newIndex = (current + 1) % images.length;
        $('.gas-lightbox').data('current', newIndex);
        updateLightboxImage(newIndex);
    });
    
    // Close lightbox on background click
    $(document).on('click', '.gas-lightbox', function(e) {
        if ($(e.target).hasClass('gas-lightbox')) {
            $('.gas-lightbox').removeClass('active');
            $('body').css('overflow', '');
        }
    });
    
    // More Info toggle
    $(document).on('click', '.gas-more-info-toggle', function() {
        $(this).toggleClass('active');
        $('.gas-description-full').toggleClass('active');
        
        // Update button text
        var $span = $(this).find('span');
        if ($(this).hasClass('active')) {
            $span.text('Less Information');
        } else {
            $span.text('More Information');
        }
    });
    
    // Keyboard navigation for lightbox
    $(document).on('keydown', function(e) {
        if (!$('.gas-lightbox').hasClass('active')) return;
        if (e.key === 'Escape') $('.gas-lightbox-close').click();
        if (e.key === 'ArrowLeft') $('.gas-lightbox-prev').click();
        if (e.key === 'ArrowRight') $('.gas-lightbox-next').click();
    });
    
    // Tabs
    $(document).on('click', '.gas-tab-btn', function() {
        var tab = $(this).data('tab');
        
        $('.gas-tab-btn').removeClass('active');
        $(this).addClass('active');
        
        $('.gas-tab-content').removeClass('active');
        $('.gas-tab-content[data-tab="' + tab + '"]').addClass('active');
    });
    
    // Accordion
    $(document).on('click', '.gas-accordion-header', function() {
        var $item = $(this).closest('.gas-accordion-item');
        $item.toggleClass('active');
    });
    
    // Availability Calendar - 2 month view
    var calendarMonth = new Date();
    
    function loadAvailabilityCalendar(unitId, date) {
        var year = date.getFullYear();
        var month = date.getMonth();
        
        // Get data for 2 months
        var firstDay = new Date(year, month, 1);
        var lastDayMonth2 = new Date(year, month + 2, 0);
        
        var from = firstDay.toISOString().split('T')[0];
        var to = lastDayMonth2.toISOString().split('T')[0];
        
        $.ajax({
            url: gasBooking.apiUrl + '/api/public/availability/' + unitId + '?from=' + from + '&to=' + to,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                var availability = response.calendar || [];
                renderCalendar(date, availability, 'current');
                
                var nextMonth = new Date(year, month + 1, 1);
                renderCalendar(nextMonth, availability, 'next');
            }
        });
    }
    
    function renderCalendar(date, availability, which) {
        var year = date.getFullYear();
        var month = date.getMonth();
        var firstDay = new Date(year, month, 1);
        var lastDay = new Date(year, month + 1, 0);
        var startDay = firstDay.getDay(); // 0 = Sunday
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // Update title
        var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        var $calendar = $('.gas-calendar[data-month="' + which + '"]');
        $calendar.find('.gas-calendar-title').text(monthNames[month] + ' ' + year);
        
        // Create availability lookup
        var availLookup = {};
        availability.forEach(function(day) {
            availLookup[day.date] = day.available;
        });
        
        var html = '';
        
        // Day names
        var dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        dayNames.forEach(function(name) {
            html += '<div class="gas-calendar-day-name">' + name + '</div>';
        });
        
        // Empty cells before first day
        for (var i = 0; i < startDay; i++) {
            html += '<div class="gas-calendar-day empty"></div>';
        }
        
        // Days of month
        for (var d = 1; d <= lastDay.getDate(); d++) {
            var dateStr = year + '-' + String(month + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
            var thisDate = new Date(year, month, d);
            var isPast = thisDate < today;
            var isAvailable = availLookup[dateStr];
            
            var classes = 'gas-calendar-day';
            if (isPast) {
                classes += ' past';
            } else if (isAvailable === false) {
                classes += ' unavailable';
            } else if (isAvailable === true) {
                classes += ' available';
            } else {
                // No data - assume available
                classes += ' available';
            }
            
            html += '<div class="' + classes + '">' + d + '</div>';
        }
        
        $calendar.find('.gas-calendar-grid').html(html);
    }
    
    $(document).on('click', '.gas-cal-prev', function() {
        calendarMonth.setMonth(calendarMonth.getMonth() - 1);
        var unitId = $roomWidget.data('unit-id');
        loadAvailabilityCalendar(unitId, calendarMonth);
    });
    
    $(document).on('click', '.gas-cal-next', function() {
        calendarMonth.setMonth(calendarMonth.getMonth() + 1);
        var unitId = $roomWidget.data('unit-id');
        loadAvailabilityCalendar(unitId, calendarMonth);
    });
    
    function parseDescription(desc) {
        if (!desc) return '';
        if (typeof desc === 'object') {
            return desc.en || '';
        }
        try {
            var parsed = JSON.parse(desc);
            return parsed.en || desc;
        } catch(e) {
            return desc;
        }
    }
    
    // Map functions - using Leaflet for interactive maps
    var propertyMap = null;
    var propertyMarker = null;
    
    function renderMap(lat, lng, title) {
        var $mapContainer = $('.gas-map-container');
        var $map = $('.gas-map');
        
        // Parse coordinates
        lat = parseFloat(lat);
        lng = parseFloat(lng);
        
        if (isNaN(lat) || isNaN(lng)) {
            console.log('Invalid coordinates for map');
            return;
        }
        
        // Show the container
        $mapContainer.show();
        
        // Give DOM time to render, then initialize map
        setTimeout(function() {
            // Destroy existing map if any
            if (propertyMap) {
                propertyMap.remove();
                propertyMap = null;
            }
            
            // Create the Leaflet map
            propertyMap = L.map($map[0], {
                scrollWheelZoom: false,
                dragging: !L.Browser.mobile
            }).setView([lat, lng], 15);
            
            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                maxZoom: 19
            }).addTo(propertyMap);
            
            // Add marker
            propertyMarker = L.marker([lat, lng]).addTo(propertyMap);
            
            if (title) {
                propertyMarker.bindPopup('<strong>' + title + '</strong>').openPopup();
            }
            
            // Fix map size after container is visible
            propertyMap.invalidateSize();
        }, 100);
    }
    
    function renderMapByAddress(address) {
        if (!address || address.trim() === ',' || address.trim() === '') return;
        
        var $mapContainer = $('.gas-map-container');
        var $map = $('.gas-map');
        
        // Use Nominatim geocoding API to get coordinates
        var encodedAddress = encodeURIComponent(address.trim());
        
        $.ajax({
            url: 'https://nominatim.openstreetmap.org/search?format=json&q=' + encodedAddress,
            method: 'GET',
            headers: {
                'User-Agent': 'GAS-Booking-Plugin/1.0'
            },
            success: function(results) {
                if (results && results.length > 0) {
                    var lat = parseFloat(results[0].lat);
                    var lng = parseFloat(results[0].lon);
                    renderMap(lat, lng, address);
                } else {
                    console.log('Address not found:', address);
                }
            },
            error: function(err) {
                console.log('Geocoding error:', err);
            }
        });
    }
    
    // Date change handler
    $(document).on('change', '.gas-checkin, .gas-checkout', function() {
        var checkin = $('.gas-checkin').val();
        var checkout = $('.gas-checkout').val();
        var guests = $('.gas-guests').val();
        var unitId = $roomWidget.data('unit-id');
        
        if (checkin && checkout && new Date(checkout) > new Date(checkin)) {
            calculatePrice(unitId, checkin, checkout, guests);
        } else {
            // Reset to select dates state
            $('.gas-price-breakdown').hide();
            $('.gas-book-btn').prop('disabled', true).text('Select dates to check availability');
        }
    });
    
    function calculatePrice(unitId, checkin, checkout, guests) {
        var $btn = $('.gas-book-btn');
        $btn.prop('disabled', true).text('Checking availability...');
        
        // Get selected upsells
        var selectedUpsells = [];
        $('.gas-upsell-item.selected').each(function() {
            selectedUpsells.push({
                id: $(this).data('upsell-id'),
                quantity: parseInt($(this).find('.gas-upsell-qty-value').text()) || 1
            });
        });
        
        // Get voucher code if applied
        var voucherCode = $roomWidget.data('voucher-code') || '';
        
        // Get selected rate type (standard or offer)
        var selectedRate = $roomWidget.data('selected-rate') || 'standard';
        
        $.ajax({
            url: gasBooking.apiUrl + '/api/public/calculate-price',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                unit_id: unitId,
                check_in: checkin,
                check_out: checkout,
                guests: guests,
                upsells: selectedUpsells,
                voucher_code: voucherCode,
                rate_type: selectedRate
            }),
            success: function(response) {
                var currency = $roomWidget.data('currency') || gasBooking.currency || '$';
                
                console.log('Calculate price response:', response);
                console.log('Offer from API:', response.offer_applied);
                console.log('Offer from banner:', $roomWidget.data('active-offer'));
                
                if (response.success && response.available) {
                    var nights = response.nights;
                    var accommodationTotal = response.accommodation_total || 0;
                    var upsellsTotal = response.upsells_total || 0;
                    var offerDiscount = response.offer_discount || 0;
                    var voucherDiscount = response.voucher_discount || 0;
                    var grandTotal = response.grand_total || 0;
                    
                    // Use offer from API response OR from the banner (already loaded)
                    var activeOffer = response.offer_applied || $roomWidget.data('active-offer');
                    
                    // Store pricing data
                    $roomWidget.data('pricing', {
                        nights: nights,
                        accommodationTotal: accommodationTotal,
                        currency: currency,
                        offer: activeOffer
                    });
                    
                    // Build rate options if offer exists
                    if (activeOffer) {
                        renderRateOptions(nights, accommodationTotal, activeOffer, currency);
                    } else {
                        // No offer - hide rate options, show simple breakdown
                        $('.gas-rate-options').hide();
                        showSimplePricing(nights, accommodationTotal, upsellsTotal, voucherDiscount, grandTotal, currency);
                    }
                    
                    // Update button based on selected rate
                    updateBookingButton(currency);
                    
                    $roomWidget.data('price-details', response);
                } else {
                    // NOT AVAILABLE - Switch to Availability tab
                    $('.gas-tab-btn').removeClass('active');
                    $('.gas-tab-btn[data-tab="availability"]').addClass('active');
                    $('.gas-tab-content').removeClass('active');
                    $('.gas-tab-content[data-tab="availability"]').addClass('active');
                    
                    $('.gas-price-breakdown').hide();
                    $('.gas-rate-options').hide();
                    $btn.prop('disabled', true).text('Not available for selected dates');
                }
            },
            error: function() {
                $btn.prop('disabled', true).text('Error checking availability');
            }
        });
    }
    
    // Render rate options (Standard vs Offer)
    function renderRateOptions(nights, standardTotal, offer, currency) {
        var perNightStandard = Math.round(standardTotal / nights);
        var discountAmount = 0;
        
        if (offer.discount_type === 'percentage') {
            discountAmount = standardTotal * (offer.discount_value / 100);
        } else {
            discountAmount = parseFloat(offer.discount_value);
        }
        
        var offerTotal = standardTotal - discountAmount;
        var perNightOffer = Math.round(offerTotal / nights);
        var savingsPercent = Math.round((discountAmount / standardTotal) * 100);
        
        var html = '<div class="gas-rate-options">';
        html += '<div class="gas-rate-options-title">Choose your rate:</div>';
        
        // Standard Rate
        html += '<div class="gas-rate-option" data-rate="standard">';
        html += '<div class="gas-rate-radio"><div class="gas-rate-radio-inner"></div></div>';
        html += '<div class="gas-rate-details">';
        html += '<div class="gas-rate-name">Standard Rate</div>';
        html += '<div class="gas-rate-features"><span class="gas-rate-feature">✓ Free cancellation</span></div>';
        html += '</div>';
        html += '<div class="gas-rate-price">';
        html += '<div class="gas-rate-total">' + formatPrice(standardTotal, currency) + '</div>';
        html += '<div class="gas-rate-per-night">' + formatPriceShort(perNightStandard, currency) + '/night</div>';
        html += '</div>';
        html += '</div>';
        
        // Offer Rate
        html += '<div class="gas-rate-option selected" data-rate="offer">';
        html += '<div class="gas-rate-radio"><div class="gas-rate-radio-inner"></div></div>';
        html += '<div class="gas-rate-details">';
        html += '<div class="gas-rate-name">' + offer.name + ' <span class="gas-rate-badge">Save ' + savingsPercent + '%</span></div>';
        html += '<div class="gas-rate-features"><span class="gas-rate-feature warning">✗ Non-refundable</span></div>';
        html += '</div>';
        html += '<div class="gas-rate-price">';
        html += '<div class="gas-rate-total">' + formatPrice(offerTotal, currency) + '</div>';
        html += '<div class="gas-rate-per-night"><s>' + formatPriceShort(perNightStandard, currency) + '</s> ' + formatPriceShort(perNightOffer, currency) + '/night</div>';
        html += '</div>';
        html += '</div>';
        
        html += '</div>';
        
        // Replace or insert rate options
        if ($('.gas-rate-options').length) {
            $('.gas-rate-options').replaceWith(html);
        } else {
            $('.gas-guest-field').after(html);
        }
        
        // Store totals for later
        $roomWidget.data('standard-total', standardTotal);
        $roomWidget.data('offer-total', offerTotal);
        $roomWidget.data('selected-rate', 'offer'); // Default to offer
        
        // Hide old price breakdown when showing rate options
        $('.gas-price-breakdown').hide();
    }
    
    // Show simple pricing (no offer)
    function showSimplePricing(nights, accommodationTotal, upsellsTotal, voucherDiscount, grandTotal, currency) {
        var perNight = Math.round(accommodationTotal / nights);
        
        $('.gas-nights-text').text(formatPriceShort(perNight, currency) + ' x ' + nights + ' night' + (nights > 1 ? 's' : ''));
        $('.gas-nights-price').text(formatPrice(accommodationTotal, currency));
        
        if (upsellsTotal > 0) {
            $('.gas-upsells-row').show();
            $('.gas-upsells-total').text('+' + formatPrice(upsellsTotal, currency));
        } else {
            $('.gas-upsells-row').hide();
        }
        
        $('.gas-offer-row').hide();
        
        if (voucherDiscount > 0) {
            $('.gas-voucher-row').show();
            $('.gas-voucher-amount').text('-' + formatPrice(voucherDiscount, currency));
        } else {
            $('.gas-voucher-row').hide();
        }
        
        $('.gas-total-price').text(formatPrice(grandTotal, currency));
        $('.gas-price-breakdown').show();
        
        $roomWidget.data('total-price', grandTotal);
    }
    
    // Update booking button based on selected rate
    function updateBookingButton(currency) {
        var $btn = $('.gas-book-btn');
        var selectedRate = $roomWidget.data('selected-rate') || 'standard';
        var total;
        
        if (selectedRate === 'offer') {
            total = $roomWidget.data('offer-total') || $roomWidget.data('standard-total');
        } else {
            total = $roomWidget.data('standard-total');
        }
        
        // Add upsells
        var upsellsTotal = 0;
        $('.gas-upsell-item.selected').each(function() {
            // Would need to recalculate based on upsell data
        });
        
        $roomWidget.data('total-price', total);
        $btn.prop('disabled', false).text('Book Now - ' + formatPrice(total, currency));
    }
    
    // Rate option click handler
    $(document).on('click', '.gas-rate-option', function() {
        $('.gas-rate-option').removeClass('selected');
        $(this).addClass('selected');
        
        var rate = $(this).data('rate');
        $roomWidget.data('selected-rate', rate);
        
        var currency = $roomWidget.data('currency') || gasBooking.currency || '$';
        updateBookingButton(currency);
    });
    
    // Load and display offers
    function loadOffers(unitId, checkin, checkout, guests) {
        if (!gasBooking.clientId) return;
        
        var params = '?unit_id=' + unitId;
        if (checkin) params += '&check_in=' + checkin;
        if (checkout) params += '&check_out=' + checkout;
        if (guests) params += '&guests=' + guests;
        
        $.ajax({
            url: gasBooking.apiUrl + '/api/public/client/' + gasBooking.clientId + '/offers' + params,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success && response.offers && response.offers.length > 0) {
                    // Show generic banner (specific offer shown in rate options)
                    $('.gas-offers-banner').show();
                    
                    // Store offers for rate selection
                    $roomWidget.data('available-offers', response.offers);
                    $roomWidget.data('active-offer', response.offers[0]);
                } else {
                    $('.gas-offers-banner').hide();
                    $roomWidget.data('available-offers', []);
                    $roomWidget.data('active-offer', null);
                }
            }
        });
    }
    
    // Load and display upsells
    function loadUpsells(unitId) {
        if (!gasBooking.clientId) return;
        
        $.ajax({
            url: gasBooking.apiUrl + '/api/public/client/' + gasBooking.clientId + '/upsells?unit_id=' + unitId,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success && response.upsells && response.upsells.length > 0) {
                    renderUpsells(response.upsells_by_category || {}, response.upsells);
                    $('.gas-upsells-section').show();
                } else {
                    $('.gas-upsells-section').hide();
                }
            }
        });
    }
    
    // Render upsells list
    function renderUpsells(byCategory, allUpsells) {
        var currency = $roomWidget.data('currency') || gasBooking.currency || '$';
        var html = '';
        
        // If we have categories, group them
        if (Object.keys(byCategory).length > 0) {
            for (var category in byCategory) {
                html += '<div class="gas-upsell-category">' + category + '</div>';
                byCategory[category].forEach(function(upsell) {
                    html += renderUpsellItem(upsell, currency);
                });
            }
        } else {
            // No categories, just list all
            allUpsells.forEach(function(upsell) {
                html += renderUpsellItem(upsell, currency);
            });
        }
        
        $('.gas-upsells-list').html(html);
    }
    
    function renderUpsellItem(upsell, currency) {
        var priceText = formatPriceShort(upsell.price, currency);
        var priceLabel = '';
        
        switch (upsell.charge_type) {
            case 'per_night':
                priceLabel = '/night';
                break;
            case 'per_guest':
                priceLabel = '/guest';
                break;
            case 'per_guest_per_night':
                priceLabel = '/guest/night';
                break;
            default:
                priceLabel = '';
        }
        
        return '<div class="gas-upsell-item" data-upsell-id="' + upsell.id + '">' +
            '<div class="gas-upsell-checkbox"></div>' +
            '<div class="gas-upsell-info">' +
                '<div class="gas-upsell-name">' + upsell.name + '</div>' +
                (upsell.description ? '<div class="gas-upsell-description">' + upsell.description + '</div>' : '') +
            '</div>' +
            '<div class="gas-upsell-price">' + priceText + '<small>' + priceLabel + '</small></div>' +
        '</div>';
    }
    
    // Upsell item click handler
    $(document).on('click', '.gas-upsell-item', function() {
        $(this).toggleClass('selected');
        
        // Recalculate price if dates are selected
        var checkin = $('.gas-checkin').val();
        var checkout = $('.gas-checkout').val();
        var unitId = $roomWidget.data('unit-id');
        
        if (checkin && checkout && unitId) {
            calculatePrice(unitId, checkin, checkout, $('.gas-guests').val());
        }
    });
    
    // Voucher toggle
    $(document).on('click', '.gas-voucher-toggle', function() {
        $('.gas-voucher-input').slideToggle();
    });
    
    // Voucher apply
    $(document).on('click', '.gas-voucher-apply', function() {
        var code = $('.gas-voucher-code').val().trim().toUpperCase();
        if (!code) return;
        
        var $btn = $(this);
        $btn.prop('disabled', true).text('Checking...');
        
        $.ajax({
            url: gasBooking.apiUrl + '/api/public/validate-voucher',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                code: code,
                unit_id: $roomWidget.data('unit-id'),
                check_in: $('.gas-checkin').val(),
                check_out: $('.gas-checkout').val()
            }),
            success: function(response) {
                $btn.prop('disabled', false).text('Apply');
                
                if (response.success && response.valid) {
                    // Store voucher
                    $roomWidget.data('voucher-code', code);
                    
                    // Show applied state
                    $('.gas-voucher-input').hide();
                    $('.gas-voucher-toggle').hide();
                    $('.gas-voucher-name').text('✓ ' + response.voucher.name + ' (' + code + ')');
                    $('.gas-voucher-applied').show();
                    
                    // Recalculate price
                    var checkin = $('.gas-checkin').val();
                    var checkout = $('.gas-checkout').val();
                    if (checkin && checkout) {
                        calculatePrice($roomWidget.data('unit-id'), checkin, checkout, $('.gas-guests').val());
                    }
                } else {
                    alert(response.error || 'Invalid voucher code');
                }
            },
            error: function() {
                $btn.prop('disabled', false).text('Apply');
                alert('Error validating voucher');
            }
        });
    });
    
    // Voucher remove
    $(document).on('click', '.gas-voucher-remove', function() {
        $roomWidget.data('voucher-code', '');
        $('.gas-voucher-applied').hide();
        $('.gas-voucher-toggle').show();
        $('.gas-voucher-code').val('');
        
        // Recalculate price
        var checkin = $('.gas-checkin').val();
        var checkout = $('.gas-checkout').val();
        if (checkin && checkout) {
            calculatePrice($roomWidget.data('unit-id'), checkin, checkout, $('.gas-guests').val());
        }
    });
    
    function calculateNights(checkin, checkout) {
        var start = new Date(checkin);
        var end = new Date(checkout);
        return Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    }
    
    // Book button click - redirect to checkout page
    $(document).on('click', '.gas-book-btn:not(:disabled)', function() {
        var unitId = $roomWidget.data('unit-id');
        var checkin = $('.gas-checkin').val();
        var checkout = $('.gas-checkout').val();
        var guests = $('.gas-guests').val();
        var rateType = $roomWidget.data('selected-rate') || 'standard';
        
        // Build checkout URL
        var checkoutUrl = gasBooking.checkoutUrl || '/checkout/';
        checkoutUrl += '?room=' + unitId;
        checkoutUrl += '&checkin=' + checkin;
        checkoutUrl += '&checkout=' + checkout;
        checkoutUrl += '&guests=' + guests;
        checkoutUrl += '&rate=' + rateType;
        
        // Redirect to checkout
        window.location.href = checkoutUrl;
    });
    
    // Booking form submit
    $(document).on('submit', '.gas-booking-form', function(e) {
        e.preventDefault();
        
        var $form = $(this);
        var $btn = $form.find('.gas-submit-btn');
        var originalText = $btn.text();
        
        $btn.prop('disabled', true).text('Processing...');
        
        var formData = {
            action: 'gas_create_booking',
            nonce: gasBooking.nonce,
            unit_id: $roomWidget.data('unit-id'),
            checkin: $('.gas-checkin').val(),
            checkout: $('.gas-checkout').val(),
            guests: $('.gas-guests').val(),
            total_price: $roomWidget.data('total-price'),
            first_name: $form.find('[name="first_name"]').val(),
            last_name: $form.find('[name="last_name"]').val(),
            email: $form.find('[name="email"]').val(),
            phone: $form.find('[name="phone"]').val(),
            notes: $form.find('[name="notes"]').val()
        };
        
        $.ajax({
            url: gasBooking.ajaxUrl,
            method: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    $('.gas-booking-card-header, .gas-booking-card-body, .gas-booking-form-section').hide();
                    $('.gas-confirmation-text').text('Booking reference: ' + (response.booking_id || 'Confirmed'));
                    $('.gas-booking-id').text('Check your email for confirmation details.');
                    $('.gas-booking-confirmation').show();
                } else {
                    alert('Booking failed: ' + (response.error || 'Unknown error'));
                    $btn.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                alert('Connection error. Please try again.');
                $btn.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // ========================================
    // Rooms Grid Functions (for Book Now page)
    // ========================================
    
    function checkAllAvailability(checkin, checkout, guests) {
        var $rooms = $('.gas-room-card');
        var selectedGuests = parseInt(guests) || 1;
        
        $rooms.each(function() {
            var $room = $(this);
            var unitId = $room.data('room-id');
            var maxGuests = parseInt($room.data('max-guests')) || 2;
            
            // First check if room can accommodate the guests
            if (selectedGuests > maxGuests) {
                $room.removeClass('available').addClass('unavailable guest-exceeded');
                $room.find('.gas-room-price').html('<span class="gas-too-small">Max ' + maxGuests + ' guests</span>');
                $room.find('.gas-view-btn').css({'background': '#9ca3af', 'pointer-events': 'none'}).text('Not Available');
                return; // Skip availability check
            }
            
            // Remove guest-exceeded class if previously set
            $room.removeClass('guest-exceeded');
            
            // Check date availability
            if (checkin && checkout) {
                // Show loading state
                $room.find('.gas-room-price').html('<span class="gas-checking">Checking...</span>');
                
                $.ajax({
                    url: gasBooking.apiUrl + '/api/public/availability/' + unitId + '?from=' + checkin + '&to=' + checkout,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        console.log('Availability for room ' + unitId + ':', response);
                        
                        if (response.is_available) {
                            $room.removeClass('unavailable').addClass('available');
                            var nights = calculateNights(checkin, checkout);
                            var totalPrice = response.total_price || 0;
                            $room.find('.gas-room-price').html(gasBooking.currency + Math.round(totalPrice) + ' <span>total</span>');
                            $room.find('.gas-view-btn').css({'background': '', 'pointer-events': ''}).text('View & Book');
                        } else {
                            $room.removeClass('available').addClass('unavailable dates-blocked');
                            $room.find('.gas-room-price').html('<span class="gas-not-available">Not available</span>');
                            $room.find('.gas-view-btn').css({'background': '#9ca3af', 'pointer-events': 'none'}).text('Unavailable');
                        }
                    },
                    error: function() {
                        // On error, don't mark as unavailable - just show base price
                        $room.find('.gas-room-price').html($room.data('base-price') || '');
                    }
                });
            }
        });
        
        // Reorder after a delay to move unavailable rooms to bottom
        setTimeout(reorderRooms, 2000);
    }
    
    // Reorder rooms - unavailable at bottom
    function reorderRooms() {
        var $container = $('.gas-rooms-grid');
        if (!$container.length) return;
        
        var $available = $container.find('.gas-room-card.available');
        var $unavailable = $container.find('.gas-room-card.unavailable');
        
        if ($unavailable.length > 0 && $available.length > 0) {
            // Remove existing divider if any
            $container.find('.gas-rooms-divider').remove();
            
            // Move available rooms first
            $available.prependTo($container);
            
            // Add divider
            $container.append('<div class="gas-rooms-divider">Rooms below are not available for selected dates</div>');
            
            // Move unavailable rooms after divider
            $unavailable.appendTo($container);
        }
    }
    
    // Also filter on page load if guests param is present
    function filterByGuests() {
        var urlParams = new URLSearchParams(window.location.search);
        var guests = parseInt(urlParams.get('guests')) || 0;
        
        console.log('Filter by guests:', guests);
        
        if (guests > 0) {
            $('.gas-room-card').each(function() {
                var $room = $(this);
                var maxGuestsAttr = $room.attr('data-max-guests');
                var maxGuests = parseInt(maxGuestsAttr) || 2;
                
                console.log('Room max guests:', maxGuests, 'Selected:', guests, 'Attr:', maxGuestsAttr);
                
                if (guests > maxGuests) {
                    $room.addClass('unavailable guest-exceeded');
                    $room.find('.gas-room-price').html('<span class="gas-too-small">Max ' + maxGuests + ' guests</span>');
                    $room.find('.gas-view-btn').css({'background': '#9ca3af', 'pointer-events': 'none'});
                }
            });
            
            // Reorder rooms after short delay
            setTimeout(function() {
                reorderRoomsByGuests();
            }, 300);
        }
    }
    
    // Reorder rooms - guests exceeded at bottom
    function reorderRoomsByGuests() {
        var $container = $('.gas-rooms-grid');
        if (!$container.length) return;
        
        var $ok = $container.find('.gas-room-card:not(.guest-exceeded)');
        var $exceeded = $container.find('.gas-room-card.guest-exceeded');
        
        if ($exceeded.length > 0 && $ok.length > 0) {
            // Add divider and move exceeded rooms to end
            $container.append('<div class="gas-rooms-divider" style="grid-column: 1/-1; padding: 20px 0; text-align: center; color: #9ca3af; font-size: 14px; border-top: 1px solid #e5e7eb; margin-top: 20px;">Rooms below cannot accommodate ' + (parseInt(new URLSearchParams(window.location.search).get('guests')) || 0) + ' guests</div>');
            $exceeded.appendTo($container);
        }
    }
    
    // Run guest filter on page load
    $(document).ready(function() {
        setTimeout(filterByGuests, 100); // Small delay to ensure DOM is ready
    });
    
    function reorderRooms() {
        var $container = $('.gas-rooms-grid');
        var $available = $container.find('.gas-room-card.available');
        var $unavailable = $container.find('.gas-room-card.unavailable');
        
        // If we have mixed results, split into sections
        if ($available.length > 0 && $unavailable.length > 0) {
            var $parent = $container.parent();
            $container.remove();
            
            var html = '<div class="gas-rooms-section"><h3 class="gas-section-title">Available Rooms</h3><div class="gas-rooms-grid gas-available-rooms"></div></div>';
            html += '<div class="gas-rooms-section"><h3 class="gas-section-title unavailable">Unavailable Rooms</h3><div class="gas-rooms-grid gas-unavailable-rooms"></div></div>';
            
            $parent.append(html);
            $parent.find('.gas-available-rooms').append($available);
            $parent.find('.gas-unavailable-rooms').append($unavailable);
        }
    }
    
    // Filter button
    $(document).on('click', '.gas-filter-btn', function() {
        var checkin = $('.gas-filter-checkin').val();
        var checkout = $('.gas-filter-checkout').val();
        var guests = $('.gas-filter-guests').val();
        
        var params = [];
        if (checkin) params.push('checkin=' + checkin);
        if (checkout) params.push('checkout=' + checkout);
        if (guests) params.push('guests=' + guests);
        
        var url = window.location.pathname;
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        window.location.href = url;
    });
    
    // Also expose as global function for inline onclick
    window.gasFilterRooms = function() {
        $('.gas-filter-btn').click();
    };
    
    // ========================================
    // Rooms Grid Map
    // ========================================
    var roomsMap = null;
    var roomMarkers = {};
    var markerClusterGroup = null;
    
    function initRoomsMap() {
        if (!$('#gas-rooms-map').length || typeof gasRoomsMapData === 'undefined' || !gasRoomsMapData.length) {
            return;
        }
        
        // Calculate bounds from all rooms
        var bounds = [];
        gasRoomsMapData.forEach(function(room) {
            if (room.lat && room.lng) {
                bounds.push([room.lat, room.lng]);
            }
        });
        
        if (bounds.length === 0) return;
        
        // Create map
        roomsMap = L.map('gas-rooms-map', {
            scrollWheelZoom: true
        });
        
        // Add tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
            maxZoom: 19
        }).addTo(roomsMap);
        
        // Group rooms by property (same coordinates)
        var propertyGroups = {};
        gasRoomsMapData.forEach(function(room) {
            var key = room.lat + ',' + room.lng;
            if (!propertyGroups[key]) {
                propertyGroups[key] = [];
            }
            propertyGroups[key].push(room);
        });
        
        // Custom icon
        var defaultIcon = L.divIcon({
            className: 'gas-map-marker',
            html: '<div class="gas-marker-pin"></div>',
            iconSize: [30, 40],
            iconAnchor: [15, 40],
            popupAnchor: [0, -40]
        });
        
        // Add markers for each property group
        Object.keys(propertyGroups).forEach(function(key) {
            var rooms = propertyGroups[key];
            var lat = rooms[0].lat;
            var lng = rooms[0].lng;
            
            // Create marker
            var marker = L.marker([lat, lng], {
                icon: defaultIcon
            }).addTo(roomsMap);
            
            // Build popup content
            var popupHtml = '<div class="gas-map-popup">';
            
            if (rooms.length === 1) {
                // Single room popup
                var room = rooms[0];
                if (room.image_url) {
                    popupHtml += '<img src="' + room.image_url + '" class="gas-map-popup-image" alt="' + room.name + '">';
                }
                popupHtml += '<div class="gas-map-popup-title">' + room.name + '</div>';
                if (room.property_name) {
                    popupHtml += '<div class="gas-map-popup-property">' + room.property_name + '</div>';
                }
                if (room.price > 0) {
                    popupHtml += '<div class="gas-map-popup-price">' + gasBooking.currency + Math.round(room.price) + ' <small>/ night</small></div>';
                }
                popupHtml += '<a href="' + room.url + '" class="gas-map-popup-link">View &amp; Book</a>';
            } else {
                // Multiple rooms at same location
                popupHtml += '<div class="gas-map-popup-title">' + rooms[0].property_name + '</div>';
                popupHtml += '<div class="gas-map-popup-property">' + rooms.length + ' rooms available</div>';
                popupHtml += '<div style="max-height: 150px; overflow-y: auto; margin-top: 8px;">';
                rooms.forEach(function(room) {
                    popupHtml += '<div style="padding: 6px 0; border-bottom: 1px solid #eee;">';
                    popupHtml += '<div style="font-weight: 500; font-size: 13px;">' + room.name + '</div>';
                    if (room.price > 0) {
                        popupHtml += '<div style="font-size: 12px; color: #666;">' + gasBooking.currency + Math.round(room.price) + '/night</div>';
                    }
                    popupHtml += '<a href="' + room.url + '" style="font-size: 11px; color: #667eea;">View →</a>';
                    popupHtml += '</div>';
                });
                popupHtml += '</div>';
            }
            
            popupHtml += '</div>';
            
            marker.bindPopup(popupHtml, {
                maxWidth: 280,
                minWidth: 200
            });
            
            // Store marker reference for each room
            rooms.forEach(function(room) {
                roomMarkers[room.id] = marker;
            });
        });
        
        // Fit map to bounds
        if (bounds.length === 1) {
            roomsMap.setView(bounds[0], 15);
        } else {
            roomsMap.fitBounds(bounds, { padding: [30, 30] });
        }
        
        // Card hover interaction
        $(document).on('mouseenter', '.gas-room-card', function() {
            var roomId = $(this).data('room-id');
            if (roomMarkers[roomId]) {
                roomMarkers[roomId].openPopup();
            }
        });
        
        $(document).on('mouseleave', '.gas-room-card', function() {
            var roomId = $(this).data('room-id');
            if (roomMarkers[roomId]) {
                roomMarkers[roomId].closePopup();
            }
        });
        
        // Card click to navigate
        $(document).on('click', '.gas-room-card', function(e) {
            // Don't navigate if clicking the View & Book button
            if ($(e.target).hasClass('gas-view-btn') || $(e.target).closest('.gas-view-btn').length) {
                return;
            }
            var url = $(this).data('url');
            if (url) {
                window.location.href = url;
            }
        });
    }
    
    // Initialize rooms map if present
    if ($('#gas-rooms-map').length && typeof L !== 'undefined') {
        initRoomsMap();
    }
    
    // ========================================
    // Mobile Calendar Swipe Navigation
    // ========================================
    (function() {
        var $container = $('.gas-calendar-container');
        if (!$container.length) return;
        
        var touchStartX = 0;
        var touchEndX = 0;
        
        $container.on('touchstart', function(e) {
            touchStartX = e.originalEvent.touches[0].clientX;
        });
        
        $container.on('touchend', function(e) {
            touchEndX = e.originalEvent.changedTouches[0].clientX;
            handleSwipe();
        });
        
        function handleSwipe() {
            var swipeThreshold = 50;
            var diff = touchStartX - touchEndX;
            
            if (Math.abs(diff) < swipeThreshold) return;
            
            if (diff > 0) {
                // Swipe left - show next month
                $container.addClass('show-next');
                $('.gas-cal-next').trigger('click');
            } else {
                // Swipe right - show previous month
                $container.removeClass('show-next');
                $('.gas-cal-prev').trigger('click');
            }
        }
        
        // Also handle navigation button clicks on mobile
        $(document).on('click', '.gas-cal-next', function() {
            if (window.innerWidth <= 500) {
                $container.addClass('show-next');
            }
        });
        
        $(document).on('click', '.gas-cal-prev', function() {
            if (window.innerWidth <= 500) {
                $container.removeClass('show-next');
            }
        });
    })();
    
    // =========================================================
    // CHECKOUT PAGE
    // =========================================================
    var $checkoutPage = $('.gas-checkout-page');
    if ($checkoutPage.length) {
        // Hide page hero/title elements (theme-agnostic)
        var heroSelectors = [
            '.page-hero', '.entry-header', '.page-title-section', '.hero-section',
            '.wp-block-post-title', '.page-header', '.page-title', '.entry-title',
            'article > header', '.hentry > header', '.ast-archive-description',
            '.developer-entry-title', '.developer-page-header', '.developer-hero'
        ];
        heroSelectors.forEach(function(selector) {
            $(selector).not('.gas-checkout-page *').hide();
        });
        // Also try to find and hide any dark header sections before our content
        $checkoutPage.prevAll('section, header, div').each(function() {
            var $el = $(this);
            var bg = $el.css('background-color');
            // Hide dark backgrounds (likely hero sections)
            if (bg && (bg.indexOf('rgb(0') === 0 || bg.indexOf('rgb(30') === 0 || bg.indexOf('rgb(31') === 0 || bg.indexOf('#1') === 0 || bg.indexOf('#2') === 0)) {
                $el.hide();
            }
        });
        
        var checkoutData = {
            unitId: $checkoutPage.data('unit-id'),
            checkin: $checkoutPage.data('checkin'),
            checkout: $checkoutPage.data('checkout'),
            guests: $checkoutPage.data('guests'),
            rateType: $checkoutPage.data('rate-type'),
            apiUrl: $checkoutPage.data('api-url'),
            clientId: $checkoutPage.data('client-id'),
            selectedUpsells: [],
            voucherCode: '',
            pricing: {}
        };
        
        // Load room details and pricing
        loadCheckoutData();
        
        function loadCheckoutData() {
            // Load room info
            $.ajax({
                url: checkoutData.apiUrl + '/api/public/unit/' + checkoutData.unitId,
                method: 'GET',
                success: function(response) {
                    if (response.success && response.unit) {
                        var room = response.unit;
                        $('.gas-summary-room-name').text(room.name);
                        $('.gas-summary-property').text(room.property_name || '');
                        
                        if (response.images && response.images.length > 0) {
                            var imgUrl = response.images[0].url || response.images[0].image_url;
                            if (imgUrl) {
                                $('.gas-room-thumb').attr('src', imgUrl);
                            }
                        } else {
                            // Use placeholder if no images
                            $('.gas-room-thumb').attr('src', 'https://via.placeholder.com/200x150?text=Room');
                        }
                        
                        checkoutData.room = room;
                        checkoutData.currency = room.currency || gasBooking.currency || 'USD';
                    }
                }
            });
            
            // Load pricing
            $.ajax({
                url: checkoutData.apiUrl + '/api/public/calculate-price',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    unit_id: checkoutData.unitId,
                    check_in: checkoutData.checkin,
                    check_out: checkoutData.checkout,
                    guests: checkoutData.guests
                }),
                success: function(response) {
                    if (response.success) {
                        checkoutData.pricing = response;
                        updateCheckoutPricing();
                    }
                }
            });
            
            // Load upsells
            if (checkoutData.clientId) {
                $.ajax({
                    url: checkoutData.apiUrl + '/api/public/client/' + checkoutData.clientId + '/upsells?unit_id=' + checkoutData.unitId,
                    method: 'GET',
                    success: function(response) {
                        $('.gas-upsells-loading').hide();
                        if (response.success && response.upsells && response.upsells.length > 0) {
                            renderCheckoutUpsells(response.upsells);
                        } else {
                            $('.gas-no-upsells').show();
                        }
                    },
                    error: function() {
                        $('.gas-upsells-loading').hide();
                        $('.gas-no-upsells').show();
                    }
                });
            } else {
                $('.gas-upsells-loading').hide();
                $('.gas-no-upsells').show();
            }
        }
        
        function updateCheckoutPricing() {
            var p = checkoutData.pricing || {};
            var currency = checkoutData.currency || 'USD';
            var nights = p.nights || 1;
            var accommodationTotal = parseFloat(p.accommodation_total) || 0;
            var upsellsTotal = calculateUpsellsTotal();
            var discount = parseFloat(p.offer_discount) || 0;
            var voucherDiscount = parseFloat(checkoutData.voucherDiscount) || 0;
            var taxes = p.taxes || [];
            var taxTotal = 0;
            
            console.log('Checkout pricing update:', {
                nights: nights,
                accommodationTotal: accommodationTotal,
                discount: discount,
                taxes: taxes
            });
            
            // Accommodation line
            var perNight = nights > 0 ? Math.round(accommodationTotal / nights) : 0;
            $('.gas-nights-label').text(formatPriceShort(perNight, currency) + ' x ' + nights + ' night' + (nights > 1 ? 's' : ''));
            $('.gas-nights-total').text(formatPrice(accommodationTotal, currency));
            
            // Discount line
            if (discount > 0) {
                $('.gas-discount-line').show().find('.gas-discount-amount').text('-' + formatPrice(discount, currency));
            } else {
                $('.gas-discount-line').hide();
            }
            
            // Update selected extras in left sidebar
            if (checkoutData.selectedUpsells && checkoutData.selectedUpsells.length > 0) {
                var extrasHtml = '';
                checkoutData.selectedUpsells.forEach(function(upsell) {
                    var itemTotal = calculateUpsellItemTotal(upsell);
                    extrasHtml += '<div class="gas-extra-item">';
                    extrasHtml += '<span>' + upsell.name + '</span>';
                    extrasHtml += '<span>' + formatPrice(itemTotal, currency) + '</span>';
                    extrasHtml += '</div>';
                });
                $('.gas-extras-list').html(extrasHtml);
                $('.gas-selected-extras').show();
            } else {
                $('.gas-selected-extras').hide();
            }
            
            // Voucher discount
            if (voucherDiscount > 0) {
                $('.gas-voucher-line').show().find('.gas-voucher-discount').text('-' + formatPrice(voucherDiscount, currency));
            } else {
                $('.gas-voucher-line').hide();
            }
            
            // Taxes breakdown
            if (taxes && taxes.length > 0) {
                var taxesHtml = '';
                taxes.forEach(function(tax) {
                    var taxAmt = parseFloat(tax.amount) || 0;
                    taxesHtml += '<div class="gas-tax-item">';
                    taxesHtml += '<span>' + tax.name + '</span>';
                    taxesHtml += '<span>' + formatPrice(taxAmt, currency) + '</span>';
                    taxesHtml += '</div>';
                    taxTotal += taxAmt;
                });
                $('.gas-taxes-list').html(taxesHtml);
                $('.gas-taxes-section').show();
            } else {
                $('.gas-taxes-section').hide();
            }
            
            // Update cancellation policy based on rate type
            if (checkoutData.rateType === 'offer') {
                $('.gas-policy-standard').hide();
                $('.gas-policy-nonrefund').show();
            } else {
                $('.gas-policy-standard').show();
                $('.gas-policy-nonrefund').hide();
            }
            
            // Grand total
            var grandTotal = accommodationTotal + upsellsTotal - discount - voucherDiscount + taxTotal;
            if (isNaN(grandTotal)) grandTotal = 0;
            $('.gas-grand-total').text(formatPrice(grandTotal, currency));
            
            checkoutData.grandTotal = grandTotal;
        }
        
        function calculateUpsellItemTotal(upsell) {
            var nights = checkoutData.pricing.nights || 1;
            var guests = checkoutData.guests || 1;
            var price = parseFloat(upsell.price);
            
            if (upsell.charge_type === 'per_night') {
                price = price * nights;
            } else if (upsell.charge_type === 'per_guest') {
                price = price * guests;
            } else if (upsell.charge_type === 'per_guest_per_night') {
                price = price * nights * guests;
            }
            
            return price * (upsell.quantity || 1);
        }
        
        function calculateUpsellsTotal() {
            var total = 0;
            var nights = checkoutData.pricing.nights || 1;
            var guests = checkoutData.guests || 1;
            
            checkoutData.selectedUpsells.forEach(function(upsell) {
                var price = parseFloat(upsell.price);
                if (upsell.charge_type === 'per_night') {
                    price = price * nights;
                } else if (upsell.charge_type === 'per_guest') {
                    price = price * guests;
                } else if (upsell.charge_type === 'per_guest_per_night') {
                    price = price * nights * guests;
                }
                total += price * (upsell.quantity || 1);
            });
            
            return total;
        }
        
        function renderCheckoutUpsells(upsells) {
            var currency = checkoutData.currency || 'USD';
            var html = '';
            
            console.log('Rendering upsells:', upsells);
            
            upsells.forEach(function(upsell) {
                var priceLabel = '';
                switch (upsell.charge_type) {
                    case 'per_night': priceLabel = '/night'; break;
                    case 'per_guest': priceLabel = '/guest'; break;
                    case 'per_guest_per_night': priceLabel = '/guest/night'; break;
                    default: priceLabel = '';
                }
                
                html += '<div class="gas-upsell-card" data-upsell-id="' + upsell.id + '" data-price="' + upsell.price + '" data-charge-type="' + (upsell.charge_type || 'per_booking') + '">';
                
                // Image if available
                if (upsell.image_url) {
                    html += '<div class="gas-upsell-image"><img src="' + upsell.image_url + '" alt="' + upsell.name + '" /></div>';
                } else {
                    // Default icon based on name
                    var icon = '✨';
                    var nameLower = upsell.name.toLowerCase();
                    if (nameLower.includes('parking')) icon = '🚗';
                    else if (nameLower.includes('breakfast')) icon = '🍳';
                    else if (nameLower.includes('dog') || nameLower.includes('pet')) icon = '🐕';
                    else if (nameLower.includes('towel')) icon = '🛁';
                    else if (nameLower.includes('wine') || nameLower.includes('champagne')) icon = '🍾';
                    else if (nameLower.includes('flower') || nameLower.includes('roses')) icon = '💐';
                    else if (nameLower.includes('spa') || nameLower.includes('massage')) icon = '💆';
                    else if (nameLower.includes('airport') || nameLower.includes('transfer')) icon = '🚐';
                    else if (nameLower.includes('late') || nameLower.includes('early')) icon = '🕐';
                    else if (nameLower.includes('cot') || nameLower.includes('baby') || nameLower.includes('crib')) icon = '👶';
                    html += '<div class="gas-upsell-icon">' + icon + '</div>';
                }
                
                html += '<div class="gas-upsell-info">';
                html += '<div class="gas-upsell-name">' + upsell.name + '</div>';
                if (upsell.description) {
                    html += '<div class="gas-upsell-desc">' + upsell.description + '</div>';
                }
                html += '<div class="gas-upsell-price">' + formatPriceShort(upsell.price, currency) + '<small>' + priceLabel + '</small></div>';
                html += '</div>';
                
                html += '<div class="gas-upsell-check">✓</div>';
                html += '</div>';
            });
            
            if (html === '') {
                $('.gas-no-upsells').show();
            } else {
                $('.gas-checkout-upsells').html(html);
            }
        }
        
        // Upsell click handler
        $(document).on('click', '.gas-upsell-card', function() {
            var $card = $(this);
            var upsellId = $card.data('upsell-id');
            var price = $card.data('price');
            var chargeType = $card.data('charge-type');
            var name = $card.find('.gas-upsell-name').text();
            
            if ($card.hasClass('selected')) {
                $card.removeClass('selected');
                checkoutData.selectedUpsells = checkoutData.selectedUpsells.filter(function(u) {
                    return u.id !== upsellId;
                });
            } else {
                $card.addClass('selected');
                checkoutData.selectedUpsells.push({
                    id: upsellId,
                    name: name,
                    price: price,
                    charge_type: chargeType,
                    quantity: 1
                });
            }
            
            updateCheckoutPricing();
        });
        
        // Email confirmation match
        $(document).on('input', '#gas-email, #gas-email-confirm', function() {
            var email = $('#gas-email').val();
            var confirm = $('#gas-email-confirm').val();
            
            if (confirm.length > 0) {
                if (email === confirm) {
                    $('.gas-email-match').show();
                    $('.gas-email-mismatch').hide();
                } else {
                    $('.gas-email-match').hide();
                    $('.gas-email-mismatch').show();
                }
            } else {
                $('.gas-email-match, .gas-email-mismatch').hide();
            }
        });
        
        // Step navigation
        $(document).on('click', '.gas-next-step', function() {
            var nextStep = $(this).data('next');
            var currentStep = nextStep - 1;
            
            // Validate current step
            if (currentStep === 1) {
                var $form = $('#gas-guest-form');
                var isValid = $form[0].checkValidity();
                
                // Check email match
                var email = $('#gas-email').val();
                var confirm = $('#gas-email-confirm').val();
                if (email !== confirm) {
                    alert('Email addresses do not match. Please check and try again.');
                    return;
                }
                
                if (!isValid) {
                    $form[0].reportValidity();
                    return;
                }
            }
            
            // Hide current, show next
            $('.gas-checkout-step-content').hide();
            $('.gas-checkout-step-content[data-step="' + nextStep + '"]').show();
            
            // Update step indicators
            $('.gas-step').removeClass('active');
            $('.gas-step[data-step="' + nextStep + '"]').addClass('active');
            $('.gas-step').each(function() {
                if ($(this).data('step') < nextStep) {
                    $(this).addClass('completed');
                }
            });
            
            // Scroll to top
            $('html, body').animate({ scrollTop: $checkoutPage.offset().top - 20 }, 300);
        });
        
        $(document).on('click', '.gas-prev-step', function() {
            var prevStep = $(this).data('prev');
            
            $('.gas-checkout-step-content').hide();
            $('.gas-checkout-step-content[data-step="' + prevStep + '"]').show();
            
            $('.gas-step').removeClass('active completed');
            $('.gas-step[data-step="' + prevStep + '"]').addClass('active');
            $('.gas-step').each(function() {
                if ($(this).data('step') < prevStep) {
                    $(this).addClass('completed');
                }
            });
        });
        
        // Payment option selection
        $(document).on('click', '.gas-payment-option:not(.disabled)', function() {
            $('.gas-payment-option').removeClass('selected');
            $(this).addClass('selected');
            $(this).find('input').prop('checked', true);
        });
        
        // Voucher apply
        $(document).on('click', '.gas-btn-apply', function() {
            var code = $('.gas-voucher-input').val().trim().toUpperCase();
            if (!code) return;
            
            var $btn = $(this);
            $btn.prop('disabled', true).text('Checking...');
            
            $.ajax({
                url: checkoutData.apiUrl + '/api/public/validate-voucher',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    code: code,
                    unit_id: checkoutData.unitId,
                    check_in: checkoutData.checkin,
                    check_out: checkoutData.checkout
                }),
                success: function(response) {
                    $btn.prop('disabled', false).text('Apply');
                    
                    if (response.success && response.valid) {
                        checkoutData.voucherCode = code;
                        checkoutData.voucher = response.voucher;
                        $('.gas-voucher-result').html('<span class="gas-voucher-success">✓ ' + response.voucher.name + ' applied!</span>');
                        
                        // Show voucher discount in summary
                        var discount = 0;
                        var subtotal = checkoutData.grandTotal;
                        if (response.voucher.discount_type === 'percentage') {
                            discount = subtotal * (response.voucher.discount_value / 100);
                        } else {
                            discount = parseFloat(response.voucher.discount_value);
                        }
                        
                        $('.gas-voucher-line').show();
                        $('.gas-voucher-label').text('Promo: ' + code);
                        $('.gas-voucher-discount').text('-' + formatPrice(discount, checkoutData.currency));
                        
                        checkoutData.voucherDiscount = discount;
                        checkoutData.grandTotal = checkoutData.grandTotal - discount;
                        $('.gas-grand-total').text(formatPrice(checkoutData.grandTotal, checkoutData.currency));
                    } else {
                        $('.gas-voucher-result').html('<span class="gas-voucher-error">' + (response.error || 'Invalid voucher code') + '</span>');
                    }
                },
                error: function() {
                    $btn.prop('disabled', false).text('Apply');
                    $('.gas-voucher-result').html('<span class="gas-voucher-error">Error checking voucher</span>');
                }
            });
        });
        
        // Confirm booking
        $(document).on('click', '#gas-confirm-booking', function() {
            var $btn = $(this);
            
            // Check terms
            if (!$('#gas-terms').is(':checked')) {
                alert('Please agree to the Terms & Conditions to continue.');
                return;
            }
            
            $btn.prop('disabled', true);
            $btn.find('.gas-btn-text').hide();
            $btn.find('.gas-btn-loading').show();
            
            // Gather form data
            var $form = $('#gas-guest-form');
            var formData = {
                unit_id: checkoutData.unitId,
                check_in: checkoutData.checkin,
                check_out: checkoutData.checkout,
                guests: checkoutData.guests,
                first_name: $form.find('[name="first_name"]').val(),
                last_name: $form.find('[name="last_name"]').val(),
                email: $form.find('[name="email"]').val(),
                phone: $form.find('[name="phone"]').val(),
                country: $form.find('[name="country"]').val(),
                notes: $form.find('[name="notes"]').val(),
                marketing: $form.find('[name="marketing"]').is(':checked'),
                payment_method: $('input[name="payment_method"]:checked').val(),
                total_price: checkoutData.grandTotal,
                rate_type: checkoutData.rateType,
                upsells: checkoutData.selectedUpsells,
                voucher_code: checkoutData.voucherCode
            };
            
            $.ajax({
                url: checkoutData.apiUrl + '/api/public/book',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(formData),
                success: function(response) {
                    if (response.success) {
                        // Show confirmation
                        $('.gas-checkout-main > *').hide();
                        $('.gas-checkout-confirmation').show();
                        
                        $('.gas-booking-ref').text(response.booking_id || response.booking?.id || 'Confirmed');
                        $('.gas-guest-email').text(formData.email);
                        
                        // Build confirmation details
                        var details = '<p><strong>Room:</strong> ' + (checkoutData.room?.name || 'Room') + '</p>';
                        details += '<p><strong>Check-in:</strong> ' + checkoutData.checkin + '</p>';
                        details += '<p><strong>Check-out:</strong> ' + checkoutData.checkout + '</p>';
                        details += '<p><strong>Guests:</strong> ' + checkoutData.guests + '</p>';
                        details += '<p><strong>Total:</strong> ' + checkoutData.currency + Math.round(checkoutData.grandTotal) + '</p>';
                        details += '<p><strong>Payment:</strong> Pay at Property</p>';
                        
                        $('.gas-confirmation-details').html(details);
                        
                        // Scroll to top
                        $('html, body').animate({ scrollTop: $checkoutPage.offset().top - 20 }, 300);
                    } else {
                        alert('Booking failed: ' + (response.error || 'Please try again'));
                        $btn.prop('disabled', false);
                        $btn.find('.gas-btn-text').show();
                        $btn.find('.gas-btn-loading').hide();
                    }
                },
                error: function() {
                    alert('Connection error. Please try again.');
                    $btn.prop('disabled', false);
                    $btn.find('.gas-btn-text').show();
                    $btn.find('.gas-btn-loading').hide();
                }
            });
        });
    }
});
