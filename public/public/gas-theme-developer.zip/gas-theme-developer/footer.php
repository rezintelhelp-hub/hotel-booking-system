</main>

<footer class="developer-footer">
    <div class="developer-container">
        <div class="developer-footer-grid">
            <div class="developer-footer-brand">
                <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <h3 style="color: white; margin-bottom: 0;"><?php bloginfo('name'); ?></h3>
                <?php endif; ?>
                <p><?php bloginfo('description'); ?></p>
                
                <div class="developer-footer-social">
                    <?php if (get_theme_mod('developer_social_facebook')) : ?>
                        <a href="<?php echo esc_url(get_theme_mod('developer_social_facebook')); ?>" target="_blank" aria-label="Facebook">
                            <svg fill="currentColor" viewBox="0 0 24 24" width="20" height="20"><path d="M18.77,7.46H14.5v-1.9c0-.9.6-1.1,1-1.1h3V.5h-4.33C10.24.5,9.5,3.44,9.5,5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4Z"/></svg>
                        </a>
                    <?php endif; ?>
                    <?php if (get_theme_mod('developer_social_instagram')) : ?>
                        <a href="<?php echo esc_url(get_theme_mod('developer_social_instagram')); ?>" target="_blank" aria-label="Instagram">
                            <svg fill="currentColor" viewBox="0 0 24 24" width="20" height="20"><path d="M12,2.16c3.2,0,3.58,0,4.85.07,3.25.15,4.77,1.69,4.92,4.92.06,1.27.07,1.65.07,4.85s0,3.58-.07,4.85c-.15,3.23-1.66,4.77-4.92,4.92-1.27.06-1.65.07-4.85.07s-3.58,0-4.85-.07c-3.26-.15-4.77-1.7-4.92-4.92-.06-1.27-.07-1.65-.07-4.85s0-3.58.07-4.85C2.38,3.92,3.9,2.38,7.15,2.23,8.42,2.18,8.8,2.16,12,2.16ZM12,0C8.74,0,8.33,0,7.05.07c-4.35.2-6.78,2.62-7,7C0,8.33,0,8.74,0,12s0,3.67.07,4.95c.2,4.36,2.62,6.78,7,7C8.33,24,8.74,24,12,24s3.67,0,4.95-.07c4.35-.2,6.78-2.62,7-7C24,15.67,24,15.26,24,12s0-3.67-.07-4.95c-.2-4.35-2.62-6.78-7-7C15.67,0,15.26,0,12,0Zm0,5.84A6.16,6.16,0,1,0,18.16,12,6.16,6.16,0,0,0,12,5.84ZM12,16a4,4,0,1,1,4-4A4,4,0,0,1,12,16ZM18.41,4.15a1.44,1.44,0,1,0,1.44,1.44A1.44,1.44,0,0,0,18.41,4.15Z"/></svg>
                        </a>
                    <?php endif; ?>
                    <?php if (get_theme_mod('developer_social_twitter')) : ?>
                        <a href="<?php echo esc_url(get_theme_mod('developer_social_twitter')); ?>" target="_blank" aria-label="Twitter">
                            <svg fill="currentColor" viewBox="0 0 24 24" width="20" height="20"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                        </a>
                    <?php endif; ?>
                    <?php if (get_theme_mod('developer_social_youtube')) : ?>
                        <a href="<?php echo esc_url(get_theme_mod('developer_social_youtube')); ?>" target="_blank" aria-label="YouTube">
                            <svg fill="currentColor" viewBox="0 0 24 24" width="20" height="20"><path d="M23.5,6.19a3.02,3.02,0,0,0-2.12-2.14C19.5,3.5,12,3.5,12,3.5s-7.5,0-9.38.55A3.02,3.02,0,0,0,.5,6.19,31.64,31.64,0,0,0,0,12a31.64,31.64,0,0,0,.5,5.81,3.02,3.02,0,0,0,2.12,2.14c1.88.55,9.38.55,9.38.55s7.5,0,9.38-.55a3.02,3.02,0,0,0,2.12-2.14A31.64,31.64,0,0,0,24,12,31.64,31.64,0,0,0,23.5,6.19ZM9.55,15.57V8.43L15.82,12Z"/></svg>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <div>
                <h4>Quick Links</h4>
                <ul class="developer-footer-links">
                    <li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
                    <li><a href="<?php echo esc_url(home_url('/book-now/')); ?>">Properties</a></li>
                    <li><a href="<?php echo esc_url(home_url('/about/')); ?>">About Us</a></li>
                    <li><a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a></li>
                    <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a></li>
                </ul>
            </div>
            
            <div>
                <h4>Properties</h4>
                <ul class="developer-footer-links">
                    <li><a href="<?php echo esc_url(home_url('/book-now/')); ?>">View All</a></li>
                    <li><a href="<?php echo esc_url(home_url('/book-now/')); ?>">Vacation Rentals</a></li>
                    <li><a href="<?php echo esc_url(home_url('/book-now/')); ?>">Luxury Stays</a></li>
                    <li><a href="<?php echo esc_url(home_url('/book-now/')); ?>">Family Homes</a></li>
                </ul>
            </div>
            
            <div>
                <h4>Contact</h4>
                <ul class="developer-footer-links">
                    <?php if (get_theme_mod('developer_phone')) : ?>
                        <li><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', get_theme_mod('developer_phone'))); ?>"><?php echo esc_html(get_theme_mod('developer_phone')); ?></a></li>
                    <?php endif; ?>
                    <?php if (get_theme_mod('developer_email')) : ?>
                        <li><a href="mailto:<?php echo esc_attr(get_theme_mod('developer_email')); ?>"><?php echo esc_html(get_theme_mod('developer_email')); ?></a></li>
                    <?php endif; ?>
                    <?php if (get_theme_mod('developer_address')) : ?>
                        <li><?php echo esc_html(get_theme_mod('developer_address')); ?></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        
        <div class="developer-footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved. Powered by <a href="https://developer-admin.replit.app" target="_blank" style="color: inherit; text-decoration: underline;">GAS Booking</a></p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
