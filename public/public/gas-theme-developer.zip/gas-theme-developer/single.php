<?php
/**
 * Single Post Template
 *
 * @package GAS_Developer
 */

get_header();
?>

<article class="developer-single-post">
    <div class="developer-page-header">
        <div class="developer-container">
            <div class="developer-blog-meta" style="color: rgba(255,255,255,0.7); margin-bottom: 16px;">
                <?php echo get_the_date(); ?> · <?php echo get_the_category_list(', '); ?>
            </div>
            <h1><?php the_title(); ?></h1>
        </div>
    </div>
    
    <div class="developer-page-content">
        <div class="developer-container">
            <div style="max-width: 800px; margin: 0 auto;">
                <?php if (has_post_thumbnail()) : ?>
                    <div style="margin: -40px 0 40px; border-radius: 12px; overflow: hidden; box-shadow: var(--developer-shadow-lg);">
                        <?php the_post_thumbnail('large', array('style' => 'width: 100%; height: auto;')); ?>
                    </div>
                <?php endif; ?>
                
                <div class="developer-post-content" style="font-size: 18px; line-height: 1.8;">
                    <?php the_content(); ?>
                </div>
                
                <div style="margin-top: 60px; padding-top: 40px; border-top: 1px solid var(--developer-border);">
                    <h3>Share This Post</h3>
                    <div style="display: flex; gap: 12px; margin-top: 16px;">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" class="developer-btn" style="background: #1877f2; color: white; padding: 10px 20px;">Facebook</a>
                        <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>" target="_blank" class="developer-btn" style="background: #1da1f2; color: white; padding: 10px 20px;">Twitter</a>
                    </div>
                </div>
                
                <div style="margin-top: 60px;">
                    <a href="<?php echo esc_url(home_url('/blog/')); ?>" style="display: inline-flex; align-items: center; gap: 8px; color: var(--developer-primary);">
                        ← Back to Blog
                    </a>
                </div>
            </div>
        </div>
    </div>
</article>

<?php get_footer(); ?>
