<?php
/**
 * Template Name: Book Now
 * 
 * Properties listing page with map
 *
 * @package GAS_Developer
 */

get_header();
?>

<div class="developer-book-now-page">
    <?php if (shortcode_exists('gas_rooms')) : ?>
        <?php echo do_shortcode('[gas_rooms]'); ?>
    <?php else : ?>
        <div style="text-align: center; padding: 80px 24px; background: #f8fafc; border-radius: 12px; margin: 100px 24px;">
            <h3>Properties Coming Soon</h3>
            <p style="color: #64748b;">Please install and activate the GAS Booking plugin to display properties.</p>
        </div>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
