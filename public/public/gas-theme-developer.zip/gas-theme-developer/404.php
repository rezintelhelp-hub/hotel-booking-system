<?php
/**
 * 404 Error Page
 *
 * @package GAS_Developer
 */

get_header();
?>

<div class="developer-page-header">
    <div class="developer-container">
        <h1>Page Not Found</h1>
        <p>Oops! The page you're looking for doesn't exist.</p>
    </div>
</div>

<div class="developer-page-content">
    <div class="developer-container">
        <div style="text-align: center; max-width: 600px; margin: 0 auto; padding: 40px 0;">
            <div style="font-size: 120px; margin-bottom: 24px;">🏠</div>
            <h2>Let's Get You Back on Track</h2>
            <p style="color: var(--developer-text-light); margin-bottom: 32px;">The page you're looking for might have been moved, deleted, or never existed. No worries - let's help you find what you need.</p>
            
            <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="developer-btn developer-btn-primary" style="background: var(--developer-primary); color: white;">Go Home</a>
                <a href="<?php echo esc_url(home_url('/book-now/')); ?>" class="developer-btn" style="background: var(--developer-bg-alt); color: var(--developer-text);">View Properties</a>
                <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="developer-btn" style="background: var(--developer-bg-alt); color: var(--developer-text);">Contact Us</a>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
