<?php
/**
 * Default Page Template
 *
 * @package GAS_Developer
 */

get_header();
?>

<div class="developer-page-header">
    <div class="developer-container">
        <h1><?php the_title(); ?></h1>
    </div>
</div>

<div class="developer-page-content">
    <div class="developer-container">
        <?php while (have_posts()) : the_post(); ?>
            <div class="developer-page-body" style="max-width: 800px; margin: 0 auto;">
                <?php the_content(); ?>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php get_footer(); ?>
